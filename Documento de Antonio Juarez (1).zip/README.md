# 🎤 Chalan Voice

> **Sistema avanzado de clonación de voz y síntesis de audio con Inteligencia Artificial**

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![FastAPI](https://img.shields.io/badge/FastAPI-109689-?logo=fastapi&logoColor=white)](https://fastapi.tiangolo.com/)
[![Android](https://img.shields.io/badge/Android-3DDC84?logo=android&logoColor=white)](https://developer.android.com/)
[![Python](https://img.shields.io/badge/Python-3.9+-3776AB?logo=python&logoColor=white)](https://python.org)
[![PyTorch](https://img.shields.io/badge/PyTorch-EE4C2C?logo=pytorch&logoColor=white)](https://pytorch.org/)

## 📖 Descripción

Chalan Voice es una aplicación completa de clonación de voz que permite:

- 🎯 **Clonación de voz** con solo unos segundos de audio de muestra
- 🌍 **Soporte multilingüe** para 17 idiomas diferentes
- 🎭 **Transferencia emocional** para generar audio con diferentes emociones
- 🔒 **Watermarking acústico** para protección del contenido
- 📱 **Aplicación Android nativa** con interfaz moderna
- ☁️ **Backend escalable** con FastAPI y modelos de IA de vanguardia

## ✨ Características Principales

### 🧠 Modelos de IA Integrados

| Modelo | Características | Casos de Uso |
|--------|----------------|--------------|
| **XTTSv2** | Clonación zero-shot, multilingüe | Síntesis rápida en múltiples idiomas |
| **Bark** | Síntesis expresiva, +100 presets | Audio con emociones y efectos |
| **Tortoise-TTS** | Alta calidad, control fino | Audio de calidad profesional |

### 📱 Aplicación Android

- ✅ **Jetpack Compose** - Interfaz moderna y reactiva
- ✅ **Hilt** - Inyección de dependencias
- ✅ **Retrofit** - Cliente HTTP optimizado
- ✅ **Coroutines** - Programación asíncrona
- ✅ **Seguridad avanzada** - Autenticación JWT
- ✅ **Permisos granulares** - Control total de audio

### ☁️ Backend Robusto

- ⚡ **FastAPI** - Framework moderno y de alto rendimiento
- 🐳 **Docker ready** - Despliegue simplificado
- 🗄️ **Base de datos SQLite/PostgreSQL** - Almacenamiento flexible
- 📊 **Logs y monitoreo** - Trazabilidad completa
- 🔐 **JWT Authentication** - Seguridad empresarial

## 🚀 Inicio Rápido

### Prerequisitos

- **Python 3.9+** (para backend)
- **Android Studio** (para aplicación móvil)
- **NVIDIA GPU** (recomendado para rendimiento óptimo)
- **8GB+ RAM** (16GB+ recomendado)

### 📦 Instalación Completa

```bash
# 1. Clonar el repositorio
git clone https://github.com/tu-usuario/chalan-voice.git
cd chalan-voice

# 2. Configurar y ejecutar backend
cd backend
pip install -r requirements.txt
python main.py

# 3. Configurar aplicación Android
cd ../android-app
# Abrir en Android Studio y compilar
```

## 🔨 Compilación del APK Android

### Prerequisitos para Android

- **Android Studio** (Giraffe o superior)
- **JDK 11+**
- **Android SDK API 24+**
- **Gradle 8.0+**

### Instrucciones Paso a Paso

#### 1. Preparación del Entorno

```bash
# Navegar al directorio Android
cd android-app

# Verificar gradle wrapper
./gradlew --version

# Limpiar build anterior
./gradlew clean
```

#### 2. Configuración de Build

**Archivo `app/build.gradle`:**
```gradle
android {
    buildTypes {
        debug {
            debuggable true
            applicationIdSuffix ".debug"
        }
        release {
            minifyEnabled true
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }
    }
    
    signingConfigs {
        release {
            if (project.hasProperty('CHALAN_VOICE_UPLOAD_STORE_FILE')) {
                storeFile file(CHALAN_VOICE_UPLOAD_STORE_FILE)
                storePassword CHALAN_VOICE_UPLOAD_STORE_PASSWORD
                keyAlias CHALAN_VOICE_UPLOAD_KEY_ALIAS
                keyPassword CHALAN_VOICE_UPLOAD_KEY_PASSWORD
            }
        }
    }
}
```

#### 3. Compilar APK de Debug

```bash
# Compilar APK de debug (rápido)
./gradlew assembleDebug

# El APK se genera en:
# app/build/outputs/apk/debug/app-debug.apk
```

#### 4. Compilar APK de Release

```bash
# 1. Generar keystore (solo primera vez)
keytool -genkey -v -keystore chalan-voice.keystore -alias chalan-voice -keyalg RSA -keysize 2048 -validity 10000

# 2. Configurar variables en gradle.properties
CHALAN_VOICE_UPLOAD_STORE_FILE=chalan-voice.keystore
CHALAN_VOICE_UPLOAD_STORE_PASSWORD=tu_keystore_password
CHALAN_VOICE_UPLOAD_KEY_ALIAS=chalan-voice
CHALAN_VOICE_UPLOAD_KEY_PASSWORD=tu_key_password

# 3. Compilar APK de release firmado
./gradlew assembleRelease

# El APK se genera en:
# app/build/outputs/apk/release/app-release.apk
```

#### 5. Optimizaciones para Producción

**Habilitar R8 (ProGuard):**
```gradle
android {
    buildTypes {
        release {
            minifyEnabled true
            shrinkResources true
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }
    }
}
```

**Configurar Gradle Daemon:**
```gradle
# gradle.properties
org.gradle.jvmargs=-Xmx4096m -Dfile.encoding=UTF-8
org.gradle.parallel=true
org.gradle.caching=true
android.enableR8=true
```

#### 6. Probar el APK

```bash
# Instalar APK en dispositivo/emulador
adb install app/build/outputs/apk/debug/app-debug.apk

# Ver logs en tiempo real
adb logcat | grep ChalanVoice
```

#### 7. Generar App Bundle (AAB)

```bash
# Para publicación en Google Play Store
./gradlew bundleRelease

# Se genera en:
# app/build/outputs/bundle/release/app-release.aab
```

## 🛠️ Despliegue del Backend

### Opciones de Despliegue

#### 1. 🐳 Docker (Recomendado)

```bash
# Clonar y configurar
git clone https://github.com/tu-usuario/chalan-voice.git
cd chalan-voice/backend

# Variables de entorno para producción
cp .env.example .env
# Editar .env con configuraciones de producción

# Desplegar con Docker Compose
docker-compose up -d

# Verificar estado
docker-compose ps
docker-compose logs -f chalan-voice-api
```

**Archivo `.env` para producción:**
```env
# Seguridad
SECRET_KEY=tu-clave-secreta-muy-segura-para-produccion
WATERMARK_SECRET_KEY=clave-watermarking-segura

# Base de datos
DATABASE_URL=sqlite:///./chalan_voice.db

# Configuración
DEBUG=false
ALLOWED_ORIGINS=https://tu-dominio.com,https://app.tu-dominio.com

# Rendimiento
MAX_UPLOAD_SIZE=52428800
MAX_AUDIO_DURATION=300
GPU_ENABLED=true
```

#### 2. ☁️ Cloud Platforms

**AWS ECS:**
```bash
# Construir imagen
docker build -t chalan-voice:latest .

# Tag para ECR
docker tag chalan-voice:latest 123456789.dkr.ecr.region.amazonaws.com/chalan-voice:latest

# Push a ECR
docker push 123456789.dkr.ecr.region.amazonaws.com/chalan-voice:latest
```

**Google Cloud Run:**
```bash
# Construir y desplegar
gcloud run deploy chalan-voice \
  --source . \
  --platform managed \
  --region us-central1 \
  --allow-unauthenticated
```

**Heroku:**
```bash
# Instalar Heroku CLI y container registry
heroku create tu-app-chalan-voice
heroku container:push web -a tu-app-chalan-voice
heroku container:release web -a tu-app-chalan-voice
```

#### 3. 🖥️ Servidor Dedicado

```bash
# Actualizar sistema
sudo apt update && sudo apt upgrade -y

# Instalar Python 3.9+
sudo apt install python3.9 python3.9-pip python3.9-venv

# Instalar dependencias del sistema
sudo apt install build-essential libsndfile1 libsndfile1-dev

# Clonar repositorio
git clone https://github.com/tu-usuario/chalan-voice.git
cd chalan-voice/backend

# Crear entorno virtual
python3.9 -m venv venv
source venv/bin/activate

# Instalar dependencias
pip install -r requirements.txt

# Configurar como servicio systemd
sudo nano /etc/systemd/system/chalan-voice.service
```

**Servicio systemd:**
```ini
[Unit]
Description=Chalan Voice API
After=network.target

[Service]
Type=simple
User=www-data
WorkingDirectory=/path/to/chalan-voice/backend
Environment=PATH=/path/to/chalan-voice/backend/venv/bin
ExecStart=/path/to/chalan-voice/backend/venv/bin/python main.py
Restart=always

[Install]
WantedBy=multi-user.target
```

## ⚙️ Configuración de Desarrollo

### Backend

```bash
# Entorno virtual
python -m venv venv
source venv/bin/activate  # Linux/Mac
# venv\Scripts\activate  # Windows

# Instalar dependencias de desarrollo
pip install -r requirements.txt
pip install pytest black flake8 mypy

# Configurar variables de entorno
cp .env.example .env
# Editar .env

# Ejecutar en modo desarrollo
python main.py --reload
```

### Android

```bash
# Configurar SDK
export ANDROID_HOME=$HOME/Android/Sdk
export PATH=$PATH:$ANDROID_HOME/tools:$ANDROID_HOME/platform-tools

# Sincronizar dependencias
./gradlew build

# Ejecutar tests
./gradlew test

# Ejecutar en emulador/dispositivo
./gradlew installDebug
```

### Variables de Entorno

| Variable | Descripción | Ejemplo |
|----------|-------------|---------|
| `SECRET_KEY` | Clave secreta JWT | `super-secret-key-123` |
| `DEBUG` | Modo debug | `true/false` |
| `DATABASE_URL` | URL de base de datos | `sqlite:///./chalan_voice.db` |
| `ALLOWED_ORIGINS` | Orígenes permitidos CORS | `http://localhost:3000` |
| `GPU_ENABLED` | Habilitar GPU | `true/false` |
| `MAX_UPLOAD_SIZE` | Tamaño máximo upload | `52428800` (50MB) |

## 🔐 Políticas Éticas

### Uso Responsable

Chalan Voice debe utilizarse de manera ética y responsable:

- ✅ **Uso legítimo**: Contenido autorizado por los propietarios de voz
- ✅ **Propósito educativo**: Aprendizaje y investigación
- ✅ **Entretenimiento**: Contenido creativo sin fines maliciosos
- ✅ **Accesibilidad**: Ayuda para personas con discapacidades

### ❌ Uso Prohibido

- **Deepfakes maliciosos**: Creación de contenido falso de personas
- **Suplantación de identidad**: Engaño o fraude
- **Contenido dañino**: Propaganda, amenazas o acoso
- **Violación de privacidad**: Uso sin consentimiento
- **Actividades ilegales**: Cualquier actividad prohibida por ley

### 🔒 Protección de Datos

- **Consentimiento explícito** para clonación de voz
- **Encriptación de datos** en tránsito y reposo
- **Retención limitada** de datos de audio
- **Derechos del usuario**: Acceso, rectificación, eliminación

### 🛡️ Medidas de Seguridad

- **Watermarking acústico** en todo contenido generado
- **Trazabilidad completa** de generaciones
- **Validación de uploads** y contenido
- **Rate limiting** para prevenir abuso
- **Monitoreo continuo** de uso

## 🤝 Contribuir al Proyecto

### Cómo Contribuir

1. **Fork** el repositorio
2. **Crear branch** para tu feature (`git checkout -b feature/nueva-caracteristica`)
3. **Hacer commit** de tus cambios (`git commit -am 'Agregar nueva característica'`)
4. **Push** al branch (`git push origin feature/nueva-caracteristica`)
5. **Crear Pull Request**

### Estándares de Código

**Backend (Python):**
```bash
# Formatear código
black .

# Linting
flake8 .

# Type checking
mypy .

# Tests
pytest tests/
```

**Android (Kotlin):**
```bash
# Formatear código
./gradlew ktlintFormat

# Linting
./gradlew lint

# Tests
./gradlew test
```

### Reportar Issues

- Usar templates de issue proporcionados
- Incluir logs y detalles de error
- Especificar versión y configuración
- Proporcionar pasos para reproducir

### Roadmap

- [ ] **v1.1**: Soporte para más idiomas
- [ ] **v1.2**: Interfaz web administrativa
- [ ] **v1.3**: API de batch processing
- [ ] **v1.4**: Integración con servicios cloud
- [ ] **v1.5**: Modelos personalizados entrenables

## 📚 Documentación Adicional

- 📖 [Documentación Backend](./backend/README.md)
- 📱 [Documentación Android](./android-app/README.md)
- 🔌 [API Documentation](./docs/api.md)
- 💻 [Ejemplos de Código](./docs/examples.md)

## 🆘 Soporte y Ayuda

### Recursos

- **📖 Documentación**: [docs.chalanvoice.com](https://docs.chalanvoice.com)
- **💬 Discord**: [discord.gg/chalanvoice](https://discord.gg/chalanvoice)
- **🐛 Issues**: [GitHub Issues](https://github.com/tu-usuario/chalan-voice/issues)
- **📧 Email**: soporte@chalantech.com

### Troubleshooting

**Backend no inicia:**
```bash
# Verificar logs
docker-compose logs chalan-voice-api

# Verificar GPU
nvidia-smi

# Reinstaurar dependencias
pip install -r requirements.txt --force-reinstall
```

**APK no compila:**
```bash
# Limpiar proyecto
./gradlew clean
./gradlew --refresh-dependencies

# Verificar SDK
echo $ANDROID_HOME
```

## 📊 Estado del Proyecto

[![Build Status](https://img.shields.io/github/actions/workflow/status/tu-usuario/chalan-voice/ci.yml?branch=main)](https://github.com/tu-usuario/chalan-voice/actions)
[![Coverage](https://img.shields.io/codecov/c/github/tu-usuario/chalan-voice)](https://codecov.io/gh/tu-usuario/chalan-voice)
[![Releases](https://img.shields.io/github/v/release/tu-usuario/chalan-voice)](https://github.com/tu-usuario/chalan-voice/releases)

## 📄 Licencia

Este proyecto está bajo la licencia MIT. Ver [LICENSE](./LICENSE) para más detalles.

## 🙏 Agradecimientos

- **Coqui TTS** - Excelente librería de síntesis de voz
- **Bark Team** - Modelo de generación de audio expresivo
- **FastAPI** - Framework web moderno y rápido
- **Jetpack Compose** - Toolkit de UI para Android

---

**Chalan Voice** - Revolucionando la clonación de voz con IA 🤖✨

*Desarrollado con ❤️ por el equipo de ChalanTech*