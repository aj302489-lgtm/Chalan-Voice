# Configuración y Requisitos - Chalan Voice

Este documento describe todos los archivos de requisitos y configuración necesarios para ejecutar el proyecto Chalan Voice.

## 📁 Estructura de Archivos de Configuración

```
chalan-voice/
├── backend/
│   ├── requirements.txt          # Dependencias Python del backend
│   ├── .env.example             # Variables de entorno de ejemplo
│   ├── Dockerfile               # Configuración Docker
│   ├── docker-compose.yml       # Orquestación Docker
│   ├── install.sh              # Script de instalación automática
│   └── nginx.conf              # Configuración Nginx
├── android-app/
│   ├── app/build.gradle         # Configuración Android
│   ├── gradle.properties        # Propiedades Gradle
│   ├── .env.example            # Variables de entorno Android
│   ├── .gitignore              # Ignorar archivos Android
│   ├── install.sh              # Script de instalación Android
│   └── local.properties        # Configuración local (no versionar)
├── .gitignore                  # Archivo principal de ignores
├── setup.sh                   # Script de configuración rápida
└── README_CONFIG.md           # Este archivo
```

## 🐍 Backend (Python/FastAPI)

### requirements.txt
**Ubicación:** `backend/requirements.txt`

**Descripción:** Lista completa de dependencias Python necesarias para el backend, incluyendo:

- **Framework Web:** FastAPI, Uvicorn
- **AI/ML:** PyTorch, Transformers, TTS, librosa
- **Base de Datos:** SQLAlchemy, Pydantic
- **Audio:** soundfile, pydub, webrtcvad
- **Seguridad:** python-jose, passlib, cryptography
- **Utilidades:** aiofiles, httpx, validators

**Instalación:**
```bash
cd backend
pip install -r requirements.txt
```

### Variables de Entorno (.env.example)
**Ubicación:** `backend/.env.example`

**Descripción:** Plantilla de variables de entorno necesarias para el backend.

**Variables principales:**
```bash
# Configuración básica
APP_NAME=Chalan Voice API
DEBUG=false
HOST=0.0.0.0
PORT=8000

# Base de datos
DATABASE_URL=sqlite:///./chalan_voice.db

# JWT Authentication
SECRET_KEY=change-this-secret-key-in-production

# AI Models
XTTS_MODEL_NAME=tts_models/multilingual/multi-dataset/xtts_v2

# Audio processing
SAMPLE_RATE=24000
MAX_AUDIO_DURATION=300
```

**Configuración:**
```bash
cp backend/.env.example backend/.env
# Editar .env con tus valores específicos
```

### Docker Configuration
**Archivos:** `backend/Dockerfile`, `backend/docker-compose.yml`

**Descripción:** Configuración completa para despliegue con Docker, incluyendo:
- Imagen base con CUDA para GPU
- Instalación de dependencias de audio (FFmpeg, libsndfile)
- Configuración de volumenes para datos persistentes
- Nginx como reverse proxy opcional

**Uso:**
```bash
cd backend
docker-compose up --build
```

### Script de Instalación (install.sh)
**Ubicación:** `backend/install.sh`

**Descripción:** Script automático que:
- Verifica dependencias del sistema (Python, pip, git)
- Instala dependencias del sistema (ffmpeg, libsndfile, etc.)
- Configura entorno virtual Python
- Instala dependencias Python con GPU optimization
- Crea directorios necesarios
- Configura variables de entorno

**Uso:**
```bash
cd backend
bash install.sh
```

## 📱 Android App (Kotlin/Android)

### Build Configuration
**Archivos:** `android-app/app/build.gradle`, `android-app/gradle.properties`

**Descripción:** Configuración completa del proyecto Android con:
- **SDK:** minSdk 24, targetSdk 34
- **Dependencias:** Compose, Hilt, Retrofit, Accompanist
- **Features:** Navigation, Material3, Security, Audio
- **Testing:** JUnit, Espresso, Compose testing

### Variables de Entorno Android
**Archivo:** `android-app/.env.example`

**Descripción:** Referencia de configuraciones para la app Android, incluyendo:
- URLs de API y endpoints
- Configuración de audio y voice AI
- Configuración de debugging y performance
- Configuración de features opcionales

**Nota:** Android no usa archivos .env directamente. Estas variables deben configurarse en:
- `app/src/main/java/com/chalanvoice/data/Constants.kt`
- `local.properties`

### Script de Instalación Android
**Archivo:** `android-app/install.sh`

**Descripción:** Script automático que:
- Verifica Java 11+
- Verifica Android SDK y variables de entorno
- Construye proyecto con Gradle
- Opcional: Ejecuta tests
- Opcional: Instala en dispositivo/emulador
- Opcional: Genera APK de release

**Uso:**
```bash
cd android-app
bash install.sh
```

### .gitignore Android
**Archivo:** `android-app/.gitignore`

**Descripción:** Ignora archivos específicos de Android:
- Archivos de build (APK, AAB)
- Archivos de IDE (.idea, .vscode)
- Archivos del sistema (.DS_Store, Thumbs.db)
- Configuraciones sensibles (API keys, keystores)
- Archivos de audio y modelos grandes

## 🚀 Configuración Rápida

### Script de Configuración Principal
**Archivo:** `setup.sh` (raíz del proyecto)

**Descripción:** Script de configuración unificado que permite configurar:
- Solo Backend
- Solo Android App  
- Ambos componentes

**Uso:**
```bash
bash setup.sh
```

## 📋 Lista de Verificación

### ✅ Backend
- [ ] Python 3.9+ instalado
- [ ] pip y virtualenv disponibles
- [ ] Dependencias del sistema instaladas (ffmpeg, libsndfile)
- [ ] variables en `.env` configuradas
- [ ] Secret keys generadas para producción
- [ ] Base de datos configurada (SQLite para dev, PostgreSQL para prod)

### ✅ Android App
- [ ] Java 11+ instalado
- [ ] Android SDK configurado
- [ ] ANDROID_HOME configurado
- [ ] Gradle wrapper funcional
- [ ] URL del backend configurada en Constants.kt
- [ ] Permisos de la app configurados en AndroidManifest.xml

### ✅ Configuración General
- [ ] .gitignore configurado correctamente
- [ ] Archivos .env en .gitignore
- [ ] Variables sensibles no hardcodeadas
- [ ] Documentación de configuración actualizada

## 🔧 Comandos Útiles

### Backend
```bash
# Instalación automática
cd backend && bash install.sh

# Ejecución
python main.py

# Con Docker
docker-compose up --build

# Tests
pytest

# Ver documentación API
open http://localhost:8000/docs
```

### Android
```bash
# Instalación automática
cd android-app && bash install.sh

# Build debug
./gradlew assembleDebug

# Build release
./gradlew assembleRelease

# Tests
./gradlew test

# Instalar en dispositivo
adb install app/build/outputs/apk/debug/app-debug.apk

# Ver logs
adb logcat | grep ChalanVoice
```

## ⚠️ Consideraciones de Seguridad

1. **Variables de Entorno:**
   - Nunca commitar archivos .env
   - Usar secrets management en producción
   - Rotar keys periódicamente

2. **Base de Datos:**
   - Usar SSL en producción
   - Configurar backups automáticos
   - Encriptar datos sensibles

3. **Android:**
   - Configurar proguard para release
   - Usar keystore seguro
   - Validar certificados SSL

4. **Audio Processing:**
   - Validar archivos de entrada
   - Limitar tamaños de archivo
   - Implementar rate limiting

## 🆘 Solución de Problemas

### Backend
**Error:** PyTorch con CUDA no funciona
```bash
# Reinstalar PyTorch sin CUDA
pip uninstall torch torchaudio
pip install torch torchaudio --index-url https://download.pytorch.org/whl/cpu
```

**Error:** FFmpeg no encontrado
```bash
# Ubuntu/Debian
sudo apt update && sudo apt install ffmpeg

# macOS
brew install ffmpeg
```

### Android
**Error:** ANDROID_HOME no configurado
```bash
# Agregar a ~/.bashrc o ~/.zshrc
export ANDROID_HOME=$HOME/Android/Sdk
export PATH=$PATH:$ANDROID_HOME/platform-tools
```

**Error:** Gradle daemon issues
```bash
# Limpiar y reiniciar
./gradlew --stop
./gradlew clean
```

## 📚 Recursos Adicionales

- [Documentación FastAPI](https://fastapi.tiangolo.com/)
- [Android Developer Guide](https://developer.android.com/guide)
- [Docker Best Practices](https://docs.docker.com/develop/dev-best-practices/)
- [Git Ignore Templates](https://github.com/github/gitignore)