# 📱 Chalan Voice - Android App Documentation

## 📋 Índice

1. [Arquitectura de la App](#arquitectura-de-la-app)
2. [Configuración de Desarrollo](#configuración-de-desarrollo)
3. [Compilación y Build](#compilación-y-build)
4. [Estructura del Proyecto](#estructura-del-proyecto)
5. [APIs y Servicios](#apis-y-servicios)
6. [Permisos y Seguridad](#permisos-y-seguridad)
7. [Interfaz de Usuario](#interfaz-de-usuario)
8. [Testing](#testing)
9. [Distribución](#distribución)
10. [Troubleshooting](#troubleshooting)

## 🏗️ Arquitectura de la App

### Stack Tecnológico

- **Lenguaje**: Kotlin 100%
- **UI Framework**: Jetpack Compose
- **Arquitectura**: MVVM + Repository Pattern
- **DI**: Hilt (Dagger)
- **Networking**: Retrofit + OkHttp
- **Async**: Coroutines + Flow
- **Navegación**: Navigation Compose
- **Base de Datos**: Room (futuro)
- **Seguridad**: Encrypted SharedPreferences

### Patrones de Diseño

#### MVVM (Model-View-ViewModel)
```
UI Layer (Compose) 
    ↓
ViewModel 
    ↓
Repository 
    ↓
Data Sources (API, Local)
```

#### Dependency Injection con Hilt
```kotlin
@Module
@InstallIn(SingletonComponent::class)
object NetworkModule {
    
    @Provides
    @Singleton
    fun provideRetrofit(): Retrofit {
        return Retrofit.Builder()
            .baseUrl(BuildConfig.API_BASE_URL)
            .addConverterFactory(Json.asConverterFactory("application/json".toMediaType()))
            .addCallAdapterFactory(RetrofitResultCallAdapterFactory())
            .client(provideOkHttp())
            .build()
    }
}
```

## 🛠️ Configuración de Desarrollo

### Prerequisitos

1. **Android Studio** Giraffe (2022.3.1) o superior
2. **JDK 11+**
3. **Android SDK** API 24+ (Android 7.0)
4. **Emulador** o dispositivo físico
5. **Git** para control de versiones

### Instalación

```bash
# 1. Clonar repositorio
git clone https://github.com/tu-usuario/chalan-voice.git
cd chalan-voice/android-app

# 2. Abrir en Android Studio
# File → Open → Seleccionar directorio android-app

# 3. Sincronizar dependencias
./gradlew --refresh-dependencies

# 4. Verificar build
./gradlew build
```

### Configuración del IDE

**Android Studio Settings:**
```xml
<!-- Configuración de formateo automático -->
<!-- File → Settings → Code Style → Kotlin -->
<code_scheme name="Kotlin" version="3">
  <option name="RIGHT_MARGIN" value="120" />
  <option name="FORMATTER_TAGS_ENABLED" value="true" />
</code_scheme>
```

**Archivos de Configuración:**

```gradle
// gradle.properties
org.gradle.jvmargs=-Xmx4096m -Dfile.encoding=UTF-8
org.gradle.parallel=true
org.gradle.caching=true
android.enableR8=true
kotlin.code.style=official
android.nonTransitiveRClass=true
```

## 🔨 Compilación y Build

### Tipos de Build

#### Debug Build
```bash
# Compilar APK debug (rápido, sin optimizar)
./gradlew assembleDebug

# Instalar en dispositivo/emulador
./gradlew installDebug

# Ubicación del APK
# app/build/outputs/apk/debug/app-debug.apk
```

#### Release Build
```bash
# Compilar APK release (optimizado, firmado)
./gradlew assembleRelease

# Ubicación del APK
# app/build/outputs/apk/release/app-release.apk
```

#### App Bundle (AAB)
```bash
# Generar App Bundle para Play Store
./gradlew bundleRelease

# Ubicación del AAB
# app/build/outputs/bundle/release/app-release.aab
```

### Configuración de Signing

#### 1. Generar Keystore
```bash
keytool -genkey -v \
  -keystore chalan-voice.keystore \
  -alias chalan-voice \
  -keyalg RSA \
  -keysize 2048 \
  -validity 10000
```

#### 2. Configurar gradle.properties
```properties
# Keystore
CHALAN_VOICE_UPLOAD_STORE_FILE=chalan-voice.keystore
CHALAN_VOICE_UPLOAD_STORE_PASSWORD=tu_keystore_password
CHALAN_VOICE_UPLOAD_KEY_ALIAS=chalan-voice
CHALAN_VOICE_UPLOAD_KEY_PASSWORD=tu_key_password

# Build Config
CHALAN_VOICE_API_BASE_URL=https://api.chalanvoice.com
CHALAN_VOICE_API_KEY=tu_api_key
```

#### 3. Configurar build.gradle
```gradle
android {
    signingConfigs {
        release {
            if (project.hasProperty('CHALAN_VOICE_UPLOAD_STORE_FILE')) {
                storeFile file(CHALAN_VOICE_UPLOAD_STORE_FILE)
                storePassword CHALAN_VOICE_UPLOAD_STORE_PASSWORD
                keyAlias CHALAN_VOICE_UPLOAD_KEY_ALIAS
                keyPassword CHALAN_VOICE_UPLOAD_KEY_PASSWORD
            }
        }
    }
    
    buildTypes {
        release {
            minifyEnabled true
            shrinkResources true
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
            signingConfig signingConfigs.release
        }
        
        debug {
            debuggable true
            applicationIdSuffix ".debug"
            versionNameSuffix "-debug"
        }
    }
}
```

### Build Variants

```gradle
// Configurar diferentes environments
flavorDimensions "environment"

productFlavors {
    dev {
        dimension "environment"
        applicationId "com.chalanvoice.dev"
        versionName "1.0.0-dev"
        buildConfigField "String", "API_BASE_URL", "\"http://10.0.2.2:8000\""
    }
    
    staging {
        dimension "environment"
        applicationId "com.chalanvoice.staging"
        versionName "1.0.0-staging"
        buildConfigField "String", "API_BASE_URL", "\"https://staging-api.chalanvoice.com\""
    }
    
    prod {
        dimension "environment"
        applicationId "com.chalanvoice"
        versionName "1.0.0"
        buildConfigField "String", "API_BASE_URL", "\"https://api.chalanvoice.com\""
    }
}
```

### Optimizaciones de Build

#### ProGuard/R8 Rules
```proguard
# proguard-rules.pro

# Retain model classes
-keep class com.chalanvoice.data.models.** { *; }
-keep class com.chalanvoice.ui.models.** { *; }

# Retrofit
-dontwarn retrofit2.**
-keep class retrofit2.** { *; }
-keepattributes Signature
-keepattributes Exceptions

# OkHttp
-dontwarn okhttp3.**
-keep class okhttp3.** { *; }
-dontwarn okio.**

# JSON Serialization
-keepattributes Signature
-keepattributes *Annotation*
-dontwarn sun.misc.**
-keep class com.google.gson.** { *; }
-keep class * implements com.google.gson.TypeAdapterFactory
-keep class * implements com.google.gson.JsonSerializer
-keep class * implements com.google.gson.JsonDeserializer

# Keep Compose
-keep class androidx.compose.** { *; }
-dontwarn androidx.compose.**
```

#### Optimización de Recursos
```gradle
android {
    defaultConfig {
        vectorDrawables {
            useSupportLibrary true
        }
    }
    
    packaging {
        resources {
            excludes += [
                'META-INF/DEPENDENCIES',
                'META-INF/LICENSE',
                'META-INF/LICENSE.txt',
                'META-INF/license.txt',
                'META-INF/NOTICE',
                'META-INF/NOTICE.txt',
                'META-INF/notice.txt',
                'META-INF/ASL2.0'
            ]
        }
    }
}
```

## 📁 Estructura del Proyecto

```
android-app/
├── app/
│   ├── src/main/
│   │   ├── AndroidManifest.xml
│   │   ├── java/com/chalanvoice/
│   │   │   ├── ChalanVoiceApp.kt          # Application class
│   │   │   ├── HiltApplication.kt         # Hilt setup
│   │   │   ├── BuildConfig.kt            # Build configuration
│   │   │   │
│   │   │   ├── data/                      # Data Layer
│   │   │   │   ├── api/                   # API Services
│   │   │   │   │   ├── AuthApiService.kt
│   │   │   │   │   ├── TtsApiService.kt
│   │   │   │   │   └── TrainingApiService.kt
│   │   │   │   │
│   │   │   │   ├── repositories/          # Repositories
│   │   │   │   │   ├── AuthRepository.kt
│   │   │   │   │   ├── TtsRepository.kt
│   │   │   │   │   └── TrainingRepository.kt
│   │   │   │   │
│   │   │   │   ├── models/                # Data Models
│   │   │   │   │   ├── ApiModels.kt
│   │   │   │   │   └── DatabaseModels.kt
│   │   │   │   │
│   │   │   │   └── cache/                 # Cache layer
│   │   │   │
│   │   │   ├── di/                        # Dependency Injection
│   │   │   │   ├── AppModule.kt
│   │   │   │   └── NetworkModule.kt
│   │   │   │
│   │   │   ├── ui/                        # UI Layer
│   │   │   │   ├── screens/              # Compose Screens
│   │   │   │   │   ├── welcome/
│   │   │   │   │   │   └── WelcomeScreen.kt
│   │   │   │   │   ├── recording/
│   │   │   │   │   │   └── RecordingScreen.kt
│   │   │   │   │   ├── tts/
│   │   │   │   │   │   └── TtsGeneratorScreen.kt
│   │   │   │   │   ├── training/
│   │   │   │   │   │   └── TrainingScreen.kt
│   │   │   │   │   └── settings/
│   │   │   │   │       └── SettingsScreen.kt
│   │   │   │   │
│   │   │   │   ├── components/           # Reusable Components
│   │   │   │   │   ├── AudioPlayer.kt
│   │   │   │   │   ├── VoiceRecorder.kt
│   │   │   │   │   └── ProgressIndicator.kt
│   │   │   │   │
│   │   │   │   ├── viewmodels/           # ViewModels
│   │   │   │   │   ├── MainViewModel.kt
│   │   │   │   │   ├── RecordingViewModel.kt
│   │   │   │   │   └── TtsViewModel.kt
│   │   │   │   │
│   │   │   │   ├── models/               # UI Models
│   │   │   │   │   ├── MainUiState.kt
│   │   │   │   │   └── ScreenModels.kt
│   │   │   │   │
│   │   │   │   ├── theme/                # Theme & Typography
│   │   │   │   │   ├── Theme.kt
│   │   │   │   │   └── Typography.kt
│   │   │   │   │
│   │   │   │   └── utils/                # Utilities
│   │   │   │       └── Utils.kt
│   │   │   │
│   │   │   ├── services/                  # Android Services
│   │   │   │   └── ForegroundAudioService.kt
│   │   │   │
│   │   │   └── utils/                     # App Utilities
│   │   │       ├── AudioUtils.kt
│   │   │       ├── PermissionUtils.kt
│   │   │       └── FileUtils.kt
│   │   │
│   │   └── res/                           # Resources
│   │       ├── values/
│   │       │   ├── strings.xml
│   │       │   ├── colors.xml
│   │       │   └── dimens.xml
│   │       │
│   │       └── xml/                       # XML configurations
│   │           ├── backup_rules.xml
│   │           ├── data_extraction_rules.xml
│   │           └── file_paths.xml
│   │
│   ├── build.gradle                      # App build configuration
│   └── proguard-rules.pro               # ProGuard rules
│
├── gradle/                              # Gradle wrapper
│   └── wrapper/
│       └── gradle-wrapper.properties
│
├── build.gradle                         # Project build configuration
├── settings.gradle                      # Project settings
└── gradle.properties                    # Gradle properties
```

## 🔌 APIs y Servicios

### Configuración de Red

#### Retrofit Setup
```kotlin
@Module
@InstallIn(SingletonComponent::class)
object NetworkModule {
    
    @Provides
    @Singleton
    fun provideOkHttp(): OkHttpClient {
        val loggingInterceptor = HttpLoggingInterceptor().apply {
            level = if (BuildConfig.DEBUG) {
                HttpLoggingInterceptor.Level.BODY
            } else {
                HttpLoggingInterceptor.Level.NONE
            }
        }
        
        return OkHttpClient.Builder()
            .addInterceptor(loggingInterceptor)
            .addInterceptor(AuthInterceptor())
            .addInterceptor(ErrorInterceptor())
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .writeTimeout(60, TimeUnit.SECONDS)
            .build()
    }
    
    @Provides
    @Singleton
    fun provideRetrofit(okHttpClient: OkHttpClient): Retrofit {
        return Retrofit.Builder()
            .baseUrl(BuildConfig.API_BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(Json.asConverterFactory("application/json".toMediaType()))
            .addCallAdapterFactory(RetrofitResultCallAdapterFactory())
            .build()
    }
}
```

#### API Services

**AuthApiService.kt**
```kotlin
@RetrofitResult
interface AuthApiService {
    
    @POST("api/v1/auth/register")
    suspend fun register(
        @Body request: RegisterRequest
    ): RegisterResponse
    
    @POST("api/v1/auth/login")
    suspend fun login(
        @Body request: LoginRequest
    ): LoginResponse
    
    @GET("api/v1/auth/me")
    suspend fun getCurrentUser(): UserResponse
}
```

**TtsApiService.kt**
```kotlin
@Multipart
@RetrofitResult
interface TtsApiService {
    
    @POST("api/v1/voice/upload-voice")
    suspend fun uploadVoiceSample(
        @Part file: MultipartBody.Part,
        @Part("emotion") emotion: RequestBody
    ): VoiceUploadResponse
    
    @POST("api/v1/voice/generate")
    suspend fun generateAudio(
        @Body request: TtsGenerationRequest
    ): TtsGenerationResponse
    
    @GET("api/v1/voice/download/{generationId}")
    suspend fun downloadAudio(
        @Path("generationId") generationId: String
    ): ResponseBody
}
```

#### Repository Pattern

**TtsRepository.kt**
```kotlin
@Singleton
class TtsRepository @Inject constructor(
    private val ttsApiService: TtsApiService,
    private val audioPlayer: AudioPlayer
) {
    
    suspend fun uploadVoiceSample(
        file: File,
        emotion: String
    ): Resource<VoiceUploadResponse> {
        return safeApiCall {
            val multipartFile = MultipartBody.Part.createFormData(
                "file",
                file.name,
                file.asRequestBody("audio/*".toMediaType())
            )
            
            val emotionPart = emotion.toRequestBody("text/plain".toMediaType())
            
            ttsApiService.uploadVoiceSample(multipartFile, emotionPart)
        }
    }
    
    suspend fun generateAudio(
        text: String,
        voiceSampleId: String,
        emotion: String,
        language: String
    ): Resource<TtsGenerationResponse> {
        return safeApiCall {
            val request = TtsGenerationRequest(
                text = text,
                voice_sample_id = voiceSampleId,
                emotion = emotion,
                language = language
            )
            
            ttsApiService.generateAudio(request)
        }
    }
}
```

### Manejo de Resultados

#### RetrofitResult Wrapper
```kotlin
@Retention(AnnotationRetention.RUNTIME)
@Target(AnnotationTarget.FUNCTION)
annotation class RetrofitResult

sealed class RetrofitResult<out T> {
    data class Success<T>(val data: T) : RetrofitResult<T>()
    data class Error(val exception: Throwable) : RetrofitResult<Nothing>()
    data class NetworkError(val exception: Exception) : RetrofitResult<Nothing>()
}

fun <T> Call<T>.enqueueResult(
    onSuccess: (T) -> Unit,
    onError: (Throwable) -> Unit,
    onNetworkError: (Exception) -> Unit = { }
) {
    enqueue(object : Callback<T> {
        override fun onResponse(call: Call<T>, response: Response<T>) {
            if (response.isSuccessful) {
                response.body()?.let(onSuccess)
            } else {
                onError(HttpException(response))
            }
        }
        
        override fun onFailure(call: Call<T>, t: Throwable) {
            if (t is IOException) {
                onNetworkError(Exception("Network error", t))
            } else {
                onError(t)
            }
        }
    })
}
```

## 🔒 Permisos y Seguridad

### Permisos Requeridos

**AndroidManifest.xml**
```xml
<uses-permission android:name="android.permission.RECORD_AUDIO" />
<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" />
<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" />
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
<uses-permission android:name="android.permission.WAKE_LOCK" />
<uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
<uses-permission android:name="android.permission.VIBRATE" />
```

### Gestión de Permisos

```kotlin
@Composable
fun AudioPermissionHandler(
    onPermissionGranted: () -> Unit,
    onPermissionDenied: () -> Unit
) {
    val audioPermission = rememberPermissionState(Manifest.permission.RECORD_AUDIO)
    
    LaunchedEffect(Unit) {
        if (!audioPermission.status.isGranted) {
            audioPermission.launchPermissionRequest()
        }
    }
    
    DisposableEffect(audioPermission.status) {
        val listener = { status: PermissionStatus ->
            if (status.isGranted) {
                onPermissionGranted()
            } else {
                onPermissionDenied()
            }
        }
        audioPermission.addListener(listener)
        
        onDispose {
            audioPermission.removeListener(listener)
        }
    }
}
```

### Seguridad de Datos

#### Encrypted SharedPreferences
```kotlin
@Module
@InstallIn(SingletonComponent::class)
object SecurityModule {
    
    @Provides
    @Singleton
    fun provideMasterKey(): MasterKey {
        return MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
    }
    
    @Provides
    @Singleton
    fun provideEncryptedPreferences(
        context: Context,
        masterKey: MasterKey
    ): SharedPreferences {
        return EncryptedSharedPreferences.create(
            context,
            "chalan_voice_prefs",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }
}
```

#### Token Management
```kotlin
@Singleton
class AuthTokenManager @Inject constructor(
    @ApplicationContext private val context: Context,
    private val encryptedPrefs: SharedPreferences
) {
    
    companion object {
        private const val TOKEN_KEY = "access_token"
        private const val TOKEN_EXPIRY_KEY = "token_expiry"
    }
    
    fun saveToken(token: String, expiryTime: Long) {
        encryptedPrefs.edit()
            .putString(TOKEN_KEY, token)
            .putLong(TOKEN_EXPIRY_KEY, expiryTime)
            .apply()
    }
    
    fun getToken(): String? {
        return encryptedPrefs.getString(TOKEN_KEY, null)
    }
    
    fun isTokenValid(): Boolean {
        val token = getToken() ?: return false
        val expiryTime = encryptedPrefs.getLong(TOKEN_EXPIRY_KEY, 0)
        return System.currentTimeMillis() < expiryTime
    }
    
    fun clearToken() {
        encryptedPrefs.edit()
            .remove(TOKEN_KEY)
            .remove(TOKEN_EXPIRY_KEY)
            .apply()
    }
}
```

## 🎨 Interfaz de Usuario

### Compose Components

#### AudioPlayer Component
```kotlin
@Composable
fun AudioPlayer(
    audioFile: File,
    onPlayPause: () -> Unit,
    isPlaying: Boolean,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = if (isPlaying) "Pausar" else "Reproducir",
                    modifier = Modifier
                        .size(48.dp)
                        .clickable { onPlayPause() }
                        .padding(8.dp)
                )
                
                Spacer(modifier = Modifier.width(16.dp))
                
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = audioFile.name,
                        style = MaterialTheme.typography.titleMedium
                    )
                    
                    val duration = rememberAudioDuration(audioFile)
                    Text(
                        text = "Duración: ${duration}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            
            // Waveform visualization
            WaveformVisualization(
                audioFile = audioFile,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(60.dp)
                    .padding(top = 8.dp)
            )
        }
    }
}
```

#### VoiceRecorder Component
```kotlin
@Composable
fun VoiceRecorder(
    onRecordingStarted: () -> Unit,
    onRecordingStopped: (File) -> Unit,
    modifier: Modifier = Modifier
) {
    var isRecording by remember { mutableStateOf(false) }
    var recordingTime by remember { mutableStateOf(0L) }
    
    val recorder = remember { AudioRecorder() }
    
    LaunchedEffect(isRecording) {
        if (isRecording) {
            onRecordingStarted()
            recorder.startRecording { time ->
                recordingTime = time
            }
        } else {
            val recordedFile = recorder.stopRecording()
            onRecordingStopped(recordedFile)
        }
    }
    
    Card(
        modifier = modifier,
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(24.dp)
        ) {
            // Recording indicator
            if (isRecording) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(bottom = 16.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(12.dp)
                            .background(
                                color = MaterialTheme.colorScheme.error,
                                shape = CircleShape
                            )
                    )
                    
                    Spacer(modifier = Modifier.width(8.dp))
                    
                    Text(
                        text = formatRecordingTime(recordingTime),
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.error
                    )
                }
            }
            
            // Record button
            IconButton(
                onClick = { isRecording = !isRecording },
                modifier = Modifier.size(80.dp)
            ) {
                Icon(
                    imageVector = if (isRecording) Icons.Default.Stop else Icons.Default.Mic,
                    contentDescription = if (isRecording) "Detener grabación" else "Iniciar grabación",
                    modifier = Modifier.size(48.dp),
                    tint = if (isRecording) {
                        MaterialTheme.colorScheme.error
                    } else {
                        MaterialTheme.colorScheme.primary
                    }
                )
            }
            
            Text(
                text = if (isRecording) "Presiona para detener" else "Presiona para grabar",
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(top = 8.dp)
            )
        }
    }
}
```

### Navigation

#### Navigation Graph
```kotlin
@Composable
fun ChalanVoiceNavigation() {
    val navController = rememberNavController()
    
    NavHost(
        navController = navController,
        startDestination = ChalanVoiceScreens.Welcome.route
    ) {
        composable(
            route = ChalanVoiceScreens.Welcome.route
        ) {
            WelcomeScreen(
                onGetStarted = {
                    navController.navigate(ChalanVoiceScreens.Recording.route)
                },
                onLogin = {
                    navController.navigate(ChalanVoiceScreens.Auth.route)
                }
            )
        }
        
        composable(
            route = ChalanVoiceScreens.Recording.route
        ) {
            RecordingScreen(
                onRecordingComplete = { voiceSampleId ->
                    navController.navigate("${ChalanVoiceScreens.Tts.route}/$voiceSampleId")
                },
                onBack = {
                    navController.popBackStack()
                }
            )
        }
        
        composable(
            route = "${ChalanVoiceScreens.Tts.route}/{voiceSampleId}"
        ) { backStackEntry ->
            val voiceSampleId = backStackEntry.arguments?.getString("voiceSampleId") ?: ""
            
            TtsGeneratorScreen(
                voiceSampleId = voiceSampleId,
                onBack = {
                    navController.popBackStack()
                },
                onGenerationComplete = {
                    navController.navigate(ChalanVoiceScreens.Player.route)
                }
            )
        }
        
        composable(
            route = ChalanVoiceScreens.Player.route
        ) {
            AudioPlayerScreen(
                onBack = {
                    navController.popBackStack()
                }
            )
        }
    }
}

sealed class ChalanVoiceScreens(val route: String) {
    object Welcome : ChalanVoiceScreens("welcome")
    object Recording : ChalanVoiceScreens("recording")
    object Tts : ChalanVoiceScreens("tts")
    object Player : ChalanVoiceScreens("player")
    object Training : ChalanVoiceScreens("training")
    object Settings : ChalanVoiceScreens("settings")
    object Auth : ChalanVoiceScreens("auth")
}
```

## 🧪 Testing

### Unit Testing

```kotlin
@RunWith(AndroidJUnit4::class)
class TtsRepositoryTest {
    
    @get:Rule
    val coroutinesRule = MainCoroutineRule()
    
    @get:Rule
    val instantTaskExecutorRule = InstantTaskExecutorRule()
    
    private lateinit var repository: TtsRepository
    private lateinit var mockApiService: TtsApiService
    
    @Before
    fun setup() {
        mockApiService = mockk()
        repository = TtsRepository(mockApiService, mockk())
    }
    
    @Test
    fun `uploadVoiceSample should return success`() = runTest {
        // Given
        val file = File.createTempFile("test", ".wav")
        val expectedResponse = VoiceUploadResponse("sample_id")
        
        coEvery {
            mockApiService.uploadVoiceSample(any(), any())
        } returns expectedResponse
        
        // When
        val result = repository.uploadVoiceSample(file, "neutral")
        
        // Then
        assertTrue(result is Resource.Success)
        assertEquals("sample_id", (result as Resource.Success).data.id)
        
        coVerify {
            mockApiService.uploadVoiceSample(any(), any())
        }
    }
}
```

### UI Testing

```kotlin
@Test
fun testVoiceRecordingFlow() {
    composeTestRule.setContent {
        RecordingScreen(
            onRecordingComplete = { voiceSampleId ->
                // Test navigation after recording
            }
        )
    }
    
    // Test UI elements
    composeTestRule
        .onNodeWithText("Presiona para grabar")
        .assertIsDisplayed()
    
    // Test recording
    composeTestRule
        .onNodeWithContentDescription("Iniciar grabación")
        .performClick()
    
    composeTestRule
        .onNodeWithText("Presiona para detener")
        .assertIsDisplayed()
}
```

### Integration Testing

```kotlin
@HiltAndroidTest
class TtsIntegrationTest {
    
    @get:Rule
    val hiltRule = HiltAndroidRule(this)
    
    @get:Rule
    val composeTestRule = createAndroidComposeRule<MainActivity>()
    
    @Inject
    lateinit var repository: TtsRepository
    
    @Before
    fun setup() {
        hiltRule.inject()
    }
    
    @Test
    fun testCompleteTtsFlow() = runTest {
        // 1. Upload voice sample
        val file = createTestAudioFile()
        val uploadResult = repository.uploadVoiceSample(file, "neutral")
        assertTrue(uploadResult is Resource.Success)
        
        val voiceSampleId = (uploadResult as Resource.Success).data.id
        
        // 2. Generate TTS
        val generationResult = repository.generateAudio(
            text = "Hola, esta es una prueba",
            voiceSampleId = voiceSampleId,
            emotion = "neutral",
            language = "es"
        )
        assertTrue(generationResult is Resource.Success)
        
        // 3. Verify generation
        val generation = (generationResult as Resource.Success).data
        assertEquals("processing", generation.status)
    }
}
```

## 📦 Distribución

### Google Play Store

#### 1. Preparación para Release

```bash
# 1. Actualizar versión
# app/build.gradle
android {
    defaultConfig {
        versionCode 1          // Incrementar para cada release
        versionName "1.0.0"    // Versión visible al usuario
    }
}

# 2. Limpiar y build
./gradlew clean bundleRelease

# 3. Verificar bundle
bundletool build-apks --bundle=app-release.aab --output=app.apks
```

#### 2. Play Console Steps

1. **Crear aplicación** en Google Play Console
2. **Subir App Bundle** (AAB) generado
3. **Configurar información** de la app:
   - Título y descripción
   - Screenshots y videos
   - Categoría y contenido
4. **Configurar pricing** y distribución
5. **Revisar y publicar**

#### 3. Store Listing

```xml
<!-- strings.xml - Contenido para la tienda -->
<string name="app_description">
    🎤 Chalan Voice - Clonación de Voz con IA

    Revoluciona tu forma de crear contenido de audio con tecnología avanzada de clonación de voz.

    ✨ Características principales:
    • 🎯 Clonación de voz en segundos
    • 🌍 Soporte para 17 idiomas
    • 🎭 Transferencia de emociones
    • 🔒 Watermarking para protección
    • 📱 Interfaz moderna y fácil de usar

    🎬 Perfecto para:
    • Creadores de contenido
    • Podcasters y YouTubers
    • Desarrolladores de aplicaciones
    • Profesionales de marketing

    🔐 Tu privacidad es nuestra prioridad. Todos los datos se procesan de forma segura.

    ¡Descarga ahora y comienza a crear!
</string>

<string name="short_description">
    Clonación de voz avanzada con IA - Soporte multilingüe y transferencia emocional
</string>
```

### Firebase App Distribution

```bash
# 1. Configurar Firebase
firebase init appdistribution

# 2. Build release
./gradlew assembleRelease

# 3. Subir a Firebase
firebase appdistribution:distribute \
  app/build/outputs/apk/release/app-release.apk \
  --app 1:123456789:android:abcd1234 \
  --groups "testers,qa-team" \
  --release-notes "Nueva versión con mejoras de rendimiento"
```

### Direct APK Distribution

```bash
# 1. Generar APK firmado
./gradlew assembleRelease

# 2. Verificar APK
jarsigner -verify -verbose app-release.apk

# 3. Optimizar APK
zipalign -v 4 app-release.apk chalan-voice-optimized.apk

# 4. Generar checksums
sha256sum chalan-voice-optimized.apk > chalan-voice.apk.sha256
```

## 🔧 Troubleshooting

### Problemas Comunes

#### 1. Build Failed - Dependencies

**Error:**
```
Execution failed for task ':app:processDebugResources'.
> A failure occurred while executing com.android.build.gradle.internal.res.LinkApplicationAndroidResourcesTask
   Could not resolve all files for configuration ':app:debugRuntimeClasspath'.
```

**Solución:**
```bash
# Limpiar dependencias
./gradlew clean
./gradlew --refresh-dependencies

# Invalidar caches de Android Studio
# File → Invalidate Caches and Restart

# Verificar versions
./gradlew app:dependencies
```

#### 2. ProGuard Issues

**Error:**
```
java.lang.RuntimeException: Parcelable encountered IOException writing serializable object
```

**Solución:**
```proguard
# proguard-rules.pro

# Keep Parcelable implementations
-keepclassmembers class * implements android.os.Parcelable {
  public static final android.os.Parcelable$Creator CREATOR;
}

# Keep data classes
-keep class com.chalanvoice.data.models.** { *; }
-keep class com.chalanvoice.ui.models.** { *; }
```

#### 3. Permission Issues

**Error:**
```
SecurityException: Permission Denial: recording from microphone not allowed
```

**Solución:**
```kotlin
// Verificar y solicitar permisos
val audioPermission = rememberPermissionState(Manifest.permission.RECORD_AUDIO)

LaunchedEffect(audioPermission) {
    if (!audioPermission.status.isGranted) {
        audioPermission.launchPermissionRequest()
    }
}

// Verificar en runtime
if (ContextCompat.checkSelfPermission(
        context,
        Manifest.permission.RECORD_AUDIO
    ) == PackageManager.PERMISSION_GRANTED
) {
    // Proceder con grabación
}
```

#### 4. Network Issues

**Error:**
```
java.net.SocketTimeoutException: timeout
```

**Solución:**
```kotlin
// Aumentar timeouts en NetworkModule
@Provides
@Singleton
fun provideOkHttp(): OkHttpClient {
    return OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()
}
```

### Debug Tools

#### Network Inspection
```kotlin
// Habilitar logging detallado en debug
class NetworkLogger : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val request = chain.request()
        val startTime = System.currentTimeMillis()
        
        val response = chain.proceed(request)
        val endTime = System.currentTimeMillis()
        
        Log.d("Network", """
            ${request.method} ${request.url}
            Response: ${response.code} (${endTime - startTime}ms)
            Headers: ${response.headers}
        """.trimIndent())
        
        return response
    }
}
```

#### Performance Monitoring
```kotlin
@Composable
fun PerformanceMonitor() {
    val memoryInfo = remember { ActivityManager.MemoryInfo() }
    val activityManager = LocalContext.current.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    
    LaunchedEffect(Unit) {
        while (true) {
            activityManager.getMemoryInfo(memoryInfo)
            Log.d("Memory", """
                Available: ${memoryInfo.availMem / 1024 / 1024} MB
                Total: ${memoryInfo.totalMem / 1024 / 1024} MB
                Low: ${memoryInfo.lowMemory}
            """.trimIndent())
            delay(5000)
        }
    }
}
```

#### Audio Debug Utilities
```kotlin
object AudioDebugUtils {
    fun logAudioFileInfo(file: File) {
        val mediaPlayer = MediaPlayer()
        try {
            mediaPlayer.setDataSource(file.absolutePath)
            mediaPlayer.prepare()
            
            Log.d("AudioDebug", """
                File: ${file.name}
                Duration: ${mediaPlayer.duration}ms
                Current position: ${mediaPlayer.currentPosition}ms
                Is playing: ${mediaPlayer.isPlaying}
                Audio session ID: ${mediaPlayer.audioSessionId}
            """.trimIndent())
        } finally {
            mediaPlayer.release()
        }
    }
}
```

---

**Chalan Voice Android** - Documentación completa de la aplicación 📱🚀

*Para soporte técnico, consulta el [README principal](../README.md) o abre un issue en GitHub.*