/*
 * Este archivo BuildConfig se generará automáticamente por Gradle
 * Mantener solo para referencia de estructura
 */

package com.chalanvoice

object BuildConfig {
    const val DEBUG: Boolean = true // Será true en debug, false en release
    const val BUILD_TYPE: String = "debug"
    const val VERSION_CODE: Int = 1
    const val VERSION_NAME: String = "1.0.0"
}