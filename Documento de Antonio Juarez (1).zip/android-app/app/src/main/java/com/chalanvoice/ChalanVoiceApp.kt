package com.chalanvoice

import android.app.Application
import dagger.hilt.android.HiltAndroidApp
import timber.log.Timber

/**
 * Clase principal de la aplicación Chalan Voice.
 * Configura Hilt para inyección de dependencias y Timber para logging.
 */
@HiltAndroidApp
class ChalanVoiceApp : Application() {
    
    override fun onCreate() {
        super.onCreate()
        
        // Configurar Timber para logging en modo debug
        if (BuildConfig.DEBUG) {
            Timber.plant(Timber.DebugTree())
        } else {
            // En producción, usar un tree que envíe logs a un servicio de monitoreo
            Timber.plant(ProductionTree())
        }
        
        Timber.d("ChalanVoiceApp inicializada")
    }
}

/**
 * Tree de logging para producción que puede enviar logs a servicios de monitoreo
 */
private class ProductionTree : Timber.Tree() {
    override fun log(priority: Int, tag: String?, message: String, t: Throwable?) {
        // Aquí se puede integrar con servicios como Crashlytics, LogRocket, etc.
        // Por ahora solo loguea a consola
        if (priority >= android.util.Log.WARN) {
            android.util.Log.println(priority, "ChalanVoice", message)
        }
    }
}