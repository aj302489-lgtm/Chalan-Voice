package com.chalanvoice.data.api

import com.chalanvoice.ui.models.ApiResponse
import com.chalanvoice.ui.models.UserInfo
import retrofit2.Response
import retrofit2.http.*

/**
 * Servicios API para autenticación y gestión de usuarios
 */
interface AuthApiService {
    
    /**
     * Inicia sesión del usuario
     */
    @POST("/api/auth/login")
    suspend fun login(
        @Body request: LoginRequest
    ): Response<ApiResponse<AuthResponse>>
    
    /**
     * Registra un nuevo usuario
     */
    @POST("/api/auth/register")
    suspend fun register(
        @Body request: RegisterRequest
    ): Response<ApiResponse<AuthResponse>>
    
    /**
     * Cierra la sesión del usuario
     */
    @POST("/api/auth/logout")
    suspend fun logout(
        @Header("Authorization") auth: String
    ): Response<ApiResponse<Boolean>>
    
    /**
     * Refresca el token de autenticación
     */
    @POST("/api/auth/refresh")
    suspend fun refreshToken(
        @Body request: RefreshTokenRequest
    ): Response<ApiResponse<AuthResponse>>
    
    /**
     * Obtiene información del usuario actual
     */
    @GET("/api/auth/me")
    suspend fun getCurrentUser(
        @Header("Authorization") auth: String
    ): Response<ApiResponse<UserInfo>>
    
    /**
     * Actualiza información del usuario
     */
    @PUT("/api/auth/profile")
    suspend fun updateProfile(
        @Body request: UpdateProfileRequest,
        @Header("Authorization") auth: String
    ): Response<ApiResponse<UserInfo>>
    
    /**
     * Elimina la cuenta del usuario
     */
    @DELETE("/api/auth/account")
    suspend fun deleteAccount(
        @Header("Authorization") auth: String
    ): Response<ApiResponse<Boolean>>
    
    /**
     * Cambia la contraseña del usuario
     */
    @POST("/api/auth/change-password")
    suspend fun changePassword(
        @Body request: ChangePasswordRequest,
        @Header("Authorization") auth: String
    ): Response<ApiResponse<Boolean>>
    
    /**
     * Envía email de recuperación de contraseña
     */
    @POST("/api/auth/forgot-password")
    suspend fun forgotPassword(
        @Body request: ForgotPasswordRequest
    ): Response<ApiResponse<Boolean>>
    
    /**
     * Verifica el token de autenticación
     */
    @GET("/api/auth/verify")
    suspend fun verifyToken(
        @Header("Authorization") auth: String
    ): Response<ApiResponse<Boolean>>
}

/**
 * Clases de datos para las requests
 */
@kotlinx.serialization.Serializable
data class LoginRequest(
    val email: String,
    val password: String,
    val rememberMe: Boolean = false
)

@kotlinx.serialization.Serializable
data class RegisterRequest(
    val email: String,
    val password: String,
    val confirmPassword: String,
    val name: String
)

@kotlinx.serialization.Serializable
data class RefreshTokenRequest(
    val refreshToken: String
)

@kotlinx.serialization.Serializable
data class UpdateProfileRequest(
    val name: String? = null,
    val email: String? = null,
    val preferences: Map<String, Any>? = null
)

@kotlinx.serialization.Serializable
data class ChangePasswordRequest(
    val currentPassword: String,
    val newPassword: String,
    val confirmPassword: String
)

@kotlinx.serialization.Serializable
data class ForgotPasswordRequest(
    val email: String
)

/**
 * Respuesta de autenticación
 */
@kotlinx.serialization.Serializable
data class AuthResponse(
    val user: UserInfo,
    val accessToken: String,
    val refreshToken: String,
    val expiresIn: Long,
    val tokenType: String = "Bearer"
)