package com.chalanvoice.data.api

import com.chalanvoice.ui.models.ApiResponse
import com.chalanvoice.ui.models.TrainingResponse
import com.chalanvoice.ui.models.TtsResponse
import kotlinx.serialization.Serializable
import retrofit2.Response
import retrofit2.http.*

/**
 * Servicios API para el entrenamiento de modelos de voz
 */
interface TrainingApiService {
    
    /**
     * Inicia el proceso de entrenamiento con una grabación
     */
    @POST("/api/training/start")
    suspend fun startTraining(
        @Body request: Map<String, String>,
        @Header("Authorization") auth: String
    ): Response<ApiResponse<TrainingResponse>>
    
    /**
     * Consulta el estado de un entrenamiento
     */
    @GET("/api/training/status/{modelId}")
    suspend fun getTrainingStatus(
        @Path("modelId") modelId: String,
        @Header("Authorization") auth: String
    ): Response<ApiResponse<TrainingResponse>>
    
    /**
     * Obtiene la URL de descarga del modelo entrenado
     */
    @GET("/api/training/download/{modelId}")
    suspend fun getModelDownloadUrl(
        @Path("modelId") modelId: String,
        @Header("Authorization") auth: String
    ): Response<ApiResponse<String>>
    
    /**
     * Obtiene la lista de modelos del usuario
     */
    @GET("/api/training/models")
    suspend fun getUserModels(
        @Header("Authorization") auth: String
    ): Response<ApiResponse<List<String>>>
    
    /**
     * Elimina el modelo del usuario
     */
    @DELETE("/api/training/models")
    suspend fun deleteUserModel(
        @Header("Authorization") auth: String
    ): Response<ApiResponse<Boolean>>
    
    /**
     * Obtiene estadísticas del modelo
     */
    @GET("/api/training/stats/{modelId}")
    suspend fun getModelStats(
        @Path("modelId") modelId: String,
        @Header("Authorization") auth: String
    ): Response<ApiResponse<Map<String, Any>>>
    
    /**
     * Sube el archivo de audio para entrenamiento
     */
    @Multipart
    @POST("/api/training/upload")
    suspend fun uploadAudioFile(
        @Part("audioFile") audioFile: retrofit2.http.MultipartBody.Part,
        @Part("metadata") metadata: Map<String, String>,
        @Header("Authorization") auth: String
    ): Response<ApiResponse<String>>
}