package com.chalanvoice.data.api

import com.chalanvoice.ui.models.ApiResponse
import com.chalanvoice.ui.models.TtsResponse
import retrofit2.Response
import retrofit2.http.*

/**
 * Servicios API para síntesis de texto a voz
 */
interface TtsApiService {
    
    /**
     * Genera voz a partir de texto usando el modelo del usuario
     */
    @POST("/api/tts/generate")
    suspend fun generateVoice(
        @Body request: Map<String, Any>,
        @Header("Authorization") auth: String
    ): Response<ApiResponse<TtsResponse>>
    
    /**
     * Verifica si el usuario tiene un modelo entrenado
     */
    @GET("/api/tts/check-model")
    suspend fun checkUserModel(
        @Header("Authorization") auth: String
    ): Response<ApiResponse<Boolean>>
    
    /**
     * Descarga el audio generado
     */
    @GET("/api/tts/download/{audioId}")
    suspend fun downloadAudio(
        @Path("audioId") audioId: String,
        @Header("Authorization") auth: String
    ): Response<retrofit2.http.ResponseBody>
    
    /**
     * Obtiene el historial de audios generados por el usuario
     */
    @GET("/api/tts/history")
    suspend fun getAudioHistory(
        @Query("limit") limit: Int = 50,
        @Query("offset") offset: Int = 0,
        @Header("Authorization") auth: String
    ): Response<ApiResponse<List<TtsResponse>>>
    
    /**
     * Elimina un audio generado
     */
    @DELETE("/api/tts/audio/{audioId}")
    suspend fun deleteAudio(
        @Path("audioId") audioId: String,
        @Header("Authorization") auth: String
    ): Response<ApiResponse<Boolean>>
    
    /**
     * Obtiene información sobre el servicio TTS
     */
    @GET("/api/tts/info")
    suspend fun getServiceInfo(): Response<ApiResponse<Map<String, Any>>>
    
    /**
     * Verifica el estado del servicio TTS
     */
    @GET("/api/tts/status")
    suspend fun checkStatus(): Response<ApiResponse<Map<String, String>>>
    
    /**
     * Obtiene las emociones disponibles
     */
    @GET("/api/tts/emotions")
    suspend fun getAvailableEmotions(): Response<ApiResponse<List<Map<String, String>>>>
    
    /**
     * Genera múltiples versiones del mismo texto
     */
    @POST("/api/tts/generate-batch")
    suspend fun generateBatchVoice(
        @Body request: Map<String, Any>,
        @Header("Authorization") auth: String
    ): Response<ApiResponse<List<TtsResponse>>>
}