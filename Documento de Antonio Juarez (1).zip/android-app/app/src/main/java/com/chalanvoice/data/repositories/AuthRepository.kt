package com.chalanvoice.data.repositories

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.chalanvoice.ui.models.UserInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Repositorio para manejo de autenticación y configuración de usuario
 * Utiliza EncryptedSharedPreferences para almacenamiento seguro
 */
@Singleton
class AuthRepository @Inject constructor(
    private val context: Context
) {
    
    companion object {
        private const val PREFS_NAME = "chalan_voice_auth"
        private const val PREFS_NAME_ENC = "chalan_voice_encrypted_prefs"
        private const val KEY_TOKEN = "auth_token"
        private const val KEY_USER_ID = "user_id"
        private const val KEY_EMAIL = "email"
        private const val KEY_HAS_ACCEPTED_ETHICS = "has_accepted_ethics"
        private const val KEY_DARK_THEME = "dark_theme"
        private const val KEY_IS_LOGGED_IN = "is_logged_in"
    }
    
    // Instancia segura para preferencias encriptadas
    private val masterKey by lazy {
        MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
    }
    
    private val encryptedPrefs by lazy {
        EncryptedSharedPreferences.create(
            context,
            PREFS_NAME_ENC,
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }
    
    // Preferencias normales para datos no sensibles
    private val normalPrefs by lazy {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    /**
     * Verifica si el usuario está autenticado
     */
    suspend fun isAuthenticated(): Boolean = withContext(Dispatchers.IO) {
        try {
            val token = encryptedPrefs.getString(KEY_TOKEN, null)
            val isLoggedIn = normalPrefs.getBoolean(KEY_IS_LOGGED_IN, false)
            
            val authenticated = !token.isNullOrEmpty() && isLoggedIn
            Timber.d("Estado de autenticación: $authenticated")
            
            return@withContext authenticated
        } catch (e: Exception) {
            Timber.e(e, "Error verificando autenticación")
            return@withContext false
        }
    }

    /**
     * Obtiene la información del usuario actual
     */
    suspend fun getUserInfo(): UserInfo? = withContext(Dispatchers.IO) {
        try {
            if (!isAuthenticated()) {
                return@withContext null
            }
            
            val userId = encryptedPrefs.getString(KEY_USER_ID, null)
            val email = encryptedPrefs.getString(KEY_EMAIL, null)
            
            if (userId.isNullOrEmpty() || email.isNullOrEmpty()) {
                Timber.w("Datos de usuario incompletos")
                return@withContext null
            }
            
            // Aquí normalmente cargaríamos más datos del servidor
            // Por simplicidad, devolvemos datos básicos
            return@withContext UserInfo(
                userId = userId,
                email = email,
                modelTrained = false, // TODO: Cargar desde servidor
                modelId = null
            )
            
        } catch (e: Exception) {
            Timber.e(e, "Error obteniendo información del usuario")
            return@withContext null
        }
    }

    /**
     * Inicia sesión del usuario
     */
    suspend fun login(email: String, password: String): UserInfo = withContext(Dispatchers.IO) {
        try {
            Timber.d("Iniciando login para: $email")
            
            // TODO: Reemplazar con llamada real al servidor
            // Por ahora, simulamos la autenticación
            val userId = "user_${System.currentTimeMillis()}"
            val token = "jwt_token_${System.currentTimeMillis()}"
            
            // Guardar credenciales de forma segura
            encryptedPrefs.edit().apply {
                putString(KEY_TOKEN, token)
                putString(KEY_USER_ID, userId)
                putString(KEY_EMAIL, email)
                apply()
            }
            
            // Marcar como logueado
            normalPrefs.edit().putBoolean(KEY_IS_LOGGED_IN, true).apply()
            
            val userInfo = UserInfo(
                userId = userId,
                email = email,
                modelTrained = false,
                modelId = null
            )
            
            Timber.d("Login exitoso para: $email")
            return@withContext userInfo
            
        } catch (e: Exception) {
            Timber.e(e, "Error en login")
            throw AuthenticationException("Error de autenticación: ${e.message}")
        }
    }

    /**
     * Cierra la sesión del usuario
     */
    suspend fun logout() = withContext(Dispatchers.IO) {
        try {
            // Limpiar todas las credenciales
            encryptedPrefs.edit().clear().apply()
            normalPrefs.edit().clear().apply()
            
            Timber.d("Logout exitoso")
            
        } catch (e: Exception) {
            Timber.e(e, "Error en logout")
            throw AuthenticationException("Error cerrando sesión: ${e.message}")
        }
    }

    /**
     * Registra un nuevo usuario
     */
    suspend fun register(email: String, password: String): UserInfo = withContext(Dispatchers.IO) {
        try {
            Timber.d("Registrando usuario: $email")
            
            // TODO: Implementar registro real con servidor
            // Por ahora, simulamos el registro
            val userId = "user_${System.currentTimeMillis()}"
            val token = "jwt_token_${System.currentTimeMillis()}"
            
            encryptedPrefs.edit().apply {
                putString(KEY_TOKEN, token)
                putString(KEY_USER_ID, userId)
                putString(KEY_EMAIL, email)
                apply()
            }
            
            normalPrefs.edit().putBoolean(KEY_IS_LOGGED_IN, true).apply()
            
            val userInfo = UserInfo(
                userId = userId,
                email = email,
                modelTrained = false
            )
            
            Timber.d("Registro exitoso para: $email")
            return@withContext userInfo
            
        } catch (e: Exception) {
            Timber.e(e, "Error en registro")
            throw AuthenticationException("Error en registro: ${e.message}")
        }
    }

    /**
     * Verifica si el usuario ha aceptado los términos éticos
     */
    suspend fun hasAcceptedEthics(): Boolean = withContext(Dispatchers.IO) {
        try {
            return@withContext normalPrefs.getBoolean(KEY_HAS_ACCEPTED_ETHICS, false)
        } catch (e: Exception) {
            Timber.e(e, "Error verificando aceptación ética")
            return@withContext false
        }
    }

    /**
     * Establece si el usuario ha aceptado los términos éticos
     */
    suspend fun setEthicsAccepted(accepted: Boolean) = withContext(Dispatchers.IO) {
        try {
            normalPrefs.edit().putBoolean(KEY_HAS_ACCEPTED_ETHICS, accepted).apply()
            Timber.d("Términos éticos aceptados: $accepted")
        } catch (e: Exception) {
            Timber.e(e, "Error guardando aceptación ética")
        }
    }

    /**
     * Verifica si el tema oscuro está activado
     */
    suspend fun isDarkTheme(): Boolean = withContext(Dispatchers.IO) {
        try {
            return@withContext normalPrefs.getBoolean(KEY_DARK_THEME, true) // Por defecto oscuro
        } catch (e: Exception) {
            Timber.e(e, "Error verificando tema")
            return@withContext true
        }
    }

    /**
     * Establece el tema de la aplicación
     */
    suspend fun setDarkTheme(isDark: Boolean) = withContext(Dispatchers.IO) {
        try {
            normalPrefs.edit().putBoolean(KEY_DARK_THEME, isDark).apply()
            Timber.d("Tema establecido: ${if (isDark) "Oscuro" else "Claro"}")
        } catch (e: Exception) {
            Timber.e(e, "Error estableciendo tema")
        }
    }

    /**
     * Obtiene el token JWT actual
     */
    suspend fun getAuthToken(): String? = withContext(Dispatchers.IO) {
        try {
            return@withContext encryptedPrefs.getString(KEY_TOKEN, null)
        } catch (e: Exception) {
            Timber.e(e, "Error obteniendo token")
            return@withContext null
        }
    }

    /**
     * Refresca el token de autenticación
     */
    suspend fun refreshToken(): Boolean = withContext(Dispatchers.IO) {
        try {
            val currentToken = encryptedPrefs.getString(KEY_TOKEN, null)
            
            if (currentToken.isNullOrEmpty()) {
                Timber.w("No hay token para refrescar")
                return@withContext false
            }
            
            // TODO: Implementar refresh real con el servidor
            val newToken = "jwt_token_${System.currentTimeMillis()}"
            
            encryptedPrefs.edit().putString(KEY_TOKEN, newToken).apply()
            
            Timber.d("Token refrescado exitosamente")
            return@withContext true
            
        } catch (e: Exception) {
            Timber.e(e, "Error refrescando token")
            return@withContext false
        }
    }

    /**
     * Verifica si el token actual es válido
     */
    suspend fun isTokenValid(): Boolean = withContext(Dispatchers.IO) {
        try {
            val token = getAuthToken()
            
            if (token.isNullOrEmpty()) {
                return@withContext false
            }
            
            // TODO: Implementar validación real del token JWT
            // Por ahora, asumimos que es válido si existe
            return@withContext true
            
        } catch (e: Exception) {
            Timber.e(e, "Error validando token")
            return@withContext false
        }
    }
}

/**
 * Excepción personalizada para errores de autenticación
 */
class AuthenticationException(message: String) : Exception(message)