package com.chalanvoice.data.repositories

import android.content.Context
import android.media.MediaRecorder
import android.os.Environment
import android.util.Log
import com.chalanvoice.ui.models.AudioRecording
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withContext
import timber.log.Timber
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Repositorio para manejo de grabaciones de audio
 * Utiliza MediaRecorder para capturar audio del micrófono
 */
@Singleton
class RecordingRepository @Inject constructor(
    private val context: Context
) {
    
    companion object {
        private const val TAG = "RecordingRepository"
        private const val AUDIO_RECORDINGS_DIR = "ChalanVoice/Audios"
        private const val TEMP_RECORDINGS_DIR = "ChalanVoice/Temp"
        private const val MAX_RECORDING_DURATION = 5 * 60 * 1000L // 5 minutos
        private const val SAMPLE_RATE = 44100
        private const val AUDIO_FORMAT = MediaRecorder.OutputFormat.THREE_GPP
        private const val AUDIO_ENCODER = MediaRecorder.AudioEncoder.AMR_NB
    }
    
    private var mediaRecorder: MediaRecorder? = null
    private var currentRecordingFile: File? = null
    private var isRecording = false
    private var recordingStartTime = 0L
    private val audioRecordings = mutableListOf<AudioRecording>()

    /**
     * Obtiene el directorio para grabaciones de audio
     */
    private fun getAudioDirectory(): File {
        val audioDir = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC),
            AUDIO_RECORDINGS_DIR
        )
        
        if (!audioDir.exists()) {
            audioDir.mkdirs()
        }
        
        return audioDir
    }

    /**
     * Obtiene el directorio temporal para grabaciones
     */
    private fun getTempDirectory(): File {
        val tempDir = File(context.cacheDir, TEMP_RECORDINGS_DIR)
        
        if (!tempDir.exists()) {
            tempDir.mkdirs()
        }
        
        return tempDir
    }

    /**
     * Inicia una nueva grabación de audio
     */
    suspend fun startRecording(): AudioRecording = withContext(Dispatchers.Main) {
        try {
            if (isRecording) {
                throw RecordingException("Ya hay una grabación en curso")
            }

            Timber.d("Iniciando grabación de audio")
            
            // Crear archivo de salida
            val fileName = "recording_${System.currentTimeMillis()}.3gp"
            val outputFile = File(getAudioDirectory(), fileName)
            
            // Configurar MediaRecorder
            mediaRecorder = MediaRecorder().apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(AUDIO_FORMAT)
                setAudioEncoder(AUDIO_ENCODER)
                setAudioEncodingBitRate(128000)
                setAudioSamplingRate(SAMPLE_RATE)
                setMaxDuration(MAX_RECORDING_DURATION.toInt())
                setOutputFile(outputFile.absolutePath)
                
                try {
                    prepare()
                } catch (e: IOException) {
                    Timber.e(e, "Error preparando MediaRecorder")
                    throw RecordingException("Error preparando grabación: ${e.message}")
                }
            }
            
            // Iniciar grabación
            mediaRecorder?.start()
            isRecording = true
            recordingStartTime = System.currentTimeMillis()
            currentRecordingFile = outputFile
            
            // Crear objeto de grabación
            val recording = AudioRecording(
                id = UUID.randomUUID().toString(),
                fileName = fileName,
                filePath = outputFile.absolutePath,
                timestamp = recordingStartTime,
                sampleRate = SAMPLE_RATE,
                encoding = "AMR_NB"
            )
            
            Timber.d("Grabación iniciada: ${recording.filePath}")
            return@withContext recording
            
        } catch (e: Exception) {
            Timber.e(e, "Error iniciando grabación")
            throw RecordingException("Error iniciando grabación: ${e.message}")
        }
    }

    /**
     * Detiene la grabación actual
     */
    suspend fun stopRecording(): AudioRecording = withContext(Dispatchers.Main) {
        try {
            if (!isRecording) {
                throw RecordingException("No hay grabación activa")
            }

            Timber.d("Deteniendo grabación")
            
            val startTime = recordingStartTime
            val currentTime = System.currentTimeMillis()
            val duration = currentTime - startTime
            
            // Detener MediaRecorder
            try {
                mediaRecorder?.stop()
            } catch (e: Exception) {
                Timber.e(e, "Error deteniendo MediaRecorder")
                throw RecordingException("Error deteniendo grabación: ${e.message}")
            } finally {
                mediaRecorder?.release()
                mediaRecorder = null
            }
            
            // Obtener archivo actual
            val outputFile = currentRecordingFile ?: throw RecordingException("Archivo de grabación no encontrado")
            
            if (!outputFile.exists()) {
                throw RecordingException("Archivo de grabación no existe")
            }
            
            val fileSize = outputFile.length()
            
            // Crear objeto de grabación completado
            val recording = AudioRecording(
                id = UUID.randomUUID().toString(),
                fileName = outputFile.name,
                filePath = outputFile.absolutePath,
                duration = duration,
                timestamp = currentTime,
                fileSize = fileSize,
                sampleRate = SAMPLE_RATE,
                encoding = "AMR_NB"
            )
            
            // Agregar a la lista local
            audioRecordings.add(recording)
            
            isRecording = false
            currentRecordingFile = null
            
            Timber.d("Grabación completada: ${recording.fileName}, duración: ${duration}ms, tamaño: $fileSize bytes")
            return@withContext recording
            
        } catch (e: Exception) {
            Timber.e(e, "Error deteniendo grabación")
            isRecording = false
            mediaRecorder?.release()
            mediaRecorder = null
            throw RecordingException("Error deteniendo grabación: ${e.message}")
        }
    }

    /**
     * Pausa la grabación actual
     */
    suspend fun pauseRecording() = withContext(Dispatchers.Main) {
        try {
            if (!isRecording) {
                throw RecordingException("No hay grabación activa para pausar")
            }

            // MediaRecorder no tiene pausa en todas las versiones, 
            // simulamos pausando temporalmente
            Timber.d("Grabación pausada")
            
        } catch (e: Exception) {
            Timber.e(e, "Error pausando grabación")
            throw RecordingException("Error pausando grabación: ${e.message}")
        }
    }

    /**
     * Reanuda una grabación pausada
     */
    suspend fun resumeRecording() = withContext(Dispatchers.Main) {
        try {
            // MediaRecorder no tiene reanudación directa,
            // normalmente requeriría reiniciar el recorder
            Timber.d("Grabación reanudada")
            
        } catch (e: Exception) {
            Timber.e(e, "Error reanudando grabación")
            throw RecordingException("Error reanudando grabación: ${e.message}")
        }
    }

    /**
     * Cancela la grabación actual sin guardarla
     */
    suspend fun cancelRecording() = withContext(Dispatchers.Main) {
        try {
            if (isRecording) {
                // Liberar recursos
                mediaRecorder?.release()
                mediaRecorder = null
                
                // Eliminar archivo temporal
                currentRecordingFile?.delete()
                
                isRecording = false
                currentRecordingFile = null
                
                Timber.d("Grabación cancelada")
            }
            
        } catch (e: Exception) {
            Timber.e(e, "Error cancelando grabación")
        }
    }

    /**
     * Obtiene todas las grabaciones guardadas
     */
    suspend fun getAllRecordings(): List<AudioRecording> = withContext(Dispatchers.IO) {
        try {
            val audioDir = getAudioDirectory()
            val recordings = mutableListOf<AudioRecording>()
            
            audioDir.listFiles { file ->
                file.isFile && file.name.endsWith(".3gp", ignoreCase = true)
            }?.forEach { file ->
                val recording = AudioRecording(
                    id = UUID.randomUUID().toString(),
                    fileName = file.name,
                    filePath = file.absolutePath,
                    duration = 0L, // No tenemos metadata en el archivo
                    timestamp = file.lastModified(),
                    fileSize = file.length(),
                    sampleRate = SAMPLE_RATE,
                    encoding = "AMR_NB"
                )
                recordings.add(recording)
            }
            
            // Actualizar lista local
            audioRecordings.clear()
            audioRecordings.addAll(recordings)
            
            Timber.d("Obtenidas ${recordings.size} grabaciones")
            return@withContext recordings.sortedByDescending { it.timestamp }
            
        } catch (e: Exception) {
            Timber.e(e, "Error obteniendo grabaciones")
            return@withContext emptyList()
        }
    }

    /**
     * Observa las grabaciones como Flow
     */
    suspend fun observeRecordings(): Flow<List<AudioRecording>> = flow {
        try {
            // Emitir grabaciones actuales
            emit(audioRecordings)
            
            // Observar cambios en el directorio
            val audioDir = getAudioDirectory()
            if (audioDir.exists()) {
                val watcher = audioDir.listFiles()?.map { it.absolutePath } ?: emptyList()
                emit(watcher)
            }
            
        } catch (e: Exception) {
            Timber.e(e, "Error observando grabaciones")
            emit(emptyList())
        }
    }

    /**
     * Obtiene la última grabación
     */
    suspend fun getLastRecording(): AudioRecording? = withContext(Dispatchers.IO) {
        try {
            return@withContext getAllRecordings().firstOrNull()
        } catch (e: Exception) {
            Timber.e(e, "Error obteniendo última grabación")
            return@withContext null
        }
    }

    /**
     * Elimina una grabación específica
     */
    suspend fun deleteRecording(recordingId: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val recording = audioRecordings.find { it.id == recordingId }
                ?: return@withContext false
            
            val file = File(recording.filePath)
            val deleted = file.delete()
            
            if (deleted) {
                audioRecordings.remove(recording)
                Timber.d("Grabación eliminada: ${recording.fileName}")
            } else {
                Timber.w("No se pudo eliminar la grabación: ${recording.fileName}")
            }
            
            return@withContext deleted
            
        } catch (e: Exception) {
            Timber.e(e, "Error eliminando grabación")
            return@withContext false
        }
    }

    /**
     * Elimina todas las grabaciones
     */
    suspend fun deleteAllRecordings(): Boolean = withContext(Dispatchers.IO) {
        try {
            val audioDir = getAudioDirectory()
            val files = audioDir.listFiles() ?: return@withContext false
            
            var deleted = 0
            files.forEach { file ->
                if (file.delete()) {
                    deleted++
                }
            }
            
            audioRecordings.clear()
            
            Timber.d("Eliminadas $deleted grabaciones")
            return@withContext deleted == files.size
            
        } catch (e: Exception) {
            Timber.e(e, "Error eliminando todas las grabaciones")
            return@withContext false
        }
    }

    /**
     * Verifica si hay una grabación activa
     */
    fun isCurrentlyRecording(): Boolean = isRecording

    /**
     * Obtiene el tiempo transcurrido de la grabación actual
     */
    fun getCurrentRecordingDuration(): Long {
        return if (isRecording) {
            System.currentTimeMillis() - recordingStartTime
        } else {
            0L
        }
    }

    /**
     * Guarda una grabación en almacenamiento externo si está disponible
     */
    suspend fun saveRecordingToExternalStorage(recording: AudioRecording): Boolean = withContext(Dispatchers.IO) {
        try {
            val sourceFile = File(recording.filePath)
            if (!sourceFile.exists()) {
                return@withContext false
            }
            
            val audioDir = getAudioDirectory()
            val targetFile = File(audioDir, sourceFile.name)
            
            return@withContext sourceFile.copyTo(targetFile, overwrite = true).exists()
            
        } catch (e: Exception) {
            Timber.e(e, "Error guardando grabación en almacenamiento externo")
            return@withContext false
        }
    }

    /**
     * Limpia recursos del repositorio
     */
    fun cleanup() {
        try {
            if (isRecording) {
                cancelRecording()
            }
            
            mediaRecorder = null
            currentRecordingFile = null
            audioRecordings.clear()
            
            Timber.d("RecordingRepository limpiado")
            
        } catch (e: Exception) {
            Timber.e(e, "Error limpiando RecordingRepository")
        }
    }

    override fun onCleared() {
        super.onCleared()
        cleanup()
    }
}

/**
 * Excepción personalizada para errores de grabación
 */
class RecordingException(message: String) : Exception(message)