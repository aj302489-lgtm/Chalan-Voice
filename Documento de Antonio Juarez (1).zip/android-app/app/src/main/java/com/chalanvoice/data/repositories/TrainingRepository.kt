package com.chalanvoice.data.repositories

import android.content.Context
import com.chalanvoice.data.api.TrainingApiService
import com.chalanvoice.ui.models.AudioRecording
import com.chalanvoice.ui.models.TrainingResponse
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import timber.log.Timber
import java.io.File
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Repositorio para manejo del entrenamiento de modelos de voz
 * Se comunica con la API del servidor para procesar audios
 */
@Singleton
class TrainingRepository @Inject constructor(
    private val context: Context,
    private val trainingApi: TrainingApiService,
    private val authRepository: AuthRepository
) {
    
    companion object {
        private const val TAG = "TrainingRepository"
        private const val MODEL_FILE_NAME = "user_model.pth"
    }
    
    /**
     * Inicia el proceso de entrenamiento con una grabación
     */
    suspend fun startTraining(recording: AudioRecording): TrainingResponse = withContext(Dispatchers.IO) {
        try {
            Timber.d("Iniciando entrenamiento para: ${recording.fileName}")
            
            // Verificar que la grabación existe
            val audioFile = File(recording.filePath)
            if (!audioFile.exists()) {
                throw TrainingException("Archivo de audio no encontrado")
            }
            
            // Verificar que el usuario está autenticado
            if (!authRepository.isAuthenticated()) {
                throw TrainingException("Usuario no autenticado")
            }
            
            // Obtener token de autenticación
            val token = authRepository.getAuthToken()
                ?: throw TrainingException("Token de autenticación no disponible")
            
            // Simular subida del archivo (en implementación real usar Multipart)
            val uploadSuccess = simulateFileUpload(audioFile, token)
            if (!uploadSuccess) {
                throw TrainingException("Error subiendo archivo al servidor")
            }
            
            // Solicitar inicio del entrenamiento
            val trainingRequest = createTrainingRequest(recording)
            val response = trainingApi.startTraining(trainingRequest, "Bearer $token")
            
            if (!response.success) {
                throw TrainingException(response.error ?: "Error desconocido del servidor")
            }
            
            val trainingData = response.data ?: throw TrainingException("Datos de entrenamiento vacíos")
            
            Timber.d("Entrenamiento iniciado: ${trainingData.modelId}")
            return@withContext trainingData
            
        } catch (e: Exception) {
            Timber.e(e, "Error en entrenamiento")
            throw TrainingException("Error iniciando entrenamiento: ${e.message}")
        }
    }
    
    /**
     * Simula la subida del archivo de audio al servidor
     * En implementación real, esto usaría Multipart/form-data con Retrofit
     */
    private suspend fun simulateFileUpload(file: File, token: String): Boolean = withContext(Dispatchers.IO) {
        try {
            Timber.d("Subiendo archivo: ${file.name} (${file.length()} bytes)")
            
            // Simular tiempo de subida
            kotlinx.coroutines.delay(2000)
            
            // Simular posibles errores de red
            if (file.length() < 1024) { // Menos de 1KB
                Timber.w("Archivo muy pequeño, puede fallar la subida")
            }
            
            // Simular éxito (en implementación real verificar respuesta HTTP)
            return@withContext true
            
        } catch (e: Exception) {
            Timber.e(e, "Error subiendo archivo")
            return@withContext false
        }
    }
    
    /**
     * Crea la solicitud de entrenamiento
     */
    private fun createTrainingRequest(recording: AudioRecording): Map<String, String> {
        return mapOf(
            "audioFileName" to recording.fileName,
            "duration" to recording.duration.toString(),
            "sampleRate" to recording.sampleRate.toString(),
            "encoding" to recording.encoding,
            "fileSize" to recording.fileSize.toString(),
            "timestamp" to recording.timestamp.toString()
        )
    }
    
    /**
     * Consulta el estado del entrenamiento
     */
    suspend fun getTrainingStatus(modelId: String): TrainingResponse = withContext(Dispatchers.IO) {
        try {
            val token = authRepository.getAuthToken()
                ?: throw TrainingException("Token no disponible")
            
            val response = trainingApi.getTrainingStatus(modelId, "Bearer $token")
            
            if (!response.success) {
                throw TrainingException(response.error ?: "Error obteniendo estado")
            }
            
            return@withContext response.data ?: throw TrainingException("Estado de entrenamiento vacío")
            
        } catch (e: Exception) {
            Timber.e(e, "Error obteniendo estado de entrenamiento")
            throw TrainingException("Error obteniendo estado: ${e.message}")
        }
    }
    
    /**
     * Descarga el modelo entrenado una vez completado
     */
    suspend fun downloadTrainedModel(modelId: String): File = withContext(Dispatchers.IO) {
        try {
            Timber.d("Descargando modelo: $modelId")
            
            val token = authRepository.getAuthToken()
                ?: throw TrainingException("Token no disponible")
            
            // Obtener URL de descarga del modelo
            val response = trainingApi.getModelDownloadUrl(modelId, "Bearer $token")
            
            if (!response.success) {
                throw TrainingException(response.error ?: "Error obteniendo URL de descarga")
            }
            
            val downloadUrl = response.data ?: throw TrainingException("URL de descarga no disponible")
            
            // Simular descarga del modelo
            val modelFile = downloadModelFile(downloadUrl)
            
            Timber.d("Modelo descargado: ${modelFile.absolutePath}")
            return@withContext modelFile
            
        } catch (e: Exception) {
            Timber.e(e, "Error descargando modelo")
            throw TrainingException("Error descargando modelo: ${e.message}")
        }
    }
    
    /**
     * Simula la descarga del archivo del modelo
     */
    private suspend fun downloadModelFile(downloadUrl: String): File = withContext(Dispatchers.IO) {
        try {
            // Crear directorio para modelos
            val modelsDir = File(context.cacheDir, "models")
            if (!modelsDir.exists()) {
                modelsDir.mkdirs()
            }
            
            val modelFile = File(modelsDir, MODEL_FILE_NAME)
            
            // Simular descarga con progreso
            kotlinx.coroutines.delay(3000) // Simular tiempo de descarga
            
            // Crear archivo simulado (en implementación real descargar desde URL)
            if (!modelFile.exists()) {
                modelFile.createNewFile()
                modelFile.writeText("Simulated trained model data for $downloadUrl")
            }
            
            Timber.d("Descarga simulada completada: ${modelFile.absolutePath}")
            return@withContext modelFile
            
        } catch (e: IOException) {
            Timber.e(e, "Error creando archivo de modelo")
            throw TrainingException("Error creando archivo de modelo: ${e.message}")
        }
    }
    
    /**
     * Verifica si el usuario tiene un modelo entrenado
     */
    suspend fun hasUserModel(): Boolean = withContext(Dispatchers.IO) {
        try {
            val token = authRepository.getAuthToken()
            if (token.isNullOrEmpty()) {
                return@withContext false
            }
            
            val response = trainingApi.getUserModels("Bearer $token)
            
            return@withContext response.success && !response.data.isNullOrEmpty()
            
        } catch (e: Exception) {
            Timber.e(e, "Error verificando modelos de usuario")
            return@withContext false
        }
    }
    
    /**
     * Obtiene la lista de modelos del usuario
     */
    suspend fun getUserModels(): List<String> = withContext(Dispatchers.IO) {
        try {
            val token = authRepository.getAuthToken()
            if (token.isNullOrEmpty()) {
                return@withContext emptyList()
            }
            
            val response = trainingApi.getUserModels("Bearer $token")
            
            return@withContext if (response.success) {
                response.data ?: emptyList()
            } else {
                emptyList()
            }
            
        } catch (e: Exception) {
            Timber.e(e, "Error obteniendo modelos de usuario")
            return@withContext emptyList()
        }
    }
    
    /**
     * Elimina el modelo del usuario
     */
    suspend fun deleteUserModel(): Boolean = withContext(Dispatchers.IO) {
        try {
            Timber.d("Eliminando modelo de usuario")
            
            val token = authRepository.getAuthToken()
            if (token.isNullOrEmpty()) {
                throw TrainingException("Token de autenticación no disponible")
            }
            
            val response = trainingApi.deleteUserModel("Bearer $token)
            
            if (response.success) {
                // Eliminar también archivos locales
                deleteLocalModelFiles()
                Timber.d("Modelo eliminado exitosamente")
            } else {
                Timber.w("Error eliminando modelo en servidor: ${response.error}")
            }
            
            return@withContext response.success
            
        } catch (e: Exception) {
            Timber.e(e, "Error eliminando modelo")
            return@withContext false
        }
    }
    
    /**
     * Elimina archivos de modelo locales
     */
    private suspend fun deleteLocalModelFiles() = withContext(Dispatchers.IO) {
        try {
            val modelsDir = File(context.cacheDir, "models")
            if (modelsDir.exists()) {
                modelsDir.listFiles()?.forEach { file ->
                    if (file.name.contains("model", ignoreCase = true)) {
                        file.delete()
                        Timber.d("Archivo local eliminado: ${file.name}")
                    }
                }
            }
        } catch (e: Exception) {
            Timber.e(e, "Error eliminando archivos locales")
        }
    }
    
    /**
     * Actualiza el progreso del entrenamiento en tiempo real
     */
    suspend fun updateTrainingProgress(modelId: String, onProgress: (Int, String) -> Unit) = withContext(Dispatchers.IO) {
        try {
            var progress = 0
            while (progress < 100) {
                val status = getTrainingStatus(modelId)
                
                // Si el entrenamiento está completado
                if (status.status == "completed") {
                    onProgress(100, "Entrenamiento completado")
                    break
                }
                
                // Si hay error
                if (status.status == "error") {
                    onProgress(progress, "Error en entrenamiento")
                    break
                }
                
                // Actualizar progreso
                onProgress(status.progress, "Procesando...")
                progress = status.progress
                
                // Esperar antes de la siguiente consulta
                kotlinx.coroutines.delay(2000)
            }
            
        } catch (e: Exception) {
            Timber.e(e, "Error actualizando progreso de entrenamiento")
            onProgress(0, "Error: ${e.message}")
        }
    }
    
    /**
     * Obtiene estadísticas del modelo entrenado
     */
    suspend fun getModelStats(modelId: String): Map<String, Any> = withContext(Dispatchers.IO) {
        try {
            val token = authRepository.getAuthToken()
            if (token.isNullOrEmpty()) {
                return@withContext emptyMap()
            }
            
            val response = trainingApi.getModelStats(modelId, "Bearer $token)
            
            return@withContext if (response.success) {
                response.data ?: emptyMap()
            } else {
                emptyMap()
            }
            
        } catch (e: Exception) {
            Timber.e(e, "Error obteniendo estadísticas del modelo")
            return@withContext emptyMap()
        }
    }
    
    /**
     * Limpia recursos del repositorio
     */
    fun cleanup() {
        Timber.d("TrainingRepository limpiado")
    }
}

/**
 * Excepción personalizada para errores de entrenamiento
 */
class TrainingException(message: String) : Exception(message)