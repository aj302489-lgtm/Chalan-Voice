package com.chalanvoice.data.repositories

import android.content.Context
import com.chalanvoice.data.api.TtsApiService
import com.chalanvoice.ui.models.TtsParams
import com.chalanvoice.ui.models.TtsResponse
import com.chalanvoice.ui.models.VoiceEmotion
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import timber.log.Timber
import java.io.File
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Repositorio para manejo de síntesis de texto a voz
 * Se comunica con la API del servidor para generar audios personalizados
 */
@Singleton
class TtsRepository @Inject constructor(
    private val context: Context,
    private val ttsApi: TtsApiService,
    private val authRepository: AuthRepository
) {
    
    companion object {
        private const val TAG = "TtsRepository"
        private const val GENERATED_AUDIO_DIR = "ChalanVoice/Generated"
        private const val MAX_TEXT_LENGTH = 1000
    }
    
    /**
     * Genera voz a partir de texto usando el modelo entrenado del usuario
     */
    suspend fun generateVoice(params: TtsParams): TtsResponse = withContext(Dispatchers.IO) {
        try {
            Timber.d("Generando voz para texto: '${params.text.take(50)}...'")
            
            // Validar parámetros
            validateTtsParams(params)
            
            // Verificar que el usuario está autenticado
            if (!authRepository.isAuthenticated()) {
                throw TtsException("Usuario no autenticado")
            }
            
            // Verificar que el usuario tiene un modelo entrenado
            val hasModel = ttsApi.checkUserModel("Bearer ${authRepository.getAuthToken()}")
            if (!hasModel.success || hasModel.data != true) {
                throw TtsException("Debes entrenar un modelo antes de generar voz")
            }
            
            // Obtener token de autenticación
            val token = authRepository.getAuthToken()
                ?: throw TtsException("Token de autenticación no disponible")
            
            // Crear solicitud de TTS
            val ttsRequest = createTtsRequest(params)
            
            // Enviar solicitud al servidor
            val response = ttsApi.generateVoice(ttsRequest, "Bearer $token")
            
            if (!response.success) {
                throw TtsException(response.error ?: "Error generando voz")
            }
            
            val audioData = response.data ?: throw TtsException("Datos de audio vacíos")
            
            // Descargar el audio generado
            val audioFile = downloadGeneratedAudio(audioData.audioUrl, params)
            
            Timber.d("Voz generada exitosamente: ${audioFile.absolutePath}")
            return@withContext TtsResponse(
                audioUrl = audioData.audioUrl,
                audioPath = audioFile.absolutePath,
                duration = audioData.duration,
                fileSize = audioFile.length()
            )
            
        } catch (e: Exception) {
            Timber.e(e, "Error generando voz")
            throw TtsException("Error generando voz: ${e.message}")
        }
    }
    
    /**
     * Valida los parámetros de TTS
     */
    private fun validateTtsParams(params: TtsParams) {
        // Validar texto
        if (params.text.isBlank()) {
            throw TtsException("El texto no puede estar vacío")
        }
        
        if (params.text.length > MAX_TEXT_LENGTH) {
            throw TtsException("El texto no puede tener más de $MAX_TEXT_LENGTH caracteres")
        }
        
        // Validar emoción
        if (params.emotion !in VoiceEmotion.values()) {
            throw TtsException("Emoción no válida")
        }
        
        // Validar parámetros numéricos
        if (params.speed !in 0.5f..2.0f) {
            throw TtsException("La velocidad debe estar entre 0.5 y 2.0")
        }
        
        if (params.pitch !in 0.5f..2.0f) {
            throw TtsException("El tono debe estar entre 0.5 y 2.0")
        }
        
        if (params.volume !in 0.1f..1.0f) {
            throw TtsException("El volumen debe estar entre 0.1 y 1.0")
        }
    }
    
    /**
     * Crea la solicitud de TTS para el servidor
     */
    private fun createTtsRequest(params: TtsParams): Map<String, Any> {
        return mapOf(
            "text" to params.text,
            "emotion" to params.emotion.name,
            "speed" to params.speed,
            "pitch" to params.pitch,
            "volume" to params.volume,
            "language" to params.language,
            "useUserModel" to true // Usar modelo personalizado del usuario
        )
    }
    
    /**
     * Descarga el audio generado desde el servidor
     */
    private suspend fun downloadGeneratedAudio(audioUrl: String, params: TtsParams): File = withContext(Dispatchers.IO) {
        try {
            Timber.d("Descargando audio desde: $audioUrl")
            
            // Crear directorio para audios generados
            val audioDir = File(context.getExternalFilesDir(Environment.DIRECTORY_MUSIC), GENERATED_AUDIO_DIR)
            if (!audioDir.exists()) {
                audioDir.mkdirs()
            }
            
            // Generar nombre de archivo único
            val timestamp = System.currentTimeMillis()
            val emotion = params.emotion.name.lowercase()
            val fileName = "tts_${emotion}_${timestamp}.wav"
            val outputFile = File(audioDir, fileName)
            
            // Simular descarga del audio (en implementación real usar OkHttp)
            simulateAudioDownload(audioUrl, outputFile)
            
            Timber.d("Audio descargado: ${outputFile.absolutePath}")
            return@withContext outputFile
            
        } catch (e: Exception) {
            Timber.e(e, "Error descargando audio")
            throw TtsException("Error descargando audio: ${e.message}")
        }
    }
    
    /**
     * Simula la descarga del archivo de audio
     */
    private suspend fun simulateAudioDownload(url: String, outputFile: File) = withContext(Dispatchers.IO) {
        try {
            // Simular tiempo de generación y descarga
            kotlinx.coroutines.delay(3000)
            
            // Crear archivo de audio simulado
            outputFile.createNewFile()
            
            // Escribir datos simulados de audio
            val header = "WAVE simulated audio for $url"
            outputFile.writeText(header)
            
            Timber.d("Descarga simulada completada: ${outputFile.absolutePath}")
            
        } catch (e: IOException) {
            Timber.e(e, "Error creando archivo de audio")
            throw TtsException("Error creando archivo de audio: ${e.message}")
        }
    }
    
    /**
     * Genera múltiples versiones del mismo texto con diferentes emociones
     */
    suspend fun generateMultipleEmotions(text: String, emotions: List<VoiceEmotion>): List<TtsResponse> = withContext(Dispatchers.IO) {
        try {
            val responses = mutableListOf<TtsResponse>()
            
            emotions.forEach { emotion ->
                try {
                    val params = TtsParams(
                        text = text,
                        emotion = emotion,
                        speed = 1.0f,
                        pitch = 1.0f,
                        volume = 1.0f
                    )
                    
                    val response = generateVoice(params)
                    responses.add(response)
                    
                    // Pequeña pausa entre generaciones para no sobrecargar el servidor
                    kotlinx.coroutines.delay(500)
                    
                } catch (e: Exception) {
                    Timber.w(e, "Error generando emoción: ${emotion.displayName}")
                    // Continuar con las otras emociones aunque una falle
                }
            }
            
            Timber.d("Generadas ${responses.size} versiones para el texto")
            return@withContext responses
            
        } catch (e: Exception) {
            Timber.e(e, "Error generando múltiples emociones")
            throw TtsException("Error generando múltiples emociones: ${e.message}")
        }
    }
    
    /**
     * Obtiene la lista de audios generados por el usuario
     */
    suspend fun getGeneratedAudios(): List<File> = withContext(Dispatchers.IO) {
        try {
            val audioDir = File(context.getExternalFilesDir(Environment.DIRECTORY_MUSIC), GENERATED_AUDIO_DIR)
            
            if (!audioDir.exists()) {
                return@withContext emptyList()
            }
            
            val audioFiles = audioDir.listFiles { file ->
                file.isFile && (
                    file.name.endsWith(".wav", ignoreCase = true) ||
                    file.name.endsWith(".mp3", ignoreCase = true) ||
                    file.name.startsWith("tts_")
                )
            }?.toList() ?: emptyList()
            
            Timber.d("Encontrados ${audioFiles.size} audios generados")
            return@withContext audioFiles.sortedByDescending { it.lastModified() }
            
        } catch (e: Exception) {
            Timber.e(e, "Error obteniendo audios generados")
            return@withContext emptyList()
        }
    }
    
    /**
     * Elimina un audio generado
     */
    suspend fun deleteGeneratedAudio(filePath: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val file = File(filePath)
            val deleted = file.delete()
            
            if (deleted) {
                Timber.d("Audio eliminado: $filePath")
            } else {
                Timber.w("No se pudo eliminar el audio: $filePath")
            }
            
            return@withContext deleted
            
        } catch (e: Exception) {
            Timber.e(e, "Error eliminando audio")
            return@withContext false
        }
    }
    
    /**
     * Elimina todos los audios generados
     */
    suspend fun deleteAllGeneratedAudios(): Boolean = withContext(Dispatchers.IO) {
        try {
            val audioFiles = getGeneratedAudios()
            var deleted = 0
            
            audioFiles.forEach { file ->
                if (file.delete()) {
                    deleted++
                }
            }
            
            Timber.d("Eliminados $deleted audios de $audioFiles.size")
            return@withContext deleted == audioFiles.size
            
        } catch (e: Exception) {
            Timber.e(e, "Error eliminando todos los audios")
            return@withContext false
        }
    }
    
    /**
     * Comparte un audio generado
     */
    suspend fun shareGeneratedAudio(filePath: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val file = File(filePath)
            
            if (!file.exists()) {
                throw TtsException("El archivo de audio no existe")
            }
            
            // Aquí normalmente se usaría un Intent para compartir
            // Por ahora solo verificamos que el archivo existe
            Timber.d("Preparando para compartir: $filePath")
            
            return@withContext true
            
        } catch (e: Exception) {
            Timber.e(e, "Error preparando audio para compartir")
            return@withContext false
        }
    }
    
    /**
     * Obtiene el tamaño total de audios generados
     */
    suspend fun getTotalGeneratedSize(): Long = withContext(Dispatchers.IO) {
        try {
            val audioFiles = getGeneratedAudios()
            return@withContext audioFiles.sumOf { it.length() }
            
        } catch (e: Exception) {
            Timber.e(e, "Error calculando tamaño total")
            return@withContext 0L
        }
    }
    
    /**
     * Limpia audios antiguos (más de 30 días)
     */
    suspend fun cleanupOldGeneratedAudios(): Int = withContext(Dispatchers.IO) {
        try {
            val thirtyDaysAgo = System.currentTimeMillis() - (30 * 24 * 60 * 60 * 1000L)
            val audioFiles = getGeneratedAudios()
            var deleted = 0
            
            audioFiles.forEach { file ->
                if (file.lastModified() < thirtyDaysAgo) {
                    if (file.delete()) {
                        deleted++
                        Timber.d("Audio antiguo eliminado: ${file.name}")
                    }
                }
            }
            
            Timber.d("Limpiados $deleted audios antiguos")
            return@withContext deleted
            
        } catch (e: Exception) {
            Timber.e(e, "Error limpiando audios antiguos")
            return@withContext 0
        }
    }
    
    /**
     * Verifica el estado de la API del servidor
     */
    suspend fun checkApiStatus(): Boolean = withContext(Dispatchers.IO) {
        try {
            val response = ttsApi.checkStatus()
            return@withContext response.success
            
        } catch (e: Exception) {
            Timber.e(e, "Error verificando estado de la API")
            return@withContext false
        }
    }
    
    /**
     * Obtiene ejemplos de texto para TTS
     */
    suspend fun getExampleTexts(): List<String> = withContext(Dispatchers.IO) {
        try {
            // Texto en español para demo
            return@withContext listOf(
                "Hola, soy tu asistente de voz personalizado.",
                "Bienvenido a Chalan Voice, tu tecnología de síntesis de voz.",
                "La inteligencia artificial está revolucionando la forma en que nos comunicamos.",
                "Este es un ejemplo de texto que se convertirá en voz.",
                "La tecnología de síntesis de voz permite crear experiencias naturales e interactivas."
            )
            
        } catch (e: Exception) {
            Timber.e(e, "Error obteniendo ejemplos de texto")
            return@withContext emptyList()
        }
    }
    
    /**
     * Limpia recursos del repositorio
     */
    fun cleanup() {
        Timber.d("TtsRepository limpiado")
    }
}

/**
 * Excepción personalizada para errores de TTS
 */
class TtsException(message: String) : Exception(message)