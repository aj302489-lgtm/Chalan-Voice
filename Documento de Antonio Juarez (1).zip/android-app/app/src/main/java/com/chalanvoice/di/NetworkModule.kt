package com.chalanvoice.di

import android.content.Context
import com.chalanvoice.data.api.*
import com.chalanvoice.data.repositories.*
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.converter.kotlinx.serialization.KotlinxSerializationConverter
import timber.log.Timber
import java.util.concurrent.TimeUnit
import javax.inject.Singleton

/**
 * Módulo de dependencias para Dagger/Hilt
 * Configura las instancias de los servicios y repositorios
 */
@Module
@InstallIn(SingletonComponent::class)
object NetworkModule {

    private const val BASE_URL = "https://api.chalanvoice.com/"
    private const val CONNECT_TIMEOUT = 30L
    private const val READ_TIMEOUT = 60L
    private const val WRITE_TIMEOUT = 60L

    /**
     * Proporciona OkHttpClient configurado
     */
    @Provides
    @Singleton
    fun provideOkHttpClient(): OkHttpClient {
        return OkHttpClient.Builder()
            .connectTimeout(CONNECT_TIMEOUT, TimeUnit.SECONDS)
            .readTimeout(READ_TIMEOUT, TimeUnit.SECONDS)
            .writeTimeout(WRITE_TIMEOUT, TimeUnit.SECONDS)
            .addInterceptor(createLoggingInterceptor())
            .addInterceptor(createAuthInterceptor())
            .addInterceptor(createErrorInterceptor())
            .build()
    }

    /**
     * Crea interceptor de logging para desarrollo
     */
    private fun createLoggingInterceptor(): HttpLoggingInterceptor {
        return HttpLoggingInterceptor { message ->
            Timber.d("HTTP: $message")
        }.apply {
            level = if (com.chalanvoice.BuildConfig.DEBUG) {
                HttpLoggingInterceptor.Level.BODY
            } else {
                HttpLoggingInterceptor.Level.NONE
            }
        }
    }

    /**
     * Interceptor para agregar token de autenticación
     */
    private fun createAuthInterceptor(): okhttp3.Interceptor {
        return okhttp3.Interceptor { chain ->
            val originalRequest = chain.request()
            
            // En una implementación real, obtendríamos el token de AuthRepository
            // Por simplicidad, agregamos un token ficticio
            val requestWithAuth = originalRequest.newBuilder()
                .header("User-Agent", "ChalanVoice/Android 1.0.0")
                .header("Accept", "application/json")
                .build()
            
            chain.proceed(requestWithAuth)
        }
    }

    /**
     * Interceptor para manejar errores de red globalmente
     */
    private fun createErrorInterceptor(): okhttp3.Interceptor {
        return okhttp3.Interceptor { chain ->
            val response = chain.proceed(chain.request())
            
            when (response.code) {
                401 -> {
                    // Token expirado o inválido
                    Timber.w("Token expirado, se requiere re-autenticación")
                    // En implementación real, aquí se podría forzar logout
                }
                403 -> {
                    Timber.w("Acceso denegado")
                }
                404 -> {
                    Timber.w("Recurso no encontrado")
                }
                500 -> {
                    Timber.e("Error del servidor interno")
                }
            }
            
            response
        }
    }

    /**
     * Proporciona instancia de Retrofit
     */
    @Provides
    @Singleton
    fun provideRetrofit(okHttpClient: OkHttpClient): Retrofit {
        return Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .addConverterFactory(KotlinxSerializationConverter())
            .build()
    }

    /**
     * Proporciona servicio de API de autenticación
     */
    @Provides
    @Singleton
    fun provideAuthApiService(retrofit: Retrofit): AuthApiService {
        return retrofit.create(AuthApiService::class.java)
    }

    /**
     * Proporciona servicio de API de entrenamiento
     */
    @Provides
    @Singleton
    fun provideTrainingApiService(retrofit: Retrofit): TrainingApiService {
        return retrofit.create(TrainingApiService::class.java)
    }

    /**
     * Proporciona servicio de API de TTS
     */
    @Provides
    @Singleton
    fun provideTtsApiService(retrofit: Retrofit): TtsApiService {
        return retrofit.create(TtsApiService::class.java)
    }
}

/**
 * Módulo de repositorios
 */
@Module
@InstallIn(SingletonComponent::class)
object RepositoryModule {

    /**
     * Proporciona AuthRepository
     */
    @Provides
    @Singleton
    fun provideAuthRepository(@ApplicationContext context: Context): AuthRepository {
        return AuthRepository(context)
    }

    /**
     * Proporciona RecordingRepository
     */
    @Provides
    @Singleton
    fun provideRecordingRepository(@ApplicationContext context: Context): RecordingRepository {
        return RecordingRepository(context)
    }

    /**
     * Proporciona TrainingRepository
     */
    @Provides
    @Singleton
    fun provideTrainingRepository(
        @ApplicationContext context: Context,
        trainingApi: TrainingApiService,
        authRepository: AuthRepository
    ): TrainingRepository {
        return TrainingRepository(context, trainingApi, authRepository)
    }

    /**
     * Proporciona TtsRepository
     */
    @Provides
    @Singleton
    fun provideTtsRepository(
        @ApplicationContext context: Context,
        ttsApi: TtsApiService,
        authRepository: AuthRepository
    ): TtsRepository {
        return TtsRepository(context, ttsApi, authRepository)
    }
}