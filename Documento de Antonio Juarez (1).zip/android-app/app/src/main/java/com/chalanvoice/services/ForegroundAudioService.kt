package com.chalanvoice.services

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.MediaRecorder
import android.os.Binder
import android.os.Build
import android.os.Environment
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.chalanvoice.R
import com.chalanvoice.ui.screens.MainActivity
import com.chalanvoice.ui.models.RecordingState
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import timber.log.Timber
import java.io.File
import java.util.UUID
import javax.inject.Inject

/**
 * Servicio de primer plano para grabación de audio en segundo plano
 * Cumple con las restricciones de Android 9+ para acceso al micrófono
 */
@AndroidEntryPoint
class ForegroundAudioService : Service() {
    
    companion object {
        private const val NOTIFICATION_CHANNEL_ID = "chalan_voice_recording"
        private const val NOTIFICATION_CHANNEL_NAME = "Grabación de Voz"
        private const val NOTIFICATION_ID = 1001
        private const val ACTION_START_RECORDING = "start_recording"
        private const val ACTION_STOP_RECORDING = "stop_recording"
        private const val ACTION_PAUSE_RECORDING = "pause_recording"
        
        fun createStartIntent(context: Context): Intent {
            return Intent(context, ForegroundAudioService::class.java).apply {
                action = ACTION_START_RECORDING
            }
        }
        
        fun createStopIntent(context: Context): Intent {
            return Intent(context, ForegroundAudioService::class.java).apply {
                action = ACTION_STOP_RECORDING
            }
        }
        
        fun createPauseIntent(context: Context): Intent {
            return Intent(context, ForegroundAudioService::class.java).apply {
                action = ACTION_PAUSE_RECORDING
            }
        }
    }
    
    @Inject
    lateinit var recordingRepository: com.chalanvoice.data.repositories.RecordingRepository
    
    private val serviceScope = CoroutineScope(Dispatchers.Main + Job())
    private val binder = LocalBinder()
    private var mediaRecorder: MediaRecorder? = null
    private var currentRecordingFile: File? = null
    private var isRecording = false
    private var isPaused = false
    
    // Estado del servicio expuesto al Activity
    private val _recordingState = MutableStateFlow(RecordingState.Idle)
    val recordingState = _recordingState.asStateFlow()
    
    private val _recordingDuration = MutableStateFlow(0L)
    val recordingDuration = _recordingDuration.asStateFlow()
    
    inner class LocalBinder : Binder() {
        fun getService(): ForegroundAudioService = this@ForegroundAudioService
    }

    override fun onCreate() {
        super.onCreate()
        Timber.d("ForegroundAudioService creado")
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Timber.d("ForegroundAudioService iniciado con acción: ${intent?.action}")
        
        when (intent?.action) {
            ACTION_START_RECORDING -> {
                startForegroundService()
                startRecording()
            }
            ACTION_STOP_RECORDING -> {
                stopRecording()
                stopForegroundService()
            }
            ACTION_PAUSE_RECORDING -> {
                pauseRecording()
            }
        }
        
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder = binder

    /**
     * Inicia el servicio en primer plano con notificación
     */
    private fun startForegroundService() {
        val notification = createRecordingNotification()
        startForeground(NOTIFICATION_ID, notification)
        Timber.d("Servicio iniciado en primer plano")
    }

    /**
     * Detiene el servicio en primer plano
     */
    private fun stopForegroundService() {
        stopForeground(STOP_FOREGROUND_REMOVE)
        Timber.d("Servicio en primer plano detenido")
    }

    /**
     * Crea el canal de notificación requerido para Android 8.0+
     */
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                NOTIFICATION_CHANNEL_ID,
                NOTIFICATION_CHANNEL_NAME,
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Notificaciones de grabación de Chalan Voice"
                setShowBadge(false)
                enableVibration(false)
                enableLights(false)
            }
            
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    /**
     * Crea la notificación para el servicio en primer plano
     */
    private fun createRecordingNotification(): Notification {
        val mainIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, mainIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = createStopIntent(this)
        val stopPendingIntent = PendingIntent.getService(
            this, 1, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val pauseIntent = createPauseIntent(this)
        val pausePendingIntent = PendingIntent.getService(
            this, 2, pauseIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val title = if (isPaused) "Grabación pausada" else "Grabando..."
        val subtitle = "Chalan Voice"

        return NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(subtitle)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .addAction(
                R.drawable.ic_launcher_foreground,
                if (isPaused) "Reanudar" else "Pausar",
                pausePendingIntent
            )
            .addAction(
                R.drawable.ic_launcher_foreground,
                "Detener",
                stopPendingIntent
            )
            .setProgress(0, 0, isPaused)
            .setDefaults(0)
            .build()
    }

    /**
     * Inicia la grabación
     */
    private fun startRecording() {
        if (isRecording) {
            Timber.w("La grabación ya está en curso")
            return
        }

        serviceScope.launch {
            try {
                _recordingState.value = RecordingState.Recording
                
                // Crear archivo de grabación
                val fileName = "service_recording_${UUID.randomUUID()}.3gp"
                val outputFile = File(getExternalFilesDir(Environment.DIRECTORY_MUSIC), fileName)
                
                // Configurar MediaRecorder
                mediaRecorder = MediaRecorder().apply {
                    setAudioSource(MediaRecorder.AudioSource.MIC)
                    setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP)
                    setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB)
                    setAudioEncodingBitRate(128000)
                    setAudioSamplingRate(44100)
                    setOutputFile(outputFile.absolutePath)
                    
                    try {
                        prepare()
                    } catch (e: Exception) {
                        Timber.e(e, "Error preparando MediaRecorder")
                        _recordingState.value = RecordingState.Error(e.message ?: "Error desconocido")
                        return@launch
                    }
                }
                
                // Iniciar grabación
                mediaRecorder?.start()
                currentRecordingFile = outputFile
                isRecording = true
                isPaused = false
                
                // Iniciar contador de tiempo
                startDurationTimer()
                
                // Actualizar notificación
                updateNotification()
                
                Timber.d("Grabación iniciada desde servicio en primer plano")
                
            } catch (e: Exception) {
                Timber.e(e, "Error iniciando grabación")
                _recordingState.value = RecordingState.Error(e.message ?: "Error desconocido")
                stopForegroundService()
            }
        }
    }

    /**
     * Detiene la grabación
     */
    private fun stopRecording() {
        if (!isRecording) {
            Timber.w("No hay grabación activa para detener")
            return
        }

        serviceScope.launch {
            try {
                _recordingState.value = RecordingState.Completed
                
                // Detener MediaRecorder
                mediaRecorder?.apply {
                    stop()
                    release()
                }
                mediaRecorder = null
                
                // Guardar información de la grabación
                val recordingFile = currentRecordingFile
                if (recordingFile != null && recordingFile.exists()) {
                    // Aquí se podría guardar la información en el repositorio
                    Timber.d("Grabación completada: ${recordingFile.absolutePath}")
                }
                
                isRecording = false
                isPaused = false
                currentRecordingFile = null
                
                // Actualizar notificación
                updateNotification()
                
                Timber.d("Grabación detenida desde servicio en primer plano")
                
            } catch (e: Exception) {
                Timber.e(e, "Error deteniendo grabación")
                _recordingState.value = RecordingState.Error(e.message ?: "Error desconocido")
            }
        }
    }

    /**
     * Pausa o reanuda la grabación
     */
    private fun pauseRecording() {
        if (!isRecording) {
            Timber.w("No hay grabación activa para pausar")
            return
        }

        serviceScope.launch {
            try {
                isPaused = !isPaused
                
                if (isPaused) {
                    _recordingState.value = RecordingState.Paused
                    // MediaRecorder no tiene pausa directa en todas las versiones
                    // En una implementación completa se tendría que usar AudioRecord
                    Timber.d("Grabación pausada")
                } else {
                    _recordingState.value = RecordingState.Recording
                    Timber.d("Grabación reanudada")
                }
                
                // Actualizar notificación
                updateNotification()
                
            } catch (e: Exception) {
                Timber.e(e, "Error pausando/reanudando grabación")
            }
        }
    }

    /**
     * Inicia el temporizador de duración
     */
    private fun startDurationTimer() {
        var startTime = System.currentTimeMillis()
        
        serviceScope.launch {
            while (isRecording && !isPaused) {
                val duration = System.currentTimeMillis() - startTime
                _recordingDuration.value = duration
                kotlinx.coroutines.delay(1000) // Actualizar cada segundo
            }
        }
    }

    /**
     * Actualiza la notificación
     */
    private fun updateNotification() {
        val notification = createRecordingNotification()
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(NOTIFICATION_ID, notification)
    }

    /**
     * Obtiene el estado actual de grabación
     */
    fun getRecordingState(): RecordingState = _recordingState.value

    /**
     * Obtiene la duración actual de grabación
     */
    fun getRecordingDuration(): Long = _recordingDuration.value

    /**
     * Verifica si está grabando
     */
    fun isRecording(): Boolean = isRecording

    /**
     * Verifica si está pausado
     */
    fun isPaused(): Boolean = isPaused

    override fun onDestroy() {
        super.onDestroy()
        Timber.d("ForegroundAudioService destruido")
        
        serviceScope.cancel()
        
        // Limpiar recursos
        mediaRecorder?.release()
        mediaRecorder = null
        
        if (isRecording) {
            stopRecording()
        }
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        Timber.d("Tarea removida, deteniendo servicio")
        
        if (isRecording) {
            stopRecording()
        }
        stopForegroundService()
        stopSelf()
    }
}