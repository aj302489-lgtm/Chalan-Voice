package com.chalanvoice.ui.models

import com.chalanvoice.ui.models.RecordingState.Idle
import com.chalanvoice.ui.models.TrainingState.Idle
import com.chalanvoice.ui.models.TtsState.Idle

/**
 * Estado principal de la UI que combina todos los estados de las diferentes pantallas
 */
data class MainUiState(
    // Estado global de la aplicación
    val isLoading: Boolean = false,
    val currentError: String? = null,
    val hasAcceptedEthics: Boolean = false,
    val hasPermission: Boolean = false,
    
    // Estados específicos por funcionalidad
    val recordingState: RecordingState = Idle,
    val trainingState: TrainingState = Idle,
    val ttsState: TtsState = Idle,
    
    // Datos de la aplicación
    val currentRecording: AudioRecording? = null,
    val generatedAudio: String? = null,
    val userInfo: UserInfo? = null,
    val playbackState: PlaybackState = PlaybackState.STOPPED,
    
    // Configuración
    val isDarkTheme: Boolean = true,
    val isLoggedIn: Boolean = false
)

/**
 * Estados para el reproductor de audio
 */
enum class PlaybackState {
    STOPPED,
    PLAYING,
    PAUSED,
    LOADING
}

/**
 * Datos de progreso para operaciones largas
 */
data class ProgressData(
    val operation: String,
    val progress: Int,
    val total: Int,
    val message: String = ""
)

/**
 * Acciones que puede ejecutar la UI sobre el estado principal
 */
sealed class MainUiAction {
    data class RequestAudioPermission(val granted: Boolean) : MainUiAction()
    data class SetError(val error: String?) : MainUiAction()
    data class SetLoading(val loading: Boolean) : MainUiAction()
    data class AcceptEthics(val accepted: Boolean) : MainUiAction()
    data class SetRecordingState(val state: RecordingState) : MainUiAction()
    data class SetTrainingState(val state: TrainingState) : MainUiAction()
    data class SetTtsState(val state: TtsState) : MainUiAction()
    data class SetCurrentRecording(val recording: AudioRecording?) : MainUiAction()
    data class SetGeneratedAudio(val audioPath: String?) : MainUiAction()
    data class SetPlaybackState(val state: PlaybackState) : MainUiAction()
    data class ToggleTheme(val isDark: Boolean) : MainUiAction()
    data class SetUserInfo(val userInfo: UserInfo?) : MainUiAction()
    data class SetLoggedIn(val loggedIn: Boolean) : MainUiAction()
    data class ClearAllStates : MainUiAction()
}