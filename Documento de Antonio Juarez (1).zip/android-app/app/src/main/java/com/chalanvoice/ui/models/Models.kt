package com.chalanvoice.ui.models

import kotlinx.serialization.Serializable

/**
 * Modelo principal para representar una grabación de audio
 */
@Serializable
data class AudioRecording(
    val id: String = "",
    val fileName: String = "",
    val filePath: String = "",
    val duration: Long = 0L,
    val timestamp: Long = System.currentTimeMillis(),
    val fileSize: Long = 0L,
    val isTrained: Boolean = false,
    val sampleRate: Int = 44100,
    val encoding: String = "PCM"
)

/**
 * Estados posibles para el proceso de grabación
 */
@Serializable
sealed class RecordingState {
    object Idle : RecordingState()
    object RequestingPermission : RecordingState()
    object Recording : RecordingState()
    object Paused : RecordingState()
    object Completed : RecordingState()
    data class Error(val message: String) : RecordingState()
    data class Saved(val recording: AudioRecording) : RecordingState()
}

/**
 * Estados para el entrenamiento del modelo
 */
@Serializable
sealed class TrainingState {
    object Idle : TrainingState()
    object Uploading : TrainingState()
    object Processing : TrainingState()
    object Completed : TrainingState()
    data class Error(val message: String) : TrainingState()
}

/**
 * Tipos de emoción disponibles para la síntesis de voz
 */
enum class VoiceEmotion(val displayName: String) {
    NEUTRAL("Neutral"),
    HAPPY("Feliz"),
    SAD("Triste"),
    ANGRY("Enojado"),
    EXCITED("Emocionado"),
    CALM("Tranquilo"),
    FEARFUL("Temeroso");
    
    companion object {
        fun fromDisplayName(name: String): VoiceEmotion? {
            return values().find { it.displayName == name }
        }
    }
}

/**
 * Parámetros para la generación de texto a voz
 */
@Serializable
data class TtsParams(
    val text: String = "",
    val emotion: VoiceEmotion = VoiceEmotion.NEUTRAL,
    val speed: Float = 1.0f,
    val pitch: Float = 1.0f,
    val volume: Float = 1.0f,
    val language: String = "es-ES"
)

/**
 * Estados para el generador de texto a voz
 */
@Serializable
sealed class TtsState {
    object Idle : TtsState()
    data class Generating(val params: TtsParams) : TtsState()
    data class Completed(val audioPath: String) : TtsState()
    data class Error(val message: String) : TtsState()
}

/**
 * Respuesta de la API del servidor
 */
@Serializable
data class ApiResponse<T>(
    val success: Boolean = false,
    val data: T? = null,
    val error: String = "",
    val message: String = ""
)

/**
 * Respuesta específica para el entrenamiento
 */
@Serializable
data class TrainingResponse(
    val modelId: String,
    val status: String,
    val progress: Int = 0,
    val estimatedTimeMinutes: Int = 0
)

/**
 * Respuesta para la síntesis de voz
 */
@Serializable
data class TtsResponse(
    val audioUrl: String,
    val audioPath: String? = null,
    val duration: Long,
    val fileSize: Long
)

/**
 * Información del usuario y autenticación
 */
@Serializable
data class UserInfo(
    val userId: String,
    val email: String,
    val modelTrained: Boolean,
    val modelId: String? = null,
    val subscriptionType: String = "free"
)

/**
 * Configuraciones de la aplicación
 */
@Serializable
data class AppConfig(
    val maxRecordingDuration: Long = 5 * 60 * 1000L, // 5 minutos
    val supportedFormats: List<String> = listOf("wav", "mp3", "aac"),
    val maxTextLength: Int = 1000,
    val languages: List<String> = listOf("es-ES", "en-US", "fr-FR"),
    val emotions: List<VoiceEmotion> = VoiceEmotion.values().toList()
)

/**
 * Configuración de navegación de la aplicación
 */
object NavigationRoutes {
    const val WELCOME = "welcome"
    const val RECORDING = "recording"
    const val TRAINING = "training"
    const val TTS_GENERATOR = "tts_generator"
    const val AUDIO_PLAYER = "audio_player"
    const val SETTINGS = "settings"
    
    // Rutas con argumentos
    fun audioPlayer(recordingId: String? = null) = "audio_player/$recordingId"
}