package com.chalanvoice.ui.screens

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.chalanvoice.ui.models.*
import com.chalanvoice.ui.screens.welcome.WelcomeScreen
import com.chalanvoice.ui.screens.recording.RecordingScreen
import com.chalanvoice.ui.screens.training.TrainingScreen
import com.chalanvoice.ui.screens.tts.TtsGeneratorScreen
import com.chalanvoice.ui.screens.player.AudioPlayerScreen
import com.chalanvoice.ui.screens.settings.SettingsScreen

/**
 * Configuración de navegación de la aplicación
 */
@Composable
fun AppNavigation(
    navController: NavHostController,
    uiState: MainUiState,
    onNavigate: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    NavHost(
        navController = navController,
        startDestination = if (uiState.hasAcceptedEthics) {
            NavigationRoutes.RECORDING
        } else {
            NavigationRoutes.WELCOME
        },
        modifier = modifier
    ) {
        // Pantalla de bienvenida y consentimientos éticos
        composable(NavigationRoutes.WELCOME) {
            WelcomeScreen(
                onEthicsAccepted = {
                    onUiActionAndNavigate(
                        navController,
                        MainUiAction.AcceptEthics(true),
                        NavigationRoutes.RECORDING
                    )
                },
                onDeclineEthics = {
                    // En caso de rechazar, cerrar la app o ir a una pantalla de información
                    onNavigate(NavigationRoutes.WELCOME)
                }
            )
        }
        
        // Pantalla de grabación
        composable(NavigationRoutes.RECORDING) {
            RecordingScreen(
                uiState = uiState,
                onStartRecording = { /* Manejado en RecordingScreen */ },
                onStopRecording = { /* Manejado en RecordingScreen */ },
                onNavigateToTraining = {
                    onNavigate(NavigationRoutes.TRAINING)
                },
                onNavigateToSettings = {
                    onNavigate(NavigationRoutes.SETTINGS)
                }
            )
        }
        
        // Pantalla de entrenamiento
        composable(NavigationRoutes.TRAINING) {
            TrainingScreen(
                uiState = uiState,
                onStartTraining = { /* Manejado en TrainingScreen */ },
                onTrainingCompleted = {
                    onNavigate(NavigationRoutes.TTS_GENERATOR)
                },
                onNavigateBack = {
                    navController.popBackStack()
                }
            )
        }
        
        // Pantalla del generador de texto a voz
        composable(NavigationRoutes.TTS_GENERATOR) {
            TtsGeneratorScreen(
                uiState = uiState,
                onGenerateVoice = { /* Manejado en TtsGeneratorScreen */ },
                onNavigateToPlayer = { audioPath ->
                    onNavigate(NavigationRoutes.audioPlayer(audioPath))
                },
                onNavigateBack = {
                    navController.popBackStack()
                }
            )
        }
        
        // Pantalla del reproductor de audio
        composable(
            route = "${NavigationRoutes.AUDIO_PLAYER}/{audioPath}",
            arguments = listOf(
                androidx.navigation.navArgument("audioPath") {
                    type = androidx.navigation.NavType.StringType
                    nullable = true
                }
            )
        ) { backStackEntry ->
            val audioPath = backStackEntry.arguments?.getString("audioPath")
            AudioPlayerScreen(
                audioPath = audioPath,
                onNavigateBack = {
                    navController.popBackStack()
                }
            )
        }
        
        // Pantalla de configuración
        composable(NavigationRoutes.SETTINGS) {
            SettingsScreen(
                uiState = uiState,
                onDeleteModel = { /* Manejado en SettingsScreen */ },
                onToggleTheme = { isDark ->
                    onUiActionAndNavigate(
                        navController,
                        MainUiAction.ToggleTheme(isDark),
                        NavigationRoutes.RECORDING
                    )
                },
                onLogout = {
                    onUiActionAndNavigate(
                        navController,
                        MainUiAction.ClearAllStates,
                        NavigationRoutes.WELCOME
                    )
                },
                onNavigateBack = {
                    navController.popBackStack()
                }
            )
        }
    }
}

/**
 * Función helper para ejecutar acciones y navegar
 */
private fun onUiActionAndNavigate(
    navController: NavHostController,
    uiAction: MainUiAction,
    destination: String
) {
    // Aquí se ejecutaría la acción en el ViewModel
    // y luego se navegaría a la nueva pantalla
    navController.navigate(destination) {
        popUpTo(navController.graph.startDestinationId) {
            saveState = true
        }
        launchSingleTop = true
        restoreState = true
    }
}