package com.chalanvoice.ui.screens

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Bundle
import android.os.IBinder
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.core.splashscreen.SplashScreen
import androidx.navigation.compose.rememberNavController
import com.chalanvoice.ui.theme.ChalanVoiceTheme
import com.chalanvoice.ui.models.MainUiAction
import com.chalanvoice.services.ForegroundAudioService
import dagger.hilt.android.AndroidEntryPoint
import timber.log.Timber

/**
 * Actividad principal de Chalan Voice
 * Maneja permisos, navegación y el servicio de grabación en primer plano
 */
@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    private val viewModel: com.chalanvoice.ui.viewmodels.MainViewModel by viewModels()
    
    private var foregroundService: ForegroundAudioService? = null
    private var isServiceBound = false
    
    // Servicio de conexión para el servicio en primer plano
    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(className: ComponentName, service: IBinder) {
            val binder = service as ForegroundAudioService.LocalBinder
            foregroundService = binder.getService()
            isServiceBound = true
            Timber.d("Conexión establecida con ForegroundAudioService")
        }
        
        override fun onServiceDisconnected(arg0: ComponentName) {
            isServiceBound = false
            foregroundService = null
            Timber.d("Desconectado de ForegroundAudioService")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Configurar splash screen
        SplashScreen.installSplashScreen(this)
        
        setContent {
            ChalanVoiceTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    MainApp(viewModel = viewModel)
                }
            }
        }
        
        // Solicitar permisos necesarios
        requestPermissions()
        
        // Verificar deep links
        handleIntent(intent)
    }
    
    /**
     * Solicita permisos necesarios para la aplicación
     */
    private fun requestPermissions() {
        val permissionLauncher = registerForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) { permissions ->
            val hasMicPermission = permissions[Manifest.permission.RECORD_AUDIO] ?: false
            val hasStoragePermission = permissions[Manifest.permission.WRITE_EXTERNAL_STORAGE] ?: false
            
            Timber.d("Permisos solicitados - Micrófono: $hasMicPermission, Almacenamiento: $hasStoragePermission")
            
            viewModel.onUiAction(MainUiAction.RequestAudioPermission(hasMicPermission))
        }
        
        permissionLauncher.launch(
            arrayOf(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.READ_EXTERNAL_STORAGE
            )
        )
    }
    
    /**
     * Maneja intents de deep links y notificaciones
     */
    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        intent?.let { handleIntent(it) }
    }
    
    /**
     * Procesa los intents recibidos
     */
    private fun handleIntent(intent: Intent) {
        when (intent.action) {
            Intent.ACTION_VIEW -> {
                // Manejar deep links
                val uri = intent.data
                Timber.d("Deep link recibido: $uri")
                
                // Aquí se puede navegar a pantallas específicas basadas en el deep link
                // Por ejemplo, /voice/generator para ir directamente al generador
            }
        }
    }
    
    /**
     * Vincula el servicio en primer plano para comunicación bidireccional
     */
    private fun bindForegroundService() {
        if (!isServiceBound) {
            val intent = Intent(this, ForegroundAudioService::class.java)
            bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE)
        }
    }
    
    /**
     * Desvincula el servicio en primer plano
     */
    private fun unbindForegroundService() {
        if (isServiceBound) {
            unbindService(serviceConnection)
            isServiceBound = false
        }
    }
    
    override fun onResume() {
        super.onResume()
        bindForegroundService()
    }
    
    override fun onPause() {
        super.onPause()
        // No desvincular aquí para mantener la conexión durante la vida del Activity
    }
    
    override fun onDestroy() {
        super.onDestroy()
        unbindForegroundService()
        Timber.d("MainActivity destruida")
    }
}

/**
 * Composable principal de la aplicación
 */
@Composable
fun MainApp(viewModel: com.chalanvoice.ui.viewmodels.MainViewModel) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val navController = rememberNavController()
    
    // Configurar navegación
    AppNavigation(
        navController = navController,
        uiState = uiState,
        onNavigate = { route -> navController.navigate(route) }
    )
    
    // Mostrar errores si los hay
    uiState.currentError?.let { error ->
        ErrorDialog(
            message = error,
            onDismiss = { viewModel.clearError() }
        )
    }
    
    // Mostrar loading global si está activo
    if (uiState.isLoading) {
        LoadingOverlay()
    }
}

/**
 * Composable para mostrar diálogos de error
 */
@Composable
fun ErrorDialog(
    message: String,
    onDismiss: () -> Unit
) {
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        title = { androidx.compose.material3.Text("Error") },
        text = { androidx.compose.material3.Text(message) },
        confirmButton = {
            androidx.compose.material3.TextButton(
                onClick = onDismiss
            ) {
                androidx.compose.material3.Text("OK")
            }
        }
    )
}

/**
 * Overlay de carga global
 */
@Composable
fun LoadingOverlay() {
    androidx.compose.foundation.layout.Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = androidx.compose.ui.Alignment.Center
    ) {
        androidx.compose.material3.CircularProgressIndicator()
    }
}