package com.chalanvoice.ui.screens.player

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.chalanvoice.ui.theme.AppDimensions
import kotlinx.coroutines.delay

/**
 * Pantalla del reproductor de audio generado
 */
@Composable
fun AudioPlayerScreen(
    audioPath: String?,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    
    // Estado del reproductor
    var isPlaying by remember { mutableStateOf(false) }
    var isPaused by remember { mutableStateOf(false) }
    var currentTime by remember { mutableStateOf(0L) }
    var totalDuration by remember { mutableStateOf(30000L) } // 30 segundos simulado
    var showShareDialog by remember { mutableStateOf(false) }
    
    // Simular reproducción
    LaunchedEffect(isPlaying) {
        while (isPlaying && currentTime < totalDuration) {
            delay(1000)
            currentTime += 1000
        }
        if (currentTime >= totalDuration) {
            isPlaying = false
            isPaused = false
            currentTime = 0L
        }
    }
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .systemBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(AppDimensions.mediumPadding),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Header
            AudioPlayerHeader(onNavigateBack = onNavigateBack)
            
            Spacer(modifier = Modifier.height(AppDimensions.largePadding))
            
            // Contenido principal
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(AppDimensions.extraLargePadding)
            ) {
                // Visualización de audio
                AudioVisualization(isPlaying = isPlaying)
                
                // Información del audio
                AudioInfoCard(
                    audioPath = audioPath,
                    currentTime = currentTime,
                    totalDuration = totalDuration
                )
                
                // Barra de progreso
                AudioProgressBar(
                    currentTime = currentTime,
                    totalDuration = totalDuration,
                    onSeek = { newTime -> currentTime = newTime }
                )
                
                // Controles de reproducción
                AudioControls(
                    isPlaying = isPlaying,
                    isPaused = isPaused,
                    onPlay = { isPlaying = true; isPaused = false },
                    onPause = { isPlaying = false; isPaused = true },
                    onStop = { 
                        isPlaying = false
                        isPaused = false
                        currentTime = 0L
                    }
                )
            }
            
            Spacer(modifier = Modifier.weight(1f))
            
            // Botones de acción
            AudioActions(
                onShare = { showShareDialog = true },
                onSave = { /* Guardar audio localmente */ }
            )
        }
        
        // Diálogo de compartir
        if (showShareDialog) {
            ShareDialog(
                audioPath = audioPath,
                onDismiss = { showShareDialog = false }
            )
        }
    }
}

@Composable
private fun AudioPlayerHeader(onNavigateBack: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = AppDimensions.mediumPadding),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(
            onClick = onNavigateBack,
            modifier = Modifier.size(48.dp)
        ) {
            Icon(
                imageVector = Icons.Default.ArrowBack,
                contentDescription = "Volver",
                tint = MaterialTheme.colorScheme.onSurface
            )
        }
        
        Text(
            text = "Reproducir Audio",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground,
            textAlign = TextAlign.Center
        )
        
        Spacer(modifier = Modifier.size(48.dp))
    }
}

@Composable
private fun AudioVisualization(isPlaying: Boolean) {
    Box(
        modifier = Modifier
            .size(200.dp)
            .clip(CircleShape)
            .background(
                MaterialTheme.colorScheme.primaryContainer.copy(
                    alpha = if (isPlaying) 1f else 0.3f
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        if (isPlaying) {
            // Animación de ondas de audio
            Row(
                horizontalArrangement = Arrangement.spacedBy(2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                repeat(12) { index ->
                    val waveHeight = (20 + (kotlinx.coroutines.delay(100); (Math.random() * 80).toInt()))
                    Box(
                        modifier = Modifier
                            .width(3.dp)
                            .height(waveHeight.dp)
                            .background(MaterialTheme.colorScheme.primary)
                    )
                }
            }
        } else {
            Icon(
                imageVector = Icons.Default.VolumeUp,
                contentDescription = "Audio",
                modifier = Modifier.size(64.dp),
                tint = MaterialTheme.colorScheme.primary
            )
        }
    }
}

@Composable
private fun AudioInfoCard(
    audioPath: String?,
    currentTime: Long,
    totalDuration: Long
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(
            modifier = Modifier.padding(AppDimensions.mediumPadding)
        ) {
            Text(
                text = "Audio Generado",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )
            
            Spacer(modifier = Modifier.height(AppDimensions.smallPadding))
            
            Text(
                text = "Generado con emoción personalizada",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
            )
            
            Spacer(modifier = Modifier.height(AppDimensions.smallPadding))
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = formatTime(currentTime),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface
                )
                
                Text(
                    text = formatTime(totalDuration),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )
            }
        }
    }
}

@Composable
private fun AudioProgressBar(
    currentTime: Long,
    totalDuration: Long,
    onSeek: (Long) -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth()
    ) {
        LinearProgressIndicator(
            progress = if (totalDuration > 0) currentTime.toFloat() / totalDuration else 0f,
            modifier = Modifier.fillMaxWidth(),
            color = MaterialTheme.colorScheme.primary
        )
        
        Spacer(modifier = Modifier.height(AppDimensions.smallPadding))
        
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = formatTime(currentTime),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
            )
            
            Text(
                text = formatTime(totalDuration),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
            )
        }
    }
}

@Composable
private fun AudioControls(
    isPlaying: Boolean,
    isPaused: Boolean,
    onPlay: () -> Unit,
    onPause: () -> Unit,
    onStop: () -> Unit
) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(AppDimensions.mediumPadding),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Botón stop
        IconButton(
            onClick = onStop,
            modifier = Modifier.size(48.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Stop,
                contentDescription = "Detener",
                tint = MaterialTheme.colorScheme.onSurface
            )
        }
        
        // Botón principal play/pause
        FloatingActionButton(
            onClick = if (isPlaying) onPause else onPlay,
            modifier = Modifier.size(64.dp),
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary
        ) {
            Icon(
                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                contentDescription = if (isPlaying) "Pausar" else "Reproducir",
                modifier = Modifier.size(32.dp)
            )
        }
        
        // Botón compartir (placeholder)
        IconButton(
            onClick = { /* Compartir */ },
            modifier = Modifier.size(48.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Share,
                contentDescription = "Compartir",
                tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
            )
        }
    }
}

@Composable
private fun AudioActions(
    onShare: () -> Unit,
    onSave: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = AppDimensions.largePadding),
        horizontalArrangement = Arrangement.spacedBy(AppDimensions.mediumPadding)
    ) {
        OutlinedButton(
            onClick = onSave,
            modifier = Modifier.weight(1f),
            colors = ButtonDefaults.outlinedButtonColors(
                contentColor = MaterialTheme.colorScheme.outline
            )
        ) {
            Text("Guardar Audio")
        }
        
        Button(
            onClick = onShare,
            modifier = Modifier.weight(1f),
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary
            )
        ) {
            Icon(
                imageVector = Icons.Default.Share,
                contentDescription = null,
                modifier = Modifier.size(18.dp)
            )
            
            Spacer(modifier = Modifier.width(AppDimensions.smallPadding))
            
            Text("Compartir")
        }
    }
}

@Composable
private fun ShareDialog(
    audioPath: String?,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Compartir Audio") },
        text = { Text("El audio se compartirá mediante las aplicaciones disponibles en tu dispositivo.") },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Entendido")
            }
        }
    )
}

private fun formatTime(millis: Long): String {
    val seconds = millis / 1000
    val minutes = seconds / 60
    val remainingSeconds = seconds % 60
    return "%02d:%02d".format(minutes, remainingSeconds)
}