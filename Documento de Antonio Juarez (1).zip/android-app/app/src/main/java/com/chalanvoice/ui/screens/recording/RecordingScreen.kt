package com.chalanvoice.ui.screens.recording

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.IBinder
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.chalanvoice.R
import com.chalanvoice.ui.models.*
import com.chalanvoice.services.ForegroundAudioService
import com.chalanvoice.ui.theme.AppDimensions
import timber.log.Timber
import java.text.SimpleDateFormat
import java.util.*

/**
 * Pantalla principal de grabación de voz
 * Incluye barra de progreso, guía visual y controles
 */
@Composable
fun RecordingScreen(
    uiState: MainUiState,
    onStartRecording: () -> Unit,
    onStopRecording: () -> Unit,
    onNavigateToTraining: () -> Unit,
    onNavigateToSettings: () -> Unit
) {
    val context = LocalContext.current
    var serviceBound by remember { mutableStateOf(false) }
    var recordingDuration by remember { mutableStateOf(0L) }
    var service: ForegroundAudioService? by remember { mutableStateOf(null) }
    
    // Conexión con el servicio de primer plano
    val serviceConnection = remember {
        object : ServiceConnection {
            override fun onServiceConnected(className: ComponentName, iBinder: IBinder) {
                val binder = iBinder as ForegroundAudioService.LocalBinder
                service = binder.getService()
                serviceBound = true
                Timber.d("Conectado al servicio de grabación")
            }
            
            override fun onServiceDisconnected(arg0: ComponentName) {
                serviceBound = false
                service = null
                Timber.d("Desconectado del servicio de grabación")
            }
        }
    }
    
    // Manejar duración en tiempo real
    LaunchedEffect(uiState.recordingState) {
        when (uiState.recordingState) {
            is RecordingState.Recording -> {
                // Iniciar contador de tiempo
                var startTime = System.currentTimeMillis()
                while (uiState.recordingState == RecordingState.Recording) {
                    recordingDuration = System.currentTimeMillis() - startTime
                    kotlinx.coroutines.delay(100)
                }
            }
            else -> {
                recordingDuration = 0L
            }
        }
    }
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .systemBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(AppDimensions.mediumPadding),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Header con configuraciones
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Grabación de Voz",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                
                IconButton(
                    onClick = onNavigateToSettings,
                    modifier = Modifier.size(48.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = "Configuración",
                        tint = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(AppDimensions.largePadding))
            
            // Estado actual y controles principales
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(AppDimensions.largePadding)
            ) {
                // Visualización de estado de grabación
                RecordingStatus(
                    recordingState = uiState.recordingState,
                    duration = recordingDuration
                )
                
                // Barra de progreso visual (ondas de voz)
                VoiceWaveVisualization(
                    isRecording = uiState.recordingState == RecordingState.Recording,
                    duration = recordingDuration
                )
                
                // Instrucciones dinámicas
                RecordingInstructions(
                    recordingState = uiState.recordingState
                )
                
                // Botón principal de grabación
                RecordingButton(
                    recordingState = uiState.recordingState,
                    hasPermission = uiState.hasPermission,
                    onStartRecording = {
                        if (uiState.hasPermission) {
                            onStartRecording()
                        } else {
                            // Solicitar permisos
                            // Esto se maneja en MainActivity
                        }
                    },
                    onStopRecording = onStopRecording
                )
            }
            
            Spacer(modifier = Modifier.weight(1f))
            
            // Botón de continuar al entrenamiento
            if (uiState.recordingState is RecordingState.Completed) {
                Button(
                    onClick = onNavigateToTraining,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    )
                ) {
                    Text(
                        text = "Continuar al Entrenamiento",
                        style = MaterialTheme.typography.titleMedium
                    )
                }
                
                Spacer(modifier = Modifier.height(AppDimensions.mediumPadding))
            }
            
            // Información de la grabación actual
            uiState.currentRecording?.let { recording ->
                RecordingInfoCard(recording = recording)
            }
        }
    }
}

/**
 * Composable para mostrar el estado actual de la grabación
 */
@Composable
private fun RecordingStatus(
    recordingState: RecordingState,
    duration: Long
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(AppDimensions.smallPadding)
    ) {
        // Estado actual
        Text(
            text = when (recordingState) {
                RecordingState.Idle -> "Listo para grabar"
                RecordingState.RequestingPermission -> "Solicitando permisos..."
                RecordingState.Recording -> "Grabando..."
                RecordingState.Paused -> "Grabación pausada"
                RecordingState.Completed -> "¡Grabación completada!"
                is RecordingState.Error -> "Error: ${recordingState.message}"
                is RecordingState.Saved -> "Grabación guardada"
            },
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Medium,
            color = when (recordingState) {
                RecordingState.Recording -> MaterialTheme.colorScheme.error
                RecordingState.Completed -> MaterialTheme.colorScheme.primary
                is RecordingState.Error -> MaterialTheme.colorScheme.error
                else -> MaterialTheme.colorScheme.onSurface
            }
        )
        
        // Tiempo transcurrido
        if (recordingState == RecordingState.Recording || recordingState == RecordingState.Paused) {
            Text(
                text = formatDuration(duration),
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

/**
 * Composable para visualización de ondas de voz
 */
@Composable
private fun VoiceWaveVisualization(
    isRecording: Boolean,
    duration: Long
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(120.dp),
        contentAlignment = Alignment.Center
    ) {
        if (isRecording) {
            // Simular ondas de voz con barras animadas
            Row(
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                repeat(20) { index ->
                    val waveHeight = (50 + (Math.random() * 100).toInt()) / 4
                    Box(
                        modifier = Modifier
                            .width(3.dp)
                            .height(waveHeight.dp)
                            .clip(CircleShape)
                            .animateContentSize()
                            .align(Alignment.Bottom)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    MaterialTheme.colorScheme.primary.copy(
                                        alpha = 0.6f + (Math.random() * 0.4f).toFloat()
                                    )
                                )
                        )
                    }
                }
            }
        } else {
            // Mostrar icono de micrófono cuando no está grabando
            Icon(
                imageVector = Icons.Default.Mic,
                contentDescription = "Micrófono",
                modifier = Modifier.size(64.dp),
                tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
            )
        }
    }
}

/**
 * Composable para instrucciones dinámicas
 */
@Composable
private fun RecordingInstructions(
    recordingState: RecordingState
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        )
    ) {
        Column(
            modifier = Modifier.padding(AppDimensions.mediumPadding)
        ) {
            when (recordingState) {
                RecordingState.Idle -> {
                    InstructionItem(
                        "Habla claramente durante la grabación",
                        "Asegúrate de estar en un lugar silencioso"
                    )
                }
                RecordingState.Recording -> {
                    InstructionItem(
                        "¡Grabando! Continúa hablando",
                        "Habla de forma natural y clara"
                    )
                }
                RecordingState.Paused -> {
                    InstructionItem(
                        "Grabación pausada",
                        "Toca el botón para reanudar"
                    )
                }
                RecordingState.Completed -> {
                    InstructionItem(
                        "¡Grabación completada!",
                        "Puedes continuar al entrenamiento"
                    )
                }
                is RecordingState.Error -> {
                    InstructionItem(
                        "Error en la grabación",
                        recordingState.message
                    )
                }
                else -> {
                    InstructionItem(
                        "Preparando...",
                        "Iniciando grabación de audio"
                    )
                }
            }
        }
    }
}

/**
 * Item individual de instrucción
 */
@Composable
private fun InstructionItem(
    title: String,
    description: String
) {
    Column(
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface
        )
        
        Text(
            text = description,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
        )
    }
}

/**
 * Botón principal de grabación
 */
@Composable
private fun RecordingButton(
    recordingState: RecordingState,
    hasPermission: Boolean,
    onStartRecording: () -> Unit,
    onStopRecording: () -> Unit
) {
    val isRecording = recordingState == RecordingState.Recording
    val isIdle = recordingState == RecordingState.Idle
    
    Box(
        modifier = Modifier.size(120.dp),
        contentAlignment = Alignment.Center
    ) {
        // Botón principal circular
        if (isIdle || !hasPermission) {
            // Botón para iniciar grabación
            FloatingActionButton(
                onClick = onStartRecording,
                modifier = Modifier.size(100.dp),
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary
            ) {
                Icon(
                    imageVector = Icons.Default.Mic,
                    contentDescription = "Iniciar grabación",
                    modifier = Modifier.size(40.dp)
                )
            }
        } else if (isRecording) {
            // Botón para detener grabación
            FloatingActionButton(
                onClick = onStopRecording,
                modifier = Modifier.size(100.dp),
                containerColor = MaterialTheme.colorScheme.error,
                contentColor = MaterialTheme.colorScheme.onError
            ) {
                Icon(
                    imageVector = Icons.Default.MicOff,
                    contentDescription = "Detener grabación",
                    modifier = Modifier.size(40.dp)
                )
            )
        } else {
            // Estado de pausa u otros
            Box(
                modifier = Modifier
                    .size(100.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.MicOff,
                    contentDescription = "Grabación pausada",
                    modifier = Modifier.size(32.dp),
                    tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                )
            }
        }
        
        // Indicador de estado alrededor del botón
        if (isRecording) {
            Box(
                modifier = Modifier
                    .size(110.dp)
                    .border(
                        width = 2.dp,
                        color = MaterialTheme.colorScheme.error,
                        shape = CircleShape
                    )
            )
        }
    }
}

/**
 * Tarjeta con información de la grabación
 */
@Composable
private fun RecordingInfoCard(recording: AudioRecording) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Column(
            modifier = Modifier.padding(AppDimensions.mediumPadding)
        ) {
            Text(
                text = "Última grabación",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )
            
            Spacer(modifier = Modifier.height(AppDimensions.smallPadding))
            
            Text(
                text = "Archivo: ${recording.fileName}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
            )
            
            Text(
                text = "Duración: ${formatDuration(recording.duration)}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
            )
            
            Text(
                text = "Tamaño: ${formatFileSize(recording.fileSize)}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
            )
        }
    }
}

/**
 * Formatea la duración en formato legible
 */
private fun formatDuration(millis: Long): String {
    val seconds = millis / 1000
    val minutes = seconds / 60
    val remainingSeconds = seconds % 60
    
    return "%02d:%02d".format(minutes, remainingSeconds)
}

/**
 * Formatea el tamaño de archivo en formato legible
 */
private fun formatFileSize(bytes: Long): String {
    val kb = 1024
    val mb = kb * 1024
    
    return when {
        bytes >= mb -> "%.1f MB".format(bytes.toFloat() / mb)
        bytes >= kb -> "%.1f KB".format(bytes.toFloat() / kb)
        else -> "$bytes bytes"
    }
}