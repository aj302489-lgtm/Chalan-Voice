package com.chalanvoice.ui.screens.training

import androidx.compose.animation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.chalanvoice.ui.models.*
import com.chalanvoice.ui.theme.AppDimensions
import kotlinx.coroutines.delay

/**
 * Pantalla de entrenamiento del modelo de voz
 * Muestra el progreso del envío y procesamiento del audio
 */
@Composable
fun TrainingScreen(
    uiState: MainUiState,
    onStartTraining: () -> Unit,
    onTrainingCompleted: () -> Unit,
    onNavigateBack: () -> Unit
) {
    // Estado local para animación de progreso
    var displayProgress by remember { mutableStateOf(0f) }
    
    // Manejar progreso según el estado de entrenamiento
    LaunchedEffect(uiState.trainingState) {
        when (val state = uiState.trainingState) {
            TrainingState.Uploading -> {
                // Animar progreso de subida
                animateProgress(0f, 25f) { progress -> displayProgress = progress }
            }
            TrainingState.Processing -> {
                // Animar progreso de procesamiento
                animateProgress(25f, 75f) { progress -> displayProgress = progress }
            }
            TrainingState.Completed -> {
                // Completar progreso
                animateProgress(75f, 100f) { progress -> displayProgress = progress }
                
                // Esperar un momento antes de navegar
                delay(2000)
                onTrainingCompleted()
            }
            is TrainingState.Error -> {
                // Resetear progreso en caso de error
                displayProgress = 0f
            }
            else -> {
                displayProgress = 0f
            }
        }
    }
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .systemBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(AppDimensions.mediumPadding),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header con botón de volver
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = AppDimensions.mediumPadding),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onNavigateBack,
                    modifier = Modifier.size(48.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Volver",
                        tint = MaterialTheme.colorScheme.onSurface
                    )
                }
                
                Text(
                    text = "Entrenamiento del Modelo",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground,
                    textAlign = TextAlign.Center
                )
                
                Spacer(modifier = Modifier.size(48.dp)) // Para balancear el header
            }
            
            Spacer(modifier = Modifier.height(AppDimensions.largePadding))
            
            // Contenido principal
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(AppDimensions.largePadding),
                modifier = Modifier.weight(1f)
            ) {
                // Icono animado del estado actual
                TrainingAnimation(
                    trainingState = uiState.trainingState
                )
                
                // Título dinámico según el estado
                TrainingTitle(
                    trainingState = uiState.trainingState
                )
                
                // Descripción del proceso
                TrainingDescription(
                    trainingState = uiState.trainingState
                )
                
                // Barra de progreso
                if (uiState.trainingState != TrainingState.Idle && uiState.trainingState !is TrainingState.Error) {
                    TrainingProgressBar(
                        progress = displayProgress,
                        trainingState = uiState.trainingState
                    )
                }
                
                // Información adicional
                TrainingInfoCard(trainingState = uiState.trainingState)
                
                // Botones de acción
                TrainingActions(
                    trainingState = uiState.trainingState,
                    onStartTraining = onStartTraining,
                    onRetryTraining = { 
                        // Resetear estado y reintentar
                        onStartTraining()
                    }
                )
            }
        }
        
        // Mostrar errores globales
        uiState.currentError?.let { error ->
            ErrorBanner(
                message = error,
                onDismiss = { /* Manejado en MainViewModel */ }
            )
        }
    }
}

/**
 * Animación para el icono según el estado
 */
@Composable
private fun TrainingAnimation(
    trainingState: TrainingState
) {
    val icon = when (trainingState) {
        TrainingState.Idle -> Icons.Default.Psychology
        TrainingState.Uploading -> Icons.Default.CloudUpload
        TrainingState.Processing -> Icons.Default.Psychology
        TrainingState.Completed -> Icons.Default.Psychology
        is TrainingState.Error -> Icons.Default.Psychology
    }
    
    val tint = when (trainingState) {
        TrainingState.Idle -> MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
        TrainingState.Uploading -> MaterialTheme.processingColor
        TrainingState.Processing -> MaterialTheme.trainingColor
        TrainingState.Completed -> MaterialTheme.colorScheme.primary
        is TrainingState.Error -> MaterialTheme.colorScheme.error
    }
    
    val size = if (trainingState == TrainingState.Recording) 80.dp else 64.dp
    
    AnimatedContent(
        targetState = trainingState,
        transitionSpec = {
            fadeIn() + slideInVertically() with fadeOut() + slideOutVertically()
        }
    ) { state ->
        Icon(
            imageVector = icon,
            contentDescription = "Estado de entrenamiento",
            modifier = Modifier.size(size),
            tint = tint
        )
    }
}

/**
 * Título dinámico según el estado
 */
@Composable
private fun TrainingTitle(
    trainingState: TrainingState
) {
    val title = when (trainingState) {
        TrainingState.Idle -> "Listo para Entrenar"
        TrainingState.Uploading -> "Subiendo Audio"
        TrainingState.Processing -> "Entrenando Modelo"
        TrainingState.Completed -> "¡Entrenamiento Completado!"
        is TrainingState.Error -> "Error en el Entrenamiento"
    }
    
    Text(
        text = title,
        style = MaterialTheme.typography.headlineMedium,
        fontWeight = FontWeight.Bold,
        textAlign = TextAlign.Center,
        color = when (trainingState) {
            TrainingState.Idle -> MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
            TrainingState.Uploading -> MaterialTheme.processingColor
            TrainingState.Processing -> MaterialTheme.trainingColor
            TrainingState.Completed -> MaterialTheme.colorScheme.primary
            is TrainingState.Error -> MaterialTheme.colorScheme.error
        }
    )
}

/**
 * Descripción del proceso actual
 */
@Composable
private fun TrainingDescription(
    trainingState: TrainingState
) {
    val description = when (trainingState) {
        TrainingState.Idle -> "Tu grabación de audio se enviará al servidor para entrenar un modelo personalizado de síntesis de voz."
        TrainingState.Uploading -> "Subiendo tu audio al servidor. Esto puede tomar unos momentos..."
        TrainingState.Processing -> "El modelo está siendo entrenado con tu voz. Este proceso puede durar entre 5-10 minutos."
        TrainingState.Completed -> "¡Excelente! Tu modelo personalizado ha sido entrenado exitosamente."
        is TrainingState.Error -> "Ha ocurrido un error durante el entrenamiento. ${trainingState.message}"
    }
    
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        ),
        shape = RoundedCornerShape(AppDimensions.mediumBorderRadius)
    ) {
        Column(
            modifier = Modifier.padding(AppDimensions.mediumPadding)
        ) {
            Text(
                text = description,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f),
                textAlign = TextAlign.Center
            )
        }
    }
}

/**
 * Barra de progreso animada
 */
@Composable
private fun TrainingProgressBar(
    progress: Float,
    trainingState: TrainingState
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Barra de progreso circular
        CircularProgressIndicator(
            progress = progress / 100f,
            modifier = Modifier.size(120.dp),
            strokeWidth = 8.dp,
            color = when (trainingState) {
                TrainingState.Uploading -> MaterialTheme.processingColor
                TrainingState.Processing -> MaterialTheme.trainingColor
                TrainingState.Completed -> MaterialTheme.colorScheme.primary
                else -> MaterialTheme.colorScheme.primary
            }
        )
        
        Spacer(modifier = Modifier.height(AppDimensions.smallPadding))
        
        // Porcentaje de progreso
        Text(
            text = "${progress.toInt()}%",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )
        
        // Etiqueta de estado
        val statusLabel = when (trainingState) {
            TrainingState.Uploading -> "Subiendo..."
            TrainingState.Processing -> "Procesando..."
            TrainingState.Completed -> "Completado"
            else -> ""
        }
        
        if (statusLabel.isNotEmpty()) {
            Text(
                text = statusLabel,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
            )
        }
    }
}

/**
 * Tarjeta con información adicional
 */
@Composable
private fun TrainingInfoCard(
    trainingState: TrainingState
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = when (trainingState) {
                TrainingState.Uploading -> MaterialTheme.processingColor.copy(alpha = 0.1f)
                TrainingState.Processing -> MaterialTheme.trainingColor.copy(alpha = 0.1f)
                TrainingState.Completed -> MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)
                is TrainingState.Error -> MaterialTheme.colorScheme.error.copy(alpha = 0.1f)
                else -> MaterialTheme.colorScheme.surfaceVariant
            }
        )
    ) {
        Column(
            modifier = Modifier.padding(AppDimensions.mediumPadding)
        ) {
            when (trainingState) {
                TrainingState.Uploading -> {
                    Text(
                        text = "📤 Preparando datos para envío...",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                TrainingState.Processing -> {
                    Text(
                        text = "🧠 Analizando patrones de tu voz...",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Este proceso usa técnicas de IA avanzada para crear tu modelo personalizado.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                    )
                }
                TrainingState.Completed -> {
                    Text(
                        text = "✅ Modelo listo para usar",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Ahora puedes generar voz con tus características únicas.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                    )
                }
                is TrainingState.Error -> {
                    Text(
                        text = "❌ Error detectado",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.error
                    )
                }
                else -> {
                    Text(
                        text = "ℹ️ Información del proceso",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                    )
                }
            }
        }
    }
}

/**
 * Botones de acción según el estado
 */
@Composable
private fun TrainingActions(
    trainingState: TrainingState,
    onStartTraining: () -> Unit,
    onRetryTraining: () -> Unit
) {
    when (trainingState) {
        TrainingState.Idle -> {
            Button(
                onClick = onStartTraining,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                )
            ) {
                Text(
                    text = "Iniciar Entrenamiento",
                    style = MaterialTheme.typography.titleMedium
                )
            }
        }
        
        is TrainingState.Error -> {
            Button(
                onClick = onRetryTraining,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.error,
                    contentColor = MaterialTheme.colorScheme.onError
                )
            ) {
                Text(
                    text = "Reintentar",
                    style = MaterialTheme.typography.titleMedium
                )
            }
        }
        
        else -> {
            // Durante el procesamiento, mostrar un botón cancel
            // (implementación futura)
            Spacer(modifier = Modifier.height(AppDimensions.mediumPadding))
        }
    }
}

/**
 * Banner de error global
 */
@Composable
private fun ErrorBanner(
    message: String,
    onDismiss: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(AppDimensions.smallPadding),
        contentAlignment = Alignment.TopCenter
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.errorContainer
            ),
            shape = RoundedCornerShape(AppDimensions.mediumBorderRadius)
        ) {
            Row(
                modifier = Modifier.padding(AppDimensions.mediumPadding),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "⚠️ $message",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onErrorContainer,
                    modifier = Modifier.weight(1f)
                )
                
                TextButton(
                    onClick = onDismiss
                ) {
                    Text("Cerrar")
                }
            }
        }
    }
}

/**
 * Función para animar el progreso
 */
private suspend fun animateProgress(
    from: Float,
    to: Float,
    onProgressUpdate: (Float) -> Unit
) {
    val duration = 1500L // 1.5 segundos
    val steps = 30
    val stepDuration = duration / steps
    
    for (i in 0..steps) {
        val progress = from + (to - from) * (i.toFloat() / steps)
        onProgressUpdate(progress)
        delay(stepDuration)
    }
}