package com.chalanvoice.ui.screens.tts

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.chalanvoice.ui.models.*
import com.chalanvoice.ui.theme.AppDimensions
import kotlinx.coroutines.launch

/**
 * Pantalla del generador de texto a voz
 * Permite ingresar texto, seleccionar emoción y generar audio
 */
@Composable
fun TtsGeneratorScreen(
    uiState: MainUiState,
    onGenerateVoice: (TtsParams) -> Unit,
    onNavigateToPlayer: (String) -> Unit,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    
    // Estado local del generador
    var textInput by remember { mutableStateOf("") }
    var selectedEmotion by remember { mutableStateOf(VoiceEmotion.NEUTRAL) }
    var showEmotionPicker by remember { mutableStateOf(false) }
    var showExamples by remember { mutableStateOf(false) }
    
    // Ejemplos de texto para demostrar la funcionalidad
    val exampleTexts = listOf(
        "Hola, soy tu asistente de voz personalizado.",
        "Bienvenido a Chalan Voice, tu tecnología de síntesis de voz avanzada.",
        "La inteligencia artificial está revolucionando la forma en que nos comunicamos.",
        "Este es un ejemplo de texto que se convertirá en voz con mi modelo personalizado.",
        "La tecnología de síntesis de voz permite crear experiencias naturales e interactivas."
    )
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .systemBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(AppDimensions.mediumPadding),
            verticalArrangement = Arrangement.spacedBy(AppDimensions.mediumPadding)
        ) {
            // Header
            TtsHeader(
                onNavigateBack = onNavigateBack,
                onShowExamples = { showExamples = true }
            )
            
            // Contenido principal
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(AppDimensions.largePadding)
            ) {
                // Información del usuario
                uiState.userInfo?.let { userInfo ->
                    if (userInfo.modelTrained) {
                        UserModelStatusCard(userInfo = userInfo)
                    } else {
                        NoModelWarningCard()
                    }
                }
                
                // Campo de texto
                item {
                    TextInputCard(
                        textInput = textInput,
                        onTextChange = { textInput = it },
                        maxLength = 1000
                    )
                }
                
                // Selector de emoción
                item {
                    EmotionSelector(
                        selectedEmotion = selectedEmotion,
                        onEmotionChange = { selectedEmotion = it },
                        onShowPicker = { showEmotionPicker = true }
                    )
                }
                
                // Configuraciones adicionales
                item {
                    AdvancedSettingsCard(
                        selectedEmotion = selectedEmotion,
                        onEmotionChange = { selectedEmotion = it }
                    )
                }
                
                // Botón de generar
                item {
                    GenerateButton(
                        text = textInput,
                        isGenerating = uiState.ttsState is TtsState.Generating,
                        hasModel = uiState.userInfo?.modelTrained == true,
                        onGenerate = {
                            val params = TtsParams(
                                text = textInput,
                                emotion = selectedEmotion
                            )
                            onGenerateVoice(params)
                        }
                    )
                }
                
                // Estado de generación
                item {
                    when (val ttsState = uiState.ttsState) {
                        is TtsState.Completed -> {
                            GeneratedAudioCard(
                                audioPath = ttsState.audioPath,
                                onPlayAudio = { onNavigateToPlayer(ttsState.audioPath) }
                            )
                        }
                        is TtsState.Error -> {
                            ErrorCard(
                                error = ttsState.message,
                                onRetry = {
                                    val params = TtsParams(
                                        text = textInput,
                                        emotion = selectedEmotion
                                    )
                                    onGenerateVoice(params)
                                }
                            )
                        }
                        else -> { /* No mostrar nada */ }
                    }
                }
            }
        }
        
        // Diálogos
        if (showEmotionPicker) {
            EmotionPickerDialog(
                selectedEmotion = selectedEmotion,
                onEmotionSelected = { selectedEmotion = it },
                onDismiss = { showEmotionPicker = false }
            )
        }
        
        if (showExamples) {
            ExamplesDialog(
                examples = exampleTexts,
                onExampleSelected = { text -> 
                    textInput = text
                    showExamples = false
                },
                onDismiss = { showExamples = false }
            )
        }
    }
}

/**
 * Header de la pantalla TTS
 */
@Composable
private fun TtsHeader(
    onNavigateBack: () -> Unit,
    onShowExamples: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = AppDimensions.mediumPadding),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(
            onClick = onNavigateBack,
            modifier = Modifier.size(48.dp)
        ) {
            Icon(
                imageVector = Icons.Default.ArrowBack,
                contentDescription = "Volver",
                tint = MaterialTheme.colorScheme.onSurface
            )
        }
        
        Text(
            text = "Generador de Voz",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground,
            textAlign = TextAlign.Center
        )
        
        TextButton(
            onClick = onShowExamples
        ) {
            Text("Ejemplos")
        }
    }
}

/**
 * Tarjeta de estado del modelo del usuario
 */
@Composable
private fun UserModelStatusCard(userInfo: UserInfo) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer
        ),
        shape = RoundedCornerShape(AppDimensions.mediumBorderRadius)
    ) {
        Column(
            modifier = Modifier.padding(AppDimensions.mediumPadding)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.VolumeUp,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.width(AppDimensions.smallPadding))
                Text(
                    text = "Modelo Personalizado Activo",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
            }
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Text(
                text = "Tu modelo entrenado está listo para generar voz con tus características únicas.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
            )
            
            userInfo.modelId?.let { modelId ->
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "ID: $modelId",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.6f)
                )
            }
        }
    }
}

/**
 * Tarjeta de advertencia cuando no hay modelo
 */
@Composable
private fun NoModelWarningCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.errorContainer
        ),
        shape = RoundedCornerShape(AppDimensions.mediumBorderRadius)
    ) {
        Column(
            modifier = Modifier.padding(AppDimensions.mediumPadding)
        ) {
            Text(
                text = "⚠️ Modelo no entrenado",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onErrorContainer
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Text(
                text = "Debes entrenar un modelo personalizado primero para generar voz con tus características.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onErrorContainer.copy(alpha = 0.8f)
            )
        }
    }
}

/**
 * Tarjeta de entrada de texto
 */
@Composable
private fun TextInputCard(
    textInput: String,
    onTextChange: (String) -> Unit,
    maxLength: Int
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        ),
        shape = RoundedCornerShape(AppDimensions.mediumBorderRadius)
    ) {
        Column(
            modifier = Modifier.padding(AppDimensions.mediumPadding)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Texto a convertir",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                
                Text(
                    text = "${textInput.length}/$maxLength",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
            }
            
            Spacer(modifier = Modifier.height(AppDimensions.smallPadding))
            
            OutlinedTextField(
                value = textInput,
                onValueChange = { 
                    if (it.length <= maxLength) {
                        onTextChange(it)
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                placeholder = {
                    Text("Ingresa el texto que deseas convertir a voz...")
                },
                minLines = 3,
                maxLines = 6,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline,
                    focusedTextColor = MaterialTheme.colorScheme.onSurface,
                    unfocusedTextColor = MaterialTheme.colorScheme.onSurface
                )
            )
        }
    }
}

/**
 * Selector de emoción
 */
@Composable
private fun EmotionSelector(
    selectedEmotion: VoiceEmotion,
    onEmotionChange: (VoiceEmotion) -> Unit,
    onShowPicker: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        shape = RoundedCornerShape(AppDimensions.mediumBorderRadius)
    ) {
        Column(
            modifier = Modifier.padding(AppDimensions.mediumPadding)
        ) {
            Text(
                text = "Emoción",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )
            
            Spacer(modifier = Modifier.height(AppDimensions.smallPadding))
            
            OutlinedButton(
                onClick = onShowPicker,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = MaterialTheme.colorScheme.outline
                )
            ) {
                Icon(
                    imageVector = Icons.Default.VolumeUp,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                
                Spacer(modifier = Modifier.width(AppDimensions.smallPadding))
                
                Text(
                    text = "Emoción actual: ${selectedEmotion.displayName}",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }
}

/**
 * Configuraciones avanzadas (placeholder)
 */
@Composable
private fun AdvancedSettingsCard(
    selectedEmotion: VoiceEmotion,
    onEmotionChange: (VoiceEmotion) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.5f)
        ),
        shape = RoundedCornerShape(AppDimensions.mediumBorderRadius)
    ) {
        Column(
            modifier = Modifier.padding(AppDimensions.mediumPadding)
        ) {
            Text(
                text = "Configuraciones Avanzadas",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
            )
            
            Spacer(modifier = Modifier.height(AppDimensions.smallPadding))
            
            Text(
                text = "Velocidad, tono y volumen pueden ajustarse según la emoción seleccionada.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
            )
            
            // TODO: Implementar controles deslizantes para velocidad, tono y volumen
        }
    }
}

/**
 * Botón de generar voz
 */
@Composable
private fun GenerateButton(
    text: String,
    isGenerating: Boolean,
    hasModel: Boolean,
    onGenerate: () -> Unit
) {
    val isValid = text.isNotBlank() && text.length >= 5 && hasModel
    
    Button(
        onClick = onGenerate,
        enabled = isValid && !isGenerating,
        modifier = Modifier
            .fillMaxWidth()
            .height(56.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (hasModel) MaterialTheme.colorScheme.primary 
                           else MaterialTheme.colorScheme.outline,
            contentColor = if (hasModel) MaterialTheme.colorScheme.onPrimary
                          else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
            disabledContainerColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
            disabledContentColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
        )
    ) {
        if (isGenerating) {
            CircularProgressIndicator(
                modifier = Modifier.size(24.dp),
                color = MaterialTheme.colorScheme.onPrimary
            )
        } else {
            Icon(
                imageVector = Icons.Default.PlayArrow,
                contentDescription = null,
                modifier = Modifier.size(24.dp)
            )
        }
        
        Spacer(modifier = Modifier.width(AppDimensions.smallPadding))
        
        Text(
            text = when {
                isGenerating -> "Generando..."
                !hasModel -> "Entrena un modelo primero"
                !isValid -> "Texto muy corto"
                else -> "Generar Voz"
            },
            style = MaterialTheme.typography.titleMedium
        )
    }
}

/**
 * Tarjeta del audio generado
 */
@Composable
private fun GeneratedAudioCard(
    audioPath: String,
    onPlayAudio: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer
        ),
        shape = RoundedCornerShape(AppDimensions.mediumBorderRadius)
    ) {
        Column(
            modifier = Modifier.padding(AppDimensions.mediumPadding)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.VolumeUp,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
                
                Spacer(modifier = Modifier.width(AppDimensions.smallPadding))
                
                Text(
                    text = "¡Audio generado exitosamente!",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
            }
            
            Spacer(modifier = Modifier.height(AppDimensions.mediumPadding))
            
            Button(
                onClick = onPlayAudio,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                )
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = null
                )
                
                Spacer(modifier = Modifier.width(AppDimensions.smallPadding))
                
                Text("Reproducir Audio")
            }
        }
    }
}

/**
 * Tarjeta de error
 */
@Composable
private fun ErrorCard(
    error: String,
    onRetry: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.errorContainer
        ),
        shape = RoundedCornerShape(AppDimensions.mediumBorderRadius)
    ) {
        Column(
            modifier = Modifier.padding(AppDimensions.mediumPadding)
        ) {
            Text(
                text = "❌ Error en la generación",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onErrorContainer
            )
            
            Spacer(modifier = Modifier.height(AppDimensions.smallPadding))
            
            Text(
                text = error,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onErrorContainer.copy(alpha = 0.8f)
            )
            
            Spacer(modifier = Modifier.height(AppDimensions.mediumPadding))
            
            Button(
                onClick = onRetry,
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.error,
                    contentColor = MaterialTheme.colorScheme.onError
                )
            ) {
                Text("Reintentar")
            }
        }
    }
}

/**
 * Diálogo selector de emociones
 */
@Composable
private fun EmotionPickerDialog(
    selectedEmotion: VoiceEmotion,
    onEmotionSelected: (VoiceEmotion) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Seleccionar Emoción")
        },
        text = {
            LazyColumn {
                items(VoiceEmotion.values()) { emotion ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(AppDimensions.smallBorderRadius))
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = emotion == selectedEmotion,
                            onClick = { onEmotionSelected(emotion) }
                        )
                        
                        Spacer(modifier = Modifier.width(AppDimensions.smallPadding))
                        
                        Text(
                            text = emotion.displayName,
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (emotion == selectedEmotion) {
                                MaterialTheme.colorScheme.primary
                            } else {
                                MaterialTheme.colorScheme.onSurface
                            }
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Confirmar")
            }
        }
    )
}

/**
 * Diálogo de ejemplos
 */
@Composable
private fun ExamplesDialog(
    examples: List<String>,
    onExampleSelected: (String) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Ejemplos de Texto")
        },
        text = {
            LazyColumn {
                items(examples) { example ->
                    TextButton(
                        onClick = { onExampleSelected(example) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = example,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface,
                            textAlign = TextAlign.Start
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Cerrar")
            }
        }
    )
}