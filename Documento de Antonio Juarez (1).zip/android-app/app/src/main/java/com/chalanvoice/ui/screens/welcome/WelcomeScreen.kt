package com.chalanvoice.ui.screens.welcome

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.chalanvoice.R
import com.chalanvoice.ui.theme.AppDimensions

/**
 * Pantalla de bienvenida con consentimientos éticos
 */
@Composable
fun WelcomeScreen(
    onEthicsAccepted: () -> Unit,
    onDeclineEthics: () -> Unit
) {
    var showEthicsDialog by remember { mutableStateOf(false) }
    val scrollState = rememberScrollState()
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .systemBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(AppDimensions.mediumPadding)
                .verticalScroll(scrollState),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(AppDimensions.largePadding))
            
            // Logo e icono de la aplicación
            Icon(
                imageVector = Icons.Default.Mic,
                contentDescription = "Chalan Voice",
                modifier = Modifier.size(80.dp),
                tint = MaterialTheme.colorScheme.primary
            )
            
            Spacer(modifier = Modifier.height(AppDimensions.mediumPadding))
            
            // Título principal
            Text(
                text = "Bienvenido a Chalan Voice",
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onBackground
            )
            
            Spacer(modifier = Modifier.height(AppDimensions.smallPadding))
            
            // Subtítulo
            Text(
                text = "Tu asistente de voz inteligente personalizado",
                style = MaterialTheme.typography.bodyLarge,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.8f)
            )
            
            Spacer(modifier = Modifier.height(AppDimensions.extraLargePadding))
            
            // Información sobre la aplicación
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Column(
                    modifier = Modifier.padding(AppDimensions.mediumPadding)
                ) {
                    Text(
                        text = "¿Qué es Chalan Voice?",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    
                    Spacer(modifier = Modifier.height(AppDimensions.smallPadding))
                    
                    Text(
                        text = "Chalan Voice te permite entrenar tu propio modelo de síntesis de voz a partir de grabaciones personales. Una vez entrenado, puedes generar voz natural con diferentes emociones.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(AppDimensions.mediumPadding))
            
            // Características principales
            Text(
                text = "Características principales:",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onBackground
            )
            
            Spacer(modifier = Modifier.height(AppDimensions.smallPadding))
            
            FeatureList()
            
            Spacer(modifier = Modifier.height(AppDimensions.extraLargePadding))
            
            // Botones de acción
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(AppDimensions.smallPadding)
            ) {
                OutlinedButton(
                    onClick = onDeclineEthics,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = MaterialTheme.colorScheme.outline
                    )
                ) {
                    Text("Rechazar")
                }
                
                Button(
                    onClick = { showEthicsDialog = true },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    )
                ) {
                    Text("Continuar")
                }
            }
        }
        
        // Diálogo de consentimientos éticos
        if (showEthicsDialog) {
            EthicsDialog(
                onAccept = {
                    showEthicsDialog = false
                    onEthicsAccepted()
                },
                onDismiss = {
                    showEthicsDialog = false
                }
            )
        }
    }
}

/**
 * Lista de características de la aplicación
 */
@Composable
private fun FeatureList() {
    val features = listOf(
        "🎤 Grabación de voz de alta calidad",
        "🤖 Entrenamiento de modelo personalizado",
        "🎭 Síntesis con múltiples emociones",
        "🔒 Procesamiento seguro en servidor",
        "📱 Interfaz intuitiva y moderna",
        "⚡ Generación rápida de audio"
    )
    
    Column(
        verticalArrangement = Arrangement.spacedBy(AppDimensions.smallPadding)
    ) {
        features.forEach { feature ->
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = feature,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.9f)
                )
            }
        }
    }
}

/**
 * Diálogo de consentimientos éticos
 */
@Composable
private fun EthicsDialog(
    onAccept: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Consentimiento Ético",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(AppDimensions.smallPadding)
            ) {
                Text(
                    text = "Al usar Chalan Voice, confirmas que:",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold
                )
                
                EthicsItem("No usarás la aplicación para generar contenido dañino o ilegal")
                EthicsItem("Respetarás los derechos de propiedad intelectual")
                EthicsItem("No generarás voces de terceros sin consentimiento")
                EthicsItem("El audio generado debe usarse responsablemente")
                EthicsItem("Chalan Voice no se hace responsable del mal uso")
                
                Spacer(modifier = Modifier.height(AppDimensions.smallPadding))
                
                Text(
                    text = "¿Aceptas estos términos para continuar?",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = onAccept,
                colors = ButtonDefaults.textButtonColors(
                    contentColor = MaterialTheme.colorScheme.primary
                )
            ) {
                Text("Aceptar Términos")
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                colors = ButtonDefaults.textButtonColors(
                    contentColor = MaterialTheme.colorScheme.outline
                )
            ) {
                Text("Cancelar")
            }
        }
    )
}

/**
 * Elemento individual de la lista de ética
 */
@Composable
private fun EthicsItem(text: String) {
    Row(
        verticalAlignment = Alignment.Top,
        modifier = Modifier.padding(start = AppDimensions.smallPadding)
    ) {
        Text(
            text = "•",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.primary
        )
        
        Spacer(modifier = Modifier.width(AppDimensions.smallPadding))
        
        Text(
            text = text,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}