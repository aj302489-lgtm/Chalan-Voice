package com.chalanvoice.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

/**
 * Esquema de colores para tema oscuro (principal)
 */
private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFF6750A4),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFF21005D),
    onPrimaryContainer = Color(0xFFE6E1E5),
    
    secondary = Color(0xFF625B71),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFF4A4458),
    onSecondaryContainer = Color(0xFFE6E1E5),
    
    tertiary = Color(0xFF7D5260),
    onTertiary = Color(0xFFFFFFFF),
    tertiaryContainer = Color(0xFF633B48),
    onTertiaryContainer = Color(0xFFE6E1E5),
    
    error = Color(0xFFBA1A1A),
    errorContainer = Color(0xFF93000A),
    onError = Color(0xFFFFFFFF),
    onErrorContainer = Color(0xFFFFDAD6),
    
    background = Color(0xFF121213),
    onBackground = Color(0xFFE6E1E5),
    
    surface = Color(0xFF1C1B1F),
    onSurface = Color(0xFFE6E1E5),
    surfaceVariant = Color(0xFF49454F),
    onSurfaceVariant = Color(0xFFCAC4D0),
    
    outline = Color(0xFF938F99),
    outlineVariant = Color(0xFF49454F),
    
    scrim = Color(0xFF000000),
    inverseSurface = Color(0xFFE6E1E5),
    inverseOnSurface = Color(0xFF1C1B1F),
    inversePrimary = Color(0xFFD0BCFF),
    
    surfaceTint = Color(0xFFD0BCFF),
    
    // Colores específicos de la aplicación
    voiceWavePrimary = Color(0xFF6750A4),
    voiceWaveSecondary = Color(0xFF625B71),
    recordingColor = Color(0xFFF44336),
    trainingColor = Color(0xFF4CAF50),
    processingColor = Color(0xFFFF9800)
)

/**
 * Esquema de colores para tema claro (alternativo)
 */
private val LightColorScheme = lightColorScheme(
    primary = Color(0xFF6750A4),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFEADDFF),
    onPrimaryContainer = Color(0xFF21005D),
    
    secondary = Color(0xFF625B71),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFE8DEF8),
    onSecondaryContainer = Color(0xFF4A4458),
    
    tertiary = Color(0xFF7D5260),
    onTertiary = Color(0xFFFFFFFF),
    tertiaryContainer = Color(0xFFFFD8E4),
    onTertiaryContainer = Color(0xFF633B48),
    
    error = Color(0xFFBA1A1A),
    errorContainer = Color(0xFFFFDAD6),
    onError = Color(0xFFFFFFFF),
    onErrorContainer = Color(0xFF93000A),
    
    background = Color(0xFFFFFBFE),
    onBackground = Color(0xFF1C1B1F),
    
    surface = Color(0xFFFFFBFE),
    onSurface = Color(0xFF1C1B1F),
    surfaceVariant = Color(0xFFE7E0EC),
    onSurfaceVariant = Color(0xFF49454F),
    
    outline = Color(0xFF79747E),
    outlineVariant = Color(0xFFCAC4D0),
    
    scrim = Color(0xFF000000),
    inverseSurface = Color(0xFF313033),
    inverseOnSurface = Color(0xFFF4EFF4),
    inversePrimary = Color(0xFFD0BCFF),
    
    surfaceTint = Color(0xFF6750A4),
    
    // Colores específicos de la aplicación
    voiceWavePrimary = Color(0xFF6750A4),
    voiceWaveSecondary = Color(0xFF625B71),
    recordingColor = Color(0xFFF44336),
    trainingColor = Color(0xFF4CAF50),
    processingColor = Color(0xFFFF9800)
)

/**
 * Temas de la aplicación Chalan Voice
 */
object AppTheme {
    val colors: AppColors
        @Composable
        get() = if (isSystemInDarkTheme()) {
            DarkAppColors
        } else {
            LightAppColors
        }
}

/**
 * Extensión para acceder a colores específicos de la app en MaterialTheme
 */
val MaterialTheme.voiceWavePrimary: Color
    get() = AppTheme.colors.voiceWavePrimary

val MaterialTheme.voiceWaveSecondary: Color
    get() = AppTheme.colors.voiceWaveSecondary

val MaterialTheme.recordingColor: Color
    get() = AppTheme.colors.recordingColor

val MaterialTheme.trainingColor: Color
    get() = AppTheme.colors.trainingColor

val MaterialTheme.processingColor: Color
    get() = AppTheme.colors.processingColor

/**
 * Colores específicos de la aplicación
 */
data class AppColors(
    val voiceWavePrimary: Color,
    val voiceWaveSecondary: Color,
    val recordingColor: Color,
    val trainingColor: Color,
    val processingColor: Color
)

private val DarkAppColors = AppColors(
    voiceWavePrimary = Color(0xFF6750A4),
    voiceWaveSecondary = Color(0xFF625B71),
    recordingColor = Color(0xFFF44336),
    trainingColor = Color(0xFF4CAF50),
    processingColor = Color(0xFFFF9800)
)

private val LightAppColors = AppColors(
    voiceWavePrimary = Color(0xFF6750A4),
    voiceWaveSecondary = Color(0xFF625B71),
    recordingColor = Color(0xFFF44336),
    trainingColor = Color(0xFF4CAF50),
    processingColor = Color(0xFFFF9800)
)

/**
 * Composable principal del tema
 */
@Composable
fun ChalanVoiceTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }

        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }
    
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colorScheme.primary.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = darkTheme
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

/**
 * Dimensiones y espaciados consistentes
 */
object AppDimensions {
    val smallPadding = androidx.compose.ui.unit.dp(8)
    val mediumPadding = androidx.compose.ui.unit.dp(16)
    val largePadding = androidx.compose.ui.unit.dp(24)
    val extraLargePadding = androidx.compose.ui.unit.dp(32)
    
    val smallBorderRadius = androidx.compose.ui.unit.dp(4)
    val mediumBorderRadius = androidx.compose.ui.unit.dp(8)
    val largeBorderRadius = androidx.compose.ui.unit.dp(16)
    val extraLargeBorderRadius = androidx.compose.ui.unit.dp(24)
    
    val smallIconSize = androidx.compose.ui.unit.dp(24)
    val mediumIconSize = androidx.compose.ui.unit.dp(32)
    val largeIconSize = androidx.compose.ui.unit.dp(48)
    val extraLargeIconSize = androidx.compose.ui.unit.dp(64)
    
    val smallElevation = androidx.compose.ui.unit.dp(4)
    val mediumElevation = androidx.compose.ui.unit.dp(8)
    val largeElevation = androidx.compose.ui.unit.dp(16)
    val extraLargeElevation = androidx.compose.ui.unit.dp(24)
}

/**
 * Animaciones y transiciones de la aplicación
 */
object AppAnimations {
    val fastAnimation = androidx.compose.animation.core.spring(
        stiffness = androidx.compose.animation.core.StiffnessVeryLow,
        dampingRatio = androidx.compose.animation.core.DampingRatioLowBouncy
    )
    
    val mediumAnimation = androidx.compose.animation.core.spring(
        stiffness = androidx.compose.animation.core.StiffnessLow,
        dampingRatio = androidx.compose.animation.core.DampingRatioMediumBouncy
    )
    
    val slowAnimation = androidx.compose.animation.core.spring(
        stiffness = androidx.compose.animation.core.StiffnessMedium,
        dampingRatio = androidx.compose.animation.core.DampingRatioHighBouncy
    )
}

/**
 * Estilos personalizados para componentes
 */
object AppStyles {
    
    @Composable
    fun VoiceWaveStyle() = androidx.compose.material3.LinearProgressIndicatorDefaults.colors(
        indicatorColor = MaterialTheme.voiceWavePrimary,
        trackColor = MaterialTheme.voiceWaveSecondary.copy(alpha = 0.3f),
        disabledIndicatorColor = MaterialTheme.voiceWavePrimary.copy(alpha = 0.5f),
        disabledTrackColor = MaterialTheme.voiceWaveSecondary.copy(alpha = 0.2f)
    )
    
    @Composable
    fun RecordingButtonStyle() = androidx.compose.material3.ButtonDefaults.buttonColors(
        containerColor = MaterialTheme.recordingColor,
        contentColor = MaterialTheme.colorScheme.onPrimary,
        disabledContainerColor = MaterialTheme.recordingColor.copy(alpha = 0.5f),
        disabledContentColor = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.5f)
    )
    
    @Composable
    fun TrainingButtonStyle() = androidx.compose.material3.ButtonDefaults.buttonColors(
        containerColor = MaterialTheme.trainingColor,
        contentColor = MaterialTheme.colorScheme.onPrimary,
        disabledContainerColor = MaterialTheme.trainingColor.copy(alpha = 0.5f),
        disabledContentColor = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.5f)
    )
    
    @Composable
    fun ProcessingButtonStyle() = androidx.compose.material3.ButtonDefaults.buttonColors(
        containerColor = MaterialTheme.processingColor,
        contentColor = MaterialTheme.colorScheme.onPrimary,
        disabledContainerColor = MaterialTheme.processingColor.copy(alpha = 0.5f),
        disabledContentColor = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.5f)
    )
}