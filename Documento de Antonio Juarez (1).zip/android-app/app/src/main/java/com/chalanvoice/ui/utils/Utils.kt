package com.chalanvoice.ui.utils

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import androidx.core.content.FileProvider
import java.io.File

/**
 * Utilidades para manejo de archivos de audio
 */
object AudioFileUtils {
    
    /**
     * Obtiene el directorio de audios de la aplicación
     */
    fun getAudioDirectory(context: Context): File {
        val audioDir = File(
            context.getExternalFilesDir(Environment.DIRECTORY_MUSIC),
            "ChalanVoice"
        )
        if (!audioDir.exists()) {
            audioDir.mkdirs()
        }
        return audioDir
    }
    
    /**
     * Obtiene la URI del archivo para compartir
     */
    fun getShareableFileUri(context: Context, file: File): Uri {
        return FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
    }
    
    /**
     * Crea un intent para compartir archivo de audio
     */
    fun createShareIntent(context: Context, file: File): Intent {
        val uri = getShareableFileUri(context, file)
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "audio/*"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        return Intent.createChooser(shareIntent, "Compartir audio")
    }
    
    /**
     * Verifica si el archivo existe y es accesible
     */
    fun isFileValid(filePath: String): Boolean {
        val file = File(filePath)
        return file.exists() && file.isFile && file.canRead()
    }
    
    /**
     * Formatea el tamaño del archivo en formato legible
     */
    fun formatFileSize(bytes: Long): String {
        val kb = 1024
        val mb = kb * 1024
        val gb = mb * 1024
        
        return when {
            bytes >= gb -> "%.1f GB".format(bytes.toFloat() / gb)
            bytes >= mb -> "%.1f MB".format(bytes.toFloat() / mb)
            bytes >= kb -> "%.1f KB".format(bytes.toFloat() / kb)
            else -> "$bytes bytes"
        }
    }
}

/**
 * Utilidades para manejo de permisos
 */
object PermissionUtils {
    
    /**
     * Verifica si tiene permisos de micrófono
     */
    fun hasMicrophonePermission(context: Context): Boolean {
        // Implementar verificación real de permisos
        return true
    }
    
    /**
     * Abre la configuración de la aplicación
     */
    fun openAppSettings(context: Context) {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.fromParts("package", context.packageName, null)
        }
        context.startActivity(intent)
    }
    
    /**
     * Verifica si puede solicitar permisos
     */
    fun shouldShowRequestPermissionRationale(
        context: Context,
        permission: String
    ): Boolean {
        // Implementar lógica para mostrar justificación
        return false
    }
}

/**
 * Utilidades para formateo de tiempo
 */
object TimeUtils {
    
    /**
     * Formatea duración en milisegundos a texto legible
     */
    fun formatDuration(millis: Long): String {
        val seconds = millis / 1000
        val minutes = seconds / 60
        val hours = minutes / 60
        
        return when {
            hours > 0 -> "%d:%02d:%02d".format(hours, minutes % 60, seconds % 60)
            minutes > 0 -> "%d:%02d".format(minutes, seconds % 60)
            else -> "0:%02d".format(seconds)
        }
    }
    
    /**
     * Formatea timestamp a fecha legible
     */
    fun formatTimestamp(timestamp: Long): String {
        val date = java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", 
            java.util.Locale.getDefault()).format(java.util.Date(timestamp))
        return date
    }
}

/**
 * Utilidades de validación
 */
object ValidationUtils {
    
    /**
     * Valida email
     */
    fun isValidEmail(email: String): Boolean {
        return android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()
    }
    
    /**
     * Valida texto para TTS
     */
    fun validateTtsText(text: String, maxLength: Int = 1000): ValidationResult {
        return when {
            text.isBlank() -> ValidationResult.Error("El texto no puede estar vacío")
            text.length > maxLength -> ValidationResult.Error("El texto no puede tener más de $maxLength caracteres")
            text.length < 3 -> ValidationResult.Error("El texto debe tener al menos 3 caracteres")
            else -> ValidationResult.Success
        }
    }
    
    /**
     * Resultado de validación
     */
    sealed class ValidationResult {
        object Success : ValidationResult()
        data class Error(val message: String) : ValidationResult()
    }
}

/**
 * Utilidades para manejo de errores
 */
object ErrorUtils {
    
    /**
     * Mapea excepciones HTTP a mensajes legibles
     */
    fun mapHttpError(code: Int, message: String): String {
        return when (code) {
            400 -> "Solicitud inválida. Verifica los datos enviados."
            401 -> "No autorizado. Inicia sesión nuevamente."
            403 -> "Acceso denegado. No tienes permisos para esta acción."
            404 -> "Recurso no encontrado."
            422 -> "Datos inválidos. Revisa la información enviada."
            429 -> "Demasiadas solicitudes. Espera un momento e intenta de nuevo."
            500 -> "Error del servidor. Intenta más tarde."
            502 -> "Servicio temporalmente no disponible."
            503 -> "Servicio en mantenimiento. Intenta más tarde."
            else -> "Error inesperado: $message"
        }
    }
    
    /**
     * Mapea excepciones de red a mensajes legibles
     */
    fun mapNetworkError(exception: Exception): String {
        return when (exception) {
            is java.net.UnknownHostException -> "Sin conexión a internet. Verifica tu conexión."
            is java.net.SocketTimeoutException -> "Tiempo de espera agotado. Intenta de nuevo."
            is java.io.IOException -> "Error de red. Verifica tu conexión a internet."
            else -> "Error de conexión: ${exception.message}"
        }
    }
}

/**
 * Utilidades para logging
 */
object LogUtils {
    
    private const val TAG = "ChalanVoice"
    
    fun logError(message: String, throwable: Throwable? = null) {
        if (BuildConfig.DEBUG) {
            if (throwable != null) {
                android.util.Log.e(TAG, message, throwable)
            } else {
                android.util.Log.e(TAG, message)
            }
        }
    }
    
    fun logInfo(message: String) {
        if (BuildConfig.DEBUG) {
            android.util.Log.i(TAG, message)
        }
    }
    
    fun logDebug(message: String) {
        if (BuildConfig.DEBUG) {
            android.util.Log.d(TAG, message)
        }
    }
}