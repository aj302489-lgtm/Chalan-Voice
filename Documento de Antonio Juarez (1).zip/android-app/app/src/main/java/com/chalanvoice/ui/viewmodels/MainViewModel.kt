package com.chalanvoice.ui.viewmodels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.chalanvoice.data.repositories.AuthRepository
import com.chalanvoice.data.repositories.RecordingRepository
import com.chalanvoice.data.repositories.TrainingRepository
import com.chalanvoice.data.repositories.TtsRepository
import com.chalanvoice.ui.models.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import timber.log.Timber
import javax.inject.Inject

/**
 * ViewModel principal que maneja el estado de toda la aplicación
 * Implementa MVVM con StateFlow y manejo de estados unidireccional
 */
@HiltViewModel
class MainViewModel @Inject constructor(
    private val recordingRepository: RecordingRepository,
    private val trainingRepository: TrainingRepository,
    private val ttsRepository: TtsRepository,
    private val authRepository: AuthRepository
) : ViewModel() {

    // Estado principal de la UI
    private val _uiState = MutableStateFlow(MainUiState())
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

    // Estado compartido para operaciones de audio
    private val _audioPermissions = MutableStateFlow(false)
    val audioPermissions: StateFlow<Boolean> = _audioPermissions.asStateFlow()

    // Estado de progreso para operaciones largas
    private val _progress = MutableStateFlow<ProgressData?>(null)
    val progress: StateFlow<ProgressData?> = _progress.asStateFlow()

    init {
        // Cargar estado inicial
        initializeApp()
        
        // Observar cambios en la base de datos local
        observeLocalData()
        
        // Verificar estado de autenticación
        checkAuthState()
    }

    /**
     * Inicializa la aplicación cargando configuraciones y preferencias
     */
    private fun initializeApp() {
        viewModelScope.launch {
            try {
                val hasAcceptedEthics = authRepository.hasAcceptedEthics()
                val isDarkTheme = authRepository.isDarkTheme()
                val lastRecording = recordingRepository.getLastRecording()
                val userInfo = authRepository.getUserInfo()
                
                _uiState.update { currentState ->
                    currentState.copy(
                        hasAcceptedEthics = hasAcceptedEthics,
                        isDarkTheme = isDarkTheme,
                        currentRecording = lastRecording,
                        userInfo = userInfo,
                        isLoggedIn = userInfo != null
                    )
                }
                
                Timber.d("App inicializada correctamente")
            } catch (e: Exception) {
                Timber.e(e, "Error al inicializar la aplicación")
                handleError("Error al inicializar: ${e.message}")
            }
        }
    }

    /**
     * Observa cambios en datos locales
     */
    private fun observeLocalData() {
        // Observar grabaciones locales
        recordingRepository.observeRecordings()
            .onEach { recordings ->
                _uiState.update { it.copy(currentRecording = recordings.firstOrNull()) }
            }
            .catch { e ->
                Timber.e(e, "Error observando grabaciones")
            }
            .launchIn(viewModelScope)
    }

    /**
     * Verifica el estado de autenticación
     */
    private fun checkAuthState() {
        viewModelScope.launch {
            try {
                val isAuthenticated = authRepository.isAuthenticated()
                val userInfo = if (isAuthenticated) authRepository.getUserInfo() else null
                
                _uiState.update { it.copy(
                    isLoggedIn = isAuthenticated,
                    userInfo = userInfo
                ) }
            } catch (e: Exception) {
                Timber.e(e, "Error verificando autenticación")
            }
        }
    }

    /**
     * Procesa acciones de la UI
     */
    fun onUiAction(action: MainUiAction) {
        viewModelScope.launch {
            when (action) {
                is MainUiAction.RequestAudioPermission -> {
                    _uiState.update { it.copy(hasPermission = action.granted) }
                    _audioPermissions.value = action.granted
                    
                    if (!action.granted) {
                        handleError("Permiso de micrófono denegado")
                    }
                }
                
                is MainUiAction.SetError -> {
                    _uiState.update { it.copy(currentError = action.error) }
                }
                
                is MainUiAction.SetLoading -> {
                    _uiState.update { it.copy(isLoading = action.loading) }
                }
                
                is MainUiAction.AcceptEthics -> {
                    _uiState.update { it.copy(hasAcceptedEthics = action.accepted) }
                    authRepository.setEthicsAccepted(action.accepted)
                }
                
                is MainUiAction.SetRecordingState -> {
                    _uiState.update { it.copy(recordingState = action.state) }
                }
                
                is MainUiAction.SetTrainingState -> {
                    _uiState.update { it.copy(trainingState = action.state) }
                }
                
                is MainUiAction.SetTtsState -> {
                    _uiState.update { it.copy(ttsState = action.state) }
                }
                
                is MainUiAction.SetCurrentRecording -> {
                    _uiState.update { it.copy(currentRecording = action.recording) }
                }
                
                is MainUiAction.SetGeneratedAudio -> {
                    _uiState.update { it.copy(generatedAudio = action.audioPath) }
                }
                
                is MainUiAction.SetPlaybackState -> {
                    _uiState.update { it.copy(playbackState = action.state) }
                }
                
                is MainUiAction.ToggleTheme -> {
                    _uiState.update { it.copy(isDarkTheme = action.isDark) }
                    authRepository.setDarkTheme(action.isDark)
                }
                
                is MainUiAction.SetUserInfo -> {
                    _uiState.update { it.copy(userInfo = action.userInfo) }
                }
                
                is MainUiAction.SetLoggedIn -> {
                    _uiState.update { it.copy(isLoggedIn = action.loggedIn) }
                }
                
                MainUiAction.ClearAllStates -> {
                    _uiState.update { 
                        it.copy(
                            recordingState = RecordingState.Idle,
                            trainingState = TrainingState.Idle,
                            ttsState = TtsState.Idle,
                            currentError = null,
                            isLoading = false
                        )
                    }
                }
            }
        }
    }

    /**
     * Manejo centralizado de errores
     */
    private suspend fun handleError(message: String) {
        _uiState.update { it.copy(currentError = message, isLoading = false) }
        
        // Log del error para debugging
        Timber.e("Error en aplicación: $message")
        
        // TODO: Enviar a servicio de crash reporting en producción
    }

    /**
     * Limpiar mensaje de error
     */
    fun clearError() {
        _uiState.update { it.copy(currentError = null) }
    }

    /**
     * Operaciones específicas de grabación
     */
    fun startRecording() {
        viewModelScope.launch {
            try {
                if (!_uiState.value.hasPermission) {
                    onUiAction(MainUiAction.RequestAudioPermission(false))
                    return@launch
                }

                onUiAction(MainUiAction.SetRecordingState(RecordingState.Recording))
                
                val recording = recordingRepository.startRecording()
                onUiAction(MainUiAction.SetCurrentRecording(recording))
                
                Timber.d("Grabación iniciada: ${recording.fileName}")
            } catch (e: Exception) {
                Timber.e(e, "Error iniciando grabación")
                onUiAction(MainUiAction.SetRecordingState(RecordingState.Error(e.message ?: "Error desconocido")))
            }
        }
    }

    fun stopRecording() {
        viewModelScope.launch {
            try {
                val recording = recordingRepository.stopRecording()
                onUiAction(MainUiAction.SetRecordingState(RecordingState.Completed))
                onUiAction(MainUiAction.SetCurrentRecording(recording))
                
                Timber.d("Grabación completada: ${recording.fileName}")
            } catch (e: Exception) {
                Timber.e(e, "Error deteniendo grabación")
                onUiAction(MainUiAction.SetRecordingState(RecordingState.Error(e.message ?: "Error desconocido")))
            }
        }
    }

    /**
     * Operaciones de entrenamiento
     */
    fun startTraining(recording: AudioRecording) {
        viewModelScope.launch {
            try {
                onUiAction(MainUiAction.SetTrainingState(TrainingState.Uploading))
                
                val trainingResponse = trainingRepository.startTraining(recording)
                
                // Simular progreso (en implementación real, esto vendría del servidor)
                simulateTrainingProgress()
                
                onUiAction(MainUiAction.SetTrainingState(TrainingState.Completed))
                Timber.d("Entrenamiento completado: ${trainingResponse.modelId}")
                
            } catch (e: Exception) {
                Timber.e(e, "Error en entrenamiento")
                onUiAction(MainUiAction.SetTrainingState(TrainingState.Error(e.message ?: "Error en entrenamiento")))
            }
        }
    }

    /**
     * Simula el progreso del entrenamiento (para demo)
     */
    private suspend fun simulateTrainingProgress() {
        for (i in 0..100 step 10) {
            _progress.value = ProgressData("Entrenando modelo...", i, 100, "Subiendo y procesando...")
            kotlinx.coroutines.delay(500)
        }
        _progress.value = null
    }

    /**
     * Operaciones de texto a voz
     */
    fun generateVoice(params: TtsParams) {
        viewModelScope.launch {
            try {
                onUiAction(MainUiAction.SetTtsState(TtsState.Generating(params)))
                
                val ttsResponse = ttsRepository.generateVoice(params)
                
                onUiAction(MainUiAction.SetTtsState(TtsState.Completed(ttsResponse.audioUrl)))
                onUiAction(MainUiAction.SetGeneratedAudio(ttsResponse.audioUrl))
                
                Timber.d("Voz generada: ${ttsResponse.audioUrl}")
            } catch (e: Exception) {
                Timber.e(e, "Error generando voz")
                onUiAction(MainUiAction.SetTtsState(TtsState.Error(e.message ?: "Error generando voz")))
            }
        }
    }

    /**
     * Operaciones de autenticación
     */
    fun login(email: String, password: String) {
        viewModelScope.launch {
            try {
                onUiAction(MainUiAction.SetLoading(true))
                
                val userInfo = authRepository.login(email, password)
                
                onUiAction(MainUiAction.SetUserInfo(userInfo))
                onUiAction(MainUiAction.SetLoggedIn(true))
                onUiAction(MainUiAction.SetLoading(false))
                
                Timber.d("Usuario logueado: ${userInfo.email}")
            } catch (e: Exception) {
                Timber.e(e, "Error en login")
                handleError("Error de autenticación: ${e.message}")
            }
        }
    }

    fun logout() {
        viewModelScope.launch {
            try {
                authRepository.logout()
                
                onUiAction(MainUiAction.SetUserInfo(null))
                onUiAction(MainUiAction.SetLoggedIn(false))
                onUiAction(MainUiAction.ClearAllStates)
                
                Timber.d("Usuario deslogueado")
            } catch (e: Exception) {
                Timber.e(e, "Error en logout")
                handleError("Error cerrando sesión: ${e.message}")
            }
        }
    }

    /**
     * Operaciones de configuración
     */
    fun deleteUserModel() {
        viewModelScope.launch {
            try {
                trainingRepository.deleteUserModel()
                
                val userInfo = _uiState.value.userInfo?.copy(
                    modelTrained = false,
                    modelId = null
                )
                
                onUiAction(MainUiAction.SetUserInfo(userInfo))
                
                Timber.d("Modelo de usuario eliminado")
            } catch (e: Exception) {
                Timber.e(e, "Error eliminando modelo")
                handleError("Error eliminando modelo: ${e.message}")
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        Timber.d("MainViewModel limpiado")
    }
}