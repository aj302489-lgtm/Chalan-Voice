#!/bin/bash

# Script de instalación y configuración para Chalan Voice Android App
# Ejecutar con: bash install.sh

set -e

echo "🚀 Chalan Voice Android App - Script de Instalación"
echo "===================================================="

# Colores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Funciones de utilidad
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[OK]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Verificar Java
check_java() {
    print_status "Verificando Java..."
    
    if command -v java &> /dev/null; then
        JAVA_VERSION=$(java -version 2>&1 | head -n 1 | cut -d'"' -f2 | cut -d'.' -f1)
        if [ "$JAVA_VERSION" -ge 11 ]; then
            print_success "Java $JAVA_VERSION encontrado (requerido: Java 11+)"
        else
            print_error "Java 11+ requerido. Encontrado: Java $JAVA_VERSION"
            exit 1
        fi
    else
        print_error "Java no encontrado. Instalar Java 11+ desde:"
        echo "  - Ubuntu/Debian: sudo apt install openjdk-11-jdk"
        echo "  - macOS: brew install openjdk@11"
        echo "  - Windows: Descargar desde https://adoptium.net/"
        exit 1
    fi
}

# Verificar Android SDK
check_android_sdk() {
    print_status "Verificando Android SDK..."
    
    if [ -z "$ANDROID_HOME" ]; then
        print_warning "ANDROID_HOME no configurado"
        echo "Configurar ANDROID_HOME apuntando al SDK de Android"
        echo "Ejemplo: export ANDROID_HOME=\$HOME/Android/Sdk"
        
        # Buscar SDK en ubicaciones comunes
        if [ -d "$HOME/Android/Sdk" ]; then
            export ANDROID_HOME="$HOME/Android/Sdk"
            print_success "Android SDK encontrado en $ANDROID_HOME"
        elif [ -d "$HOME/Library/Android/sdk" ]; then
            export ANDROID_HOME="$HOME/Library/Android/sdk"
            print_success "Android SDK encontrado en $ANDROID_HOME"
        else
            print_error "Android SDK no encontrado. Instalar Android Studio"
            echo "Descargar desde: https://developer.android.com/studio"
            return 1
        fi
    else
        print_success "ANDROID_HOME configurado: $ANDROID_HOME"
    fi
}

# Verificar Gradle
check_gradle() {
    print_status "Verificando Gradle..."
    
    if command -v gradle &> /dev/null; then
        GRADLE_VERSION=$(gradle -v | grep Gradle | cut -d' ' -f2)
        print_success "Gradle encontrado: $GRADLE_VERSION"
    else
        print_warning "Gradle no encontrado. Usando Gradle wrapper..."
    fi
}

# Verificar herramientas Android
check_android_tools() {
    print_status "Verificando herramientas Android..."
    
    if [ -n "$ANDROID_HOME" ]; then
        TOOLS_NEEDED=("adb" "sdkmanager" "avdmanager")
        
        for tool in "${TOOLS_NEEDED[@]}"; do
            if [ -f "$ANDROID_HOME/platform-tools/$tool" ] || command -v $tool &> /dev/null; then
                print_success "$tool disponible"
            else
                print_warning "$tool no encontrado"
            fi
        done
    fi
}

# Configurar dispositivo/emulador
setup_device() {
    print_status "Configuración de dispositivo/emulador..."
    
    # Verificar si hay dispositivo conectado
    if command -v adb &> /dev/null; then
        DEVICES=$(adb devices | grep -c "device$" || echo 0)
        if [ "$DEVICES" -gt 0 ]; then
            print_success "Dispositivo(s) Android conectado(s): $DEVICES"
        else
            print_warning "No hay dispositivos conectados"
            echo "Opciones:"
            echo "1. Conectar dispositivo Android por USB"
            echo "2. Crear emulador Android usando Android Studio"
            echo "3. Continuar sin dispositivo (solo para build)"
        fi
    else
        print_warning "adb no disponible"
    fi
}

# Construir proyecto
build_project() {
    print_status "Construyendo proyecto Android..."
    
    # Limpiar build anterior
    print_status "Limpiando build anterior..."
    if [ -f "./gradlew" ]; then
        ./gradlew clean
    else
        gradle clean
    fi
    
    # Compilar en modo debug
    print_status "Compilando en modo debug..."
    if [ -f "./gradlew" ]; then
        ./gradlew assembleDebug
    else
        gradle assembleDebug
    fi
    
    if [ $? -eq 0 ]; then
        print_success "Build debug completado"
        
        # Buscar APK generado
        APK_PATH=$(find app/build/outputs/apk/debug -name "*.apk" 2>/dev/null | head -n 1)
        if [ -n "$APK_PATH" ]; then
            print_success "APK generado: $APK_PATH"
        fi
    else
        print_error "Error en el build"
        return 1
    fi
}

# Ejecutar tests
run_tests() {
    read -p "¿Ejecutar tests unitarios? (y/N): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        print_status "Ejecutando tests..."
        if [ -f "./gradlew" ]; then
            ./gradlew test
        else
            gradle test
        fi
        
        if [ $? -eq 0 ]; then
            print_success "Tests completados exitosamente"
        else
            print_warning "Algunos tests fallaron"
        fi
    fi
}

# Instalar en dispositivo
install_app() {
    read -p "¿Instalar app en dispositivo/emulador? (y/N): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        if command -v adb &> /dev/null; then
            APK_PATH=$(find app/build/outputs/apk/debug -name "*.apk" 2>/dev/null | head -n 1)
            if [ -n "$APK_PATH" ]; then
                print_status "Instalando APK..."
                adb install -r "$APK_PATH"
                
                if [ $? -eq 0 ]; then
                    print_success "App instalada exitosamente"
                    print_status "Iniciando app..."
                    adb shell am start -n com.chalanvoice/.MainActivity
                else
                    print_error "Error instalando la app"
                fi
            else
                print_error "APK no encontrado. Ejecutar build primero."
            fi
        else
            print_error "adb no disponible"
        fi
    fi
}

# Generar APK de release (opcional)
build_release() {
    read -p "¿Generar APK de release? (y/N): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        print_warning "Para release es necesario configurar signing en app/build.gradle"
        print_status "Compilando release..."
        
        if [ -f "./gradlew" ]; then
            ./gradlew assembleRelease
        else
            gradle assembleRelease
        fi
        
        if [ $? -eq 0 ]; then
            print_success "APK de release generado"
            APK_PATH=$(find app/build/outputs/apk/release -name "*.apk" 2>/dev/null | head -n 1)
            if [ -n "$APK_PATH" ]; then
                print_success "APK release: $APK_PATH"
            fi
        else
            print_error "Error generando APK de release"
        fi
    fi
}

# Configurar variables de entorno
setup_environment() {
    print_status "Configurando variables de entorno..."
    
    echo ""
    print_warning "Configuraciones importantes:"
    echo "1. Backend URL: Configurar en app/src/main/java/com/chalanvoice/data/Constants.kt"
    echo "2. API Keys: Si se usan servicios externos, configurar en .env del backend"
    echo "3. Permisos: Verificar permisos en AndroidManifest.xml"
    
    # Crear archivo local de configuración si no existe
    if [ ! -f "local.properties" ]; then
        cat > local.properties << EOF
# Configuración local - NO COMMIT
# Backend API URL
API_BASE_URL=http://localhost:8000

# Debug settings
DEBUG=true

# Logging
LOG_LEVEL=DEBUG
EOF
        print_success "Archivo local.properties creado"
    fi
}

# Función principal
main() {
    echo
    print_status "Iniciando instalación de Chalan Voice Android App..."
    echo
    
    # Verificaciones del sistema
    check_java
    check_android_sdk
    check_gradle
    check_android_tools
    
    # Configuración
    setup_environment
    
    # Construir proyecto
    build_project
    
    # Opcionales
    setup_device
    run_tests
    install_app
    build_release
    
    echo
    print_success "¡Instalación completada!"
    echo
    print_status "Pasos siguientes:"
    echo "  1. Configurar backend URL en Constants.kt"
    echo "  2. Probar conexión con backend"
    echo "  3. Configurar device/emulator para testing"
    echo "  4. Configurar signing para release"
    echo
    print_warning "Comandos útiles:"
    echo "  • Gradle wrapper: ./gradlew"
    echo "  • Install debug: adb install app/build/outputs/apk/debug/app-debug.apk"
    echo "  • Logcat: adb logcat | grep ChalanVoice"
    echo "  • Tests: ./gradlew test"
    echo
}

# Ejecutar función principal
main "$@"