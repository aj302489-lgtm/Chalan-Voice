package com.chalanvoice.app

import android.app.Application
import dagger.hilt.android.HiltAndroidApp
import timber.log.Timber

/**
 * Clase principal de la aplicación que inicializa componentes globales
 * como Timber para logging y Hilt para inyección de dependencias.
 */
@HiltAndroidApp
class ChalanVoiceApplication : Application() {

    companion object {
        private const val TAG = "ChalanVoiceApp"
    }

    override fun onCreate() {
        super.onCreate()
        
        // Inicializar Timber para logging estructurado
        if (BuildConfig.DEBUG) {
            Timber.plant(Timber.DebugTree())
        }
        
        // Inicializar componentes adicionales si es necesario
        initializeComponents()
        
        Timber.d(TAG, "ChalanVoice Application initialized")
    }

    /**
     * Inicializa componentes globales de la aplicación
     */
    private fun initializeComponents() {
        // Aquí se pueden inicializar otros componentes globales
        // como crashlytics, analytics, etc.
    }
}