package com.chalanvoice.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.chalanvoice.app.ui.navigation.ChalanVoiceNavigation
import com.chalanvoice.app.ui.theme.ChalanVoiceTheme
import dagger.hilt.android.AndroidEntryPoint

/**
 * Actividad principal de la aplicación Chalan Voice.
 * Configura el tema Material 3 y la navegación Compose.
 */
@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        val splashScreen = installSplashScreen()
        
        super.onCreate(savedInstanceState)
        
        // Habilitar Edge-to-Edge para una experiencia más inmersiva
        enableEdgeToEdge()
        
        setContent {
            // Aplicar tema Material 3 personalizado
            ChalanVoiceTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    // Configurar navegación principal de la aplicación
                    ChalanVoiceNavigation()
                }
            }
        }
        
        splashScreen.setKeepOnScreenCondition { 
            // Mantener splash screen hasta que la app esté lista
            false 
        }
    }
}