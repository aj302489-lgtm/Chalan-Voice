package com.chalanvoice.app.data.repository

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.chalanvoice.app.domain.repository.UserPreferencesRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Implementación del repositorio de preferencias del usuario usando EncryptedSharedPreferences
 */
@Singleton
class UserPreferencesRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context
) : UserPreferencesRepository {

    companion object {
        private const val PREFERENCES_NAME = "chalan_voice_preferences"
        private const val KEY_CONSENT_ACCEPTED = "consent_accepted"
        private const val KEY_CONSENT_TIMESTAMP = "consent_timestamp"
        private const val KEY_AUTH_TOKEN = "auth_token"
        private const val KEY_AUTO_SAVE_RECORDINGS = "auto_save_recordings"
    }

    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val sharedPreferences = EncryptedSharedPreferences.create(
        context,
        PREFERENCES_NAME,
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    override fun hasUserAcceptedConsent(): Flow<Boolean> = flow {
        val accepted = sharedPreferences.getBoolean(KEY_CONSENT_ACCEPTED, false)
        emit(accepted)
    }

    override suspend fun saveConsentAccepted(accepted: Boolean) {
        sharedPreferences.edit()
            .putBoolean(KEY_CONSENT_ACCEPTED, accepted)
            .apply()
    }

    override fun getConsentTimestamp(): Flow<Long> = flow {
        val timestamp = sharedPreferences.getLong(KEY_CONSENT_TIMESTAMP, 0L)
        emit(timestamp)
    }

    override suspend fun saveConsentTimestamp(timestamp: Long) {
        sharedPreferences.edit()
            .putLong(KEY_CONSENT_TIMESTAMP, timestamp)
            .apply()
    }

    override fun getAuthToken(): Flow<String?> = flow {
        val token = sharedPreferences.getString(KEY_AUTH_TOKEN, null)
        emit(token)
    }

    override suspend fun saveAuthToken(token: String) {
        sharedPreferences.edit()
            .putString(KEY_AUTH_TOKEN, token)
            .apply()
    }

    override suspend fun clearAuthToken() {
        sharedPreferences.edit()
            .remove(KEY_AUTH_TOKEN)
            .apply()
    }

    override fun isAuthenticated(): Flow<Boolean> = flow {
        val token = sharedPreferences.getString(KEY_AUTH_TOKEN, null)
        emit(!token.isNullOrBlank())
    }

    override suspend fun saveAutoSaveRecordings(enabled: Boolean) {
        sharedPreferences.edit()
            .putBoolean(KEY_AUTO_SAVE_RECORDINGS, enabled)
            .apply()
    }

    override fun getAutoSaveRecordings(): Flow<Boolean> = flow {
        val enabled = sharedPreferences.getBoolean(KEY_AUTO_SAVE_RECORDINGS, true)
        emit(enabled)
    }
}