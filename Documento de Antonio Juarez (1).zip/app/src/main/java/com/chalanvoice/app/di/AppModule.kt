package com.chalanvoice.app.di

import android.content.Context
import com.chalanvoice.app.data.repository.UserPreferencesRepositoryImpl
import com.chalanvoice.app.domain.repository.UserPreferencesRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * Módulo Dagger para proporcionar dependencias singleton
 */
@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    /**
     * Proporciona el repositorio de preferencias del usuario
     */
    @Provides
    @Singleton
    fun provideUserPreferencesRepository(
        @ApplicationContext context: Context
    ): UserPreferencesRepository {
        return UserPreferencesRepositoryImpl(context)
    }
}