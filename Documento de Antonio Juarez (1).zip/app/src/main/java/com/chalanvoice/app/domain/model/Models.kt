package com.chalanvoice.app.domain.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * Modelo de datos para el consentimiento del usuario
 */
@Parcelize
data class UserConsent(
    val hasAcceptedTerms: Boolean,
    val hasAcceptedPrivacy: Boolean,
    val consentTimestamp: Long,
    val consentVersion: String = "1.0.0"
) : Parcelable

/**
 * Modelo para representar emociones disponibles para TTS
 */
enum class TtsEmotion(val displayName: String, val value: String) {
    NEUTRAL("Neutro", "neutral"),
    HAPPY("Feliz", "happy"),
    SAD("Triste", "sad"),
    ANGRY("Enojado", "angry"),
    EXCITED("Emocionado", "excited"),
    CALM("Calmado", "calm"),
    SURPRISED("Sorprendido", "surprised")
}

/**
 * Modelo para representar estados de carga
 */
sealed class LoadingState {
    object Idle : LoadingState()
    object Loading : LoadingState()
    data class Success(val data: Any? = null) : LoadingState()
    data class Error(val message: String, val exception: Throwable? = null) : LoadingState()
}

/**
 * Modelo para respuestas de API
 */
data class ApiResponse<T>(
    val success: Boolean,
    val data: T? = null,
    val message: String? = null,
    val error: String? = null
)

/**
 * Modelo para archivos de audio
 */
data class AudioFile(
    val name: String,
    val path: String,
    val duration: Long,
    val size: Long,
    val mimeType: String = "audio/wav"
)

/**
 * Modelo para configuración de usuario
 */
data class UserSettings(
    val autoSaveRecordings: Boolean = true,
    val preferredEmotion: TtsEmotion = TtsEmotion.NEUTRAL,
    val notificationEnabled: Boolean = true,
    val darkModeEnabled: Boolean = true
)