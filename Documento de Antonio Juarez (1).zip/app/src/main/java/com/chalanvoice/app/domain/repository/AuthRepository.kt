package com.chalanvoice.app.domain.repository

import com.chalanvoice.app.domain.model.ApiResponse
import kotlinx.coroutines.flow.Flow

/**
 * Interfaz para el repositorio de autenticación
 */
interface AuthRepository {
    
    /**
     * Obtener el token de autenticación actual
     */
    fun getCurrentAuthToken(): String?
    
    /**
     * Flujo del token de autenticación
     */
    fun getAuthTokenFlow(): Flow<String?>
    
    /**
     * Iniciar sesión con email y contraseña
     */
    suspend fun login(
        email: String,
        password: String
    ): ApiResponse<AuthResult>
    
    /**
     * Registrarse como nuevo usuario
     */
    suspend fun register(
        email: String,
        password: String,
        name: String
    ): ApiResponse<AuthResult>
    
    /**
     * Cerrar sesión
     */
    suspend fun logout()
    
    /**
     * Verificar si el usuario está autenticado
     */
    fun isAuthenticated(): Boolean
    
    /**
     * Refrescar token de autenticación
     */
    suspend fun refreshToken(): ApiResponse<AuthResult>
}

/**
 * Resultado de autenticación
 */
data class AuthResult(
    val token: String,
    val refreshToken: String,
    val userId: String,
    val userEmail: String,
    val expiresAt: Long
)