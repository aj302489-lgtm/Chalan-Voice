package com.chalanvoice.app.domain.repository

import kotlinx.coroutines.flow.Flow

/**
 * Interfaz para el repositorio de preferencias del usuario
 */
interface UserPreferencesRepository {
    
    /**
     * Verificar si el usuario ha aceptado el consentimiento
     */
    fun hasUserAcceptedConsent(): Flow<Boolean>
    
    /**
     * Guardar el estado de aceptación del consentimiento
     */
    suspend fun saveConsentAccepted(accepted: Boolean)
    
    /**
     * Obtener el timestamp del consentimiento
     */
    fun getConsentTimestamp(): Flow<Long>
    
    /**
     * Guardar el timestamp del consentimiento
     */
    suspend fun saveConsentTimestamp(timestamp: Long)
    
    /**
     * Obtener el token de autenticación JWT
     */
    fun getAuthToken(): Flow<String?>
    
    /**
     * Guardar el token de autenticación JWT
     */
    suspend fun saveAuthToken(token: String)
    
    /**
     * Eliminar el token de autenticación
     */
    suspend fun clearAuthToken()
    
    /**
     * Verificar si el usuario está autenticado
     */
    fun isAuthenticated(): Flow<Boolean>
    
    /**
     * Guardar configuración de auto-guardado de grabaciones
     */
    suspend fun saveAutoSaveRecordings(enabled: Boolean)
    
    /**
     * Obtener configuración de auto-guardado de grabaciones
     */
    fun getAutoSaveRecordings(): Flow<Boolean>
}