package com.chalanvoice.app.domain.repository

import com.chalanvoice.app.domain.model.ApiResponse
import java.io.File

/**
 * Interfaz para el repositorio de modelos de voz
 */
interface VoiceModelRepository {
    
    /**
     * Subir muestra de voz al servidor
     */
    suspend fun uploadVoiceSample(
        audioFile: File,
        authToken: String,
        onProgress: (Float) -> Unit = {}
    ): ApiResponse<String>
    
    /**
     * Iniciar entrenamiento del modelo
     */
    suspend fun startModelTraining(
        authToken: String
    ): ApiResponse<String>
    
    /**
     * Obtener el estado del modelo
     */
    suspend fun getModelStatus(
        authToken: String
    ): ApiResponse<ModelStatus>
    
    /**
     * Generar audio TTS usando el modelo entrenado
     */
    suspend fun generateTts(
        text: String,
        emotion: String,
        authToken: String
    ): ApiResponse<String>
}

/**
 * Estado del modelo de voz
 */
data class ModelStatus(
    val isTrained: Boolean,
    val trainingProgress: Float,
    val lastUpdate: Long,
    val modelId: String,
    val message: String? = null
)