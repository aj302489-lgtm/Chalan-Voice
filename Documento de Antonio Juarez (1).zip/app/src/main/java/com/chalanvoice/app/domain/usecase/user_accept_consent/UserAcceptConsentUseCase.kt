package com.chalanvoice.app.domain.usecase.user_accept_consent

import com.chalanvoice.app.domain.repository.UserPreferencesRepository
import javax.inject.Inject

/**
 * Caso de uso para manejar la aceptación de consentimiento del usuario
 */
class UserAcceptConsentUseCase @Inject constructor(
    private val userPreferencesRepository: UserPreferencesRepository
) {
    suspend fun execute() {
        userPreferencesRepository.saveConsentAccepted(true)
        userPreferencesRepository.saveConsentTimestamp(System.currentTimeMillis())
    }
}