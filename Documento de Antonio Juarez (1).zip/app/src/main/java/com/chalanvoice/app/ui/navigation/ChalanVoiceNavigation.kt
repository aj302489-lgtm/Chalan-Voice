package com.chalanvoice.app.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.chalanvoice.app.ui.screens.consent.ConsentScreen
import com.chalanvoice.app.ui.screens.recording.RecordingScreen
import com.chalanvoice.app.ui.screens.training.TrainingScreen
import com.chalanvoice.app.ui.screens.tts.TtsGeneratorScreen
import com.chalanvoice.app.ui.screens.player.PlayerScreen
import com.chalanvoice.app.ui.screens.settings.SettingsScreen
import com.chalanvoice.app.ui.screens.home.HomeScreen

/**
 * Composable principal que configura la navegación de la aplicación.
 * Define todas las rutas y transiciones entre pantallas.
 */
@Composable
fun ChalanVoiceNavigation(
    navController: NavHostController = rememberNavController(),
    modifier: Modifier = Modifier
) {
    NavHost(
        navController = navController,
        startDestination = ChalanVoiceScreens.Consent.route,
        modifier = modifier
    ) {
        // Pantalla de consentimiento y términos de uso
        composable(
            route = ChalanVoiceScreens.Consent.route
        ) {
            ConsentScreen(
                onConsentAccepted = {
                    navController.navigate(ChalanVoiceScreens.Home.route) {
                        popUpTo(ChalanVoiceScreens.Consent.route) {
                            inclusive = true
                        }
                    }
                }
            )
        }

        // Pantalla de inicio/bienvenida
        composable(
            route = ChalanVoiceScreens.Home.route
        ) {
            HomeScreen(
                onRecordingClick = { 
                    navController.navigate(ChalanVoiceScreens.Recording.route) 
                },
                onTrainingClick = { 
                    navController.navigate(ChalanVoiceScreens.Training.route) 
                },
                onTtsClick = { 
                    navController.navigate(ChalanVoiceScreens.TtsGenerator.route) 
                },
                onSettingsClick = { 
                    navController.navigate(ChalanVoiceScreens.Settings.route) 
                }
            )
        }

        // Pantalla de grabación de voz
        composable(
            route = ChalanVoiceScreens.Recording.route
        ) {
            RecordingScreen(
                onRecordingComplete = { audioFile ->
                    navController.navigate(
                        "${ChalanVoiceScreens.Training.route}?audioFile=${audioFile.absolutePath}"
                    )
                },
                onNavigateBack = {
                    navController.popBackStack()
                }
            )
        }

        // Pantalla de entrenamiento
        composable(
            route = "${ChalanVoiceScreens.Training.route}?audioFile={audioFile}"
        ) { backStackEntry ->
            val audioFile = backStackEntry.arguments?.getString("audioFile")
            TrainingScreen(
                audioFilePath = audioFile,
                onTrainingComplete = {
                    navController.navigate(ChalanVoiceScreens.TtsGenerator.route) {
                        // Limpiar el stack de entrenamiento
                        popUpTo(ChalanVoiceScreens.Training.route) {
                            inclusive = true
                        }
                    }
                },
                onNavigateBack = {
                    navController.popBackStack()
                }
            )
        }

        // Pantalla de generación TTS
        composable(
            route = ChalanVoiceScreens.TtsGenerator.route
        ) {
            TtsGeneratorScreen(
                onAudioGenerated = { audioUrl ->
                    navController.navigate(
                        "${ChalanVoiceScreens.Player.route}?audioUrl=$audioUrl"
                    )
                },
                onNavigateBack = {
                    navController.popBackStack()
                }
            )
        }

        // Pantalla de reproducción
        composable(
            route = "${ChalanVoiceScreens.Player.route}?audioUrl={audioUrl}"
        ) { backStackEntry ->
            val audioUrl = backStackEntry.arguments?.getString("audioUrl")
            PlayerScreen(
                audioUrl = audioUrl,
                onNavigateBack = {
                    navController.popBackStack()
                }
            )
        }

        // Pantalla de configuración
        composable(
            route = ChalanVoiceScreens.Settings.route
        ) {
            SettingsScreen(
                onNavigateBack = {
                    navController.popBackStack()
                },
                onLogout = {
                    navController.navigate(ChalanVoiceScreens.Consent.route) {
                        popUpTo(0) {
                            inclusive = true
                        }
                    }
                }
            )
        }
    }
}

/**
 * Definición de todas las rutas de navegación de la aplicación
 */
sealed class ChalanVoiceScreens(val route: String) {
    object Consent : ChalanVoiceScreens("consent")
    object Home : ChalanVoiceScreens("home")
    object Recording : ChalanVoiceScreens("recording")
    object Training : ChalanVoiceScreens("training")
    object TtsGenerator : ChalanVoiceScreens("tts_generator")
    object Player : ChalanVoiceScreens("player")
    object Settings : ChalanVoiceScreens("settings")
}