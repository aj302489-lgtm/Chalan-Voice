package com.chalanvoice.app.ui.screens.consent

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.chalanvoice.app.R
import com.chalanvoice.app.ui.components.LoadingButton

/**
 * Pantalla de consentimiento y términos de uso.
 * Permite al usuario revisar y aceptar los términos antes de usar la aplicación.
 */
@Composable
fun ConsentScreen(
    onConsentAccepted: () -> Unit,
    viewModel: ConsentViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    // Manejar navegación cuando el consentimiento es aceptado
    LaunchedEffect(uiState.isLoading) {
        if (!uiState.isLoading && uiState.canProceed) {
            // Solo navegar si acabamos de completar la carga
            // y el usuario puede proceder
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        if (uiState.isLoading) {
            // Pantalla de carga
            CircularProgressIndicator(
                modifier = Modifier.align(Alignment.Center)
            )
        } else {
            // Contenido principal
            ConsentContent(
                uiState = uiState,
                onEvent = { event ->
                    viewModel.onEvent(event)
                    // Si es el evento de aceptar, navegar después de un breve delay
                    if (event is ConsentUiEvent.AcceptConsent) {
                        kotlinx.coroutines.delay(500)
                        onConsentAccepted()
                    }
                }
            )
        }

        // Mostrar error si existe
        if (uiState.showError && uiState.errorMessage != null) {
            AlertDialog(
                onDismissRequest = { viewModel.onEvent(ConsentUiEvent.DismissError) },
                title = { Text("Error") },
                text = { Text(uiState.errorMessage) },
                confirmButton = {
                    TextButton(
                        onClick = { viewModel.onEvent(ConsentUiEvent.DismissError) }
                    ) {
                        Text("Entendido")
                    }
                }
            )
        }
    }
}

/**
 * Contenido principal de la pantalla de consentimiento
 */
@Composable
private fun ConsentContent(
    uiState: ConsentUiState,
    onEvent: (ConsentUiEvent) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(32.dp))
        
        // Logo y título
        Text(
            text = "Chalan Voice",
            style = MaterialTheme.typography.headlineLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )
        
        Spacer(modifier = Modifier.height(8.dp))
        
        Text(
            text = "Términos de Uso y Privacidad",
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onBackground,
            textAlign = TextAlign.Center
        )
        
        Spacer(modifier = Modifier.height(24.dp))

        // Contenedor de términos con scroll
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                Text(
                    text = "Términos de Uso",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                
                val termsText = """
                    Al usar Chalan Voice, aceptas nuestros términos de servicio.
                    
                    1. Uso del Servicio: La aplicación permite grabar tu voz para generar modelos TTS personalizados.
                    
                    2. Datos de Voz: Tus grabaciones de voz se procesan para crear un modelo único de tu voz.
                    
                    3. Privacidad: Tus datos de voz se almacenan de forma segura y no se comparten con terceros sin tu consentimiento.
                    
                    4. Limitaciones: El servicio puede tener limitaciones técnicas que pueden afectar la calidad del audio generado.
                    
                    5. Terminación: Puedes eliminar tus datos en cualquier momento desde la configuración.
                    
                    6. Responsabilidad: El uso del servicio es bajo tu propia responsabilidad.
                """.trimIndent()
                
                Text(
                    text = termsText,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp)
                )
                
                Divider(color = MaterialTheme.colorScheme.outlineVariant)
                
                Text(
                    text = "Política de Privacidad",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(vertical = 8.dp)
                )
                
                val privacyText = """
                    En Chalan Voice, respetamos tu privacidad:
                    
                    • Datos Recopilados: Solo recolectamos las grabaciones de voz necesarias para el servicio TTS.
                    
                    • Uso de Datos: Tus datos de voz se usan exclusivamente para generar tu modelo personalizado.
                    
                    • Almacenamiento: Los datos se almacenan de forma cifrada en servidores seguros.
                    
                    • Eliminación: Puedes eliminar todos tus datos desde la configuración de la aplicación.
                    
                    • No Compartición: No compartimos tus datos de voz con terceros.
                    
                    • Control: Tienes control total sobre tus datos y puedes revocarlos en cualquier momento.
                """.trimIndent()
                
                Text(
                    text = privacyText,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        
        Spacer(modifier = Modifier.height(24.dp))
        
        // Checkboxes de aceptación
        ConsentCheckboxes(
            hasAcceptedTerms = uiState.hasAcceptedTerms,
            hasAcceptedPrivacy = uiState.hasAcceptedPrivacy,
            onToggleTerms = { onEvent(ConsentUiEvent.ToggleTermsAcceptance(it)) },
            onTogglePrivacy = { onEvent(ConsentUiEvent.TogglePrivacyAcceptance(it)) }
        )
        
        Spacer(modifier = Modifier.height(16.dp))
        
        // Botón de aceptar
        LoadingButton(
            text = "Aceptar y Continuar",
            isLoading = uiState.isLoading,
            enabled = uiState.canProceed && !uiState.isLoading,
            onClick = { onEvent(ConsentUiEvent.AcceptConsent) },
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
        )
        
        Spacer(modifier = Modifier.height(16.dp))
        
        Text(
            text = "Al continuar, aceptas nuestros términos y política de privacidad",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
    }
}

/**
 * Componente para las checkboxes de aceptación
 */
@Composable
private fun ConsentCheckboxes(
    hasAcceptedTerms: Boolean,
    hasAcceptedPrivacy: Boolean,
    onToggleTerms: (Boolean) -> Unit,
    onTogglePrivacy: (Boolean) -> Unit
) {
    Column(
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(
                checked = hasAcceptedTerms,
                onCheckedChange = onToggleTerms,
                colors = CheckboxDefaults.colors(
                    checkedColor = MaterialTheme.colorScheme.primary,
                    uncheckedColor = MaterialTheme.colorScheme.onSurfaceVariant
                )
            )
            Text(
                text = "Acepto los términos de uso",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onBackground
            )
        }
        
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(
                checked = hasAcceptedPrivacy,
                onCheckedChange = onTogglePrivacy,
                colors = CheckboxDefaults.colors(
                    checkedColor = MaterialTheme.colorScheme.primary,
                    uncheckedColor = MaterialTheme.colorScheme.onSurfaceVariant
                )
            )
            Text(
                text = "Acepto la política de privacidad",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onBackground
            )
        }
    }
}