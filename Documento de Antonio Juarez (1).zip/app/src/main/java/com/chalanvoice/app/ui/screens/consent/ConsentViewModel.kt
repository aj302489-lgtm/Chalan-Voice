package com.chalanvoice.app.ui.screens.consent

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.chalanvoice.app.domain.usecase.user_accept_consent.UserAcceptConsentUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import timber.log.Timber
import javax.inject.Inject

/**
 * Estado de la UI para la pantalla de consentimiento
 */
data class ConsentUiState(
    val isLoading: Boolean = false,
    val hasAcceptedTerms: Boolean = false,
    val hasAcceptedPrivacy: Boolean = false,
    val showError: Boolean = false,
    val errorMessage: String? = null,
    val canProceed: Boolean = false
)

/**
 * Eventos de la UI para la pantalla de consentimiento
 */
sealed class ConsentUiEvent {
    data class ToggleTermsAcceptance(val accepted: Boolean) : ConsentUiEvent()
    data class TogglePrivacyAcceptance(val accepted: Boolean) : ConsentUiEvent()
    data object AcceptConsent : ConsentUiEvent()
    data object DismissError : ConsentUiEvent()
}

/**
 * ViewModel para manejar la lógica de la pantalla de consentimiento
 * y términos de uso.
 */
@HiltViewModel
class ConsentViewModel @Inject constructor(
    private val userAcceptConsentUseCase: UserAcceptConsentUseCase
) : ViewModel() {

    private val _uiState = MutableStateFlow(ConsentUiState())
    val uiState: StateFlow<ConsentUiState> = _uiState.asStateFlow()

    fun onEvent(event: ConsentUiEvent) {
        when (event) {
            is ConsentUiEvent.ToggleTermsAcceptance -> {
                updateState(_uiState.value.copy(
                    hasAcceptedTerms = event.accepted,
                    showError = false,
                    errorMessage = null
                ))
                updateCanProceed()
            }
            is ConsentUiEvent.TogglePrivacyAcceptance -> {
                updateState(_uiState.value.copy(
                    hasAcceptedPrivacy = event.accepted,
                    showError = false,
                    errorMessage = null
                ))
                updateCanProceed()
            }
            is ConsentUiEvent.AcceptConsent -> {
                acceptConsent()
            }
            is ConsentUiEvent.DismissError -> {
                updateState(_uiState.value.copy(
                    showError = false,
                    errorMessage = null
                ))
            }
        }
    }

    /**
     * Actualiza el estado de la UI
     */
    private fun updateState(newState: ConsentUiState) {
        _uiState.value = newState
    }

    /**
     * Verifica si el usuario puede proceder con el consentimiento
     */
    private fun updateCanProceed() {
        val currentState = _uiState.value
        updateState(currentState.copy(
            canProceed = currentState.hasAcceptedTerms && currentState.hasAcceptedPrivacy
        ))
    }

    /**
     * Procesa la aceptación de los términos y políticas
     */
    private fun acceptConsent() {
        val currentState = _uiState.value
        
        if (!currentState.canProceed) {
            updateState(currentState.copy(
                showError = true,
                errorMessage = "Debes aceptar tanto los términos de uso como la política de privacidad para continuar."
            ))
            return
        }

        viewModelScope.launch {
            updateState(currentState.copy(isLoading = true))
            
            try {
                // Guardar la aceptación en el almacenamiento local
                userAcceptConsentUseCase.execute()
                
                Timber.d("Consent accepted successfully")
                updateState(currentState.copy(isLoading = false))
                
            } catch (e: Exception) {
                Timber.e(e, "Error accepting consent")
                updateState(currentState.copy(
                    isLoading = false,
                    showError = true,
                    errorMessage = "Error al guardar el consentimiento. Inténtalo de nuevo."
                ))
            }
        }
    }
}