package com.chalanvoice.app.ui.screens.home

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.chalanvoice.app.R

/**
 * Pantalla de inicio/bienvenida principal de la aplicación.
 * Muestra las opciones principales y el estado del modelo de voz.
 */
@Composable
fun HomeScreen(
    onRecordingClick: () -> Unit,
    onTrainingClick: () -> Unit,
    onTtsClick: () -> Void,
    onSettingsClick: () -> Unit,
    viewModel: HomeViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        HomeContent(
            uiState = uiState,
            onRecordingClick = { onRecordingClick() },
            onTrainingClick = { onTrainingClick() },
            onTtsClick = { onTtsClick() },
            onSettingsClick = { onSettingsClick() }
        )
    }
}

/**
 * Contenido principal de la pantalla de inicio
 */
@Composable
private fun HomeContent(
    uiState: HomeUiState,
    onRecordingClick: () -> Unit,
    onTrainingClick: () -> Unit,
    onTtsClick: () -> Unit,
    onSettingsClick: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize()
    ) {
        // Header con logo y saludo
        HomeHeader(
            userName = uiState.userName,
            isModelTrained = uiState.isModelTrained
        )
        
        Spacer(modifier = Modifier.height(24.dp))
        
        // Estado del modelo de voz
        ModelStatusCard(
            isModelTrained = uiState.isModelTrained,
            lastTrainingTime = uiState.lastTrainingTime
        )
        
        Spacer(modifier = Modifier.height(24.dp))
        
        // Opciones principales
        Text(
            text = "¿Qué deseas hacer?",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onBackground
        )
        
        Spacer(modifier = Modifier.height(16.dp))
        
        // Grid de opciones principales
        MainOptionsGrid(
            isModelTrained = uiState.isModelTrained,
            onRecordingClick = onRecordingClick,
            onTrainingClick = onTrainingClick,
            onTtsClick = onTtsClick
        )
        
        Spacer(modifier = Modifier.height(24.dp))
        
        // Opciones secundarias
        SecondaryOptions(
            onSettingsClick = onSettingsClick
        )
    }
}

/**
 * Header con logo y saludo personalizado
 */
@Composable
private fun HomeHeader(
    userName: String?,
    isModelTrained: Boolean
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(
                text = "Chalan Voice",
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = if (userName != null) {
                    "Hola, $userName"
                } else {
                    "Tu asistente de voz personal"
                },
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        
        // Indicador del estado del modelo
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = if (isModelTrained) {
                MaterialTheme.colorScheme.primary
            } else {
                MaterialTheme.colorScheme.surfaceVariant
            },
            modifier = Modifier.padding(8.dp)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = if (isModelTrained) Icons.Default.CheckCircle else Icons.Default.Pending,
                    contentDescription = null,
                    tint = if (isModelTrained) {
                        MaterialTheme.colorScheme.onPrimary
                    } else {
                        MaterialTheme.colorScheme.onSurfaceVariant
                    },
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = if (isModelTrained) "Listo" : "No entrenado",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (isModelTrained) {
                        MaterialTheme.colorScheme.onPrimary
                    } else {
                        MaterialTheme.colorScheme.onSurfaceVariant
                    }
                )
            }
        }
    }
}

/**
 * Tarjeta del estado del modelo de voz
 */
@Composable
private fun ModelStatusCard(
    isModelTrained: Boolean,
    lastTrainingTime: Long?
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (isModelTrained) {
                MaterialTheme.colorScheme.tertiaryContainer
            } else {
                MaterialTheme.colorScheme.secondaryContainer
            }
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = if (isModelTrained) Icons.Default.ModelTraining else Icons.Default.Mic,
                    contentDescription = null,
                    tint = if (isModelTrained) {
                        MaterialTheme.colorScheme.onTertiaryContainer
                    } else {
                        MaterialTheme.colorScheme.onSecondaryContainer
                    },
                    modifier = Modifier.padding(end = 12.dp)
                )
                
                Column {
                    Text(
                        text = if (isModelTrained) {
                            "Modelo de Voz Entrenado"
                        } else {
                            "Modelo de Voz No Entrenado"
                        },
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = if (isModelTrained) {
                            MaterialTheme.colorScheme.onTertiaryContainer
                        } else {
                            MaterialTheme.colorScheme.onSecondaryContainer
                        }
                    )
                    
                    if (isModelTrained && lastTrainingTime != null) {
                        val formattedDate = formatDate(lastTrainingTime)
                        Text(
                            text = "Última actualización: $formattedDate",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (isModelTrained) {
                                MaterialTheme.colorScheme.onTertiaryContainer
                            } else {
                                MaterialTheme.colorScheme.onSecondaryContainer
                            }
                        )
                    } else {
                        Text(
                            text = if (isModelTrained) {
                                "Puedes generar audio con tu voz"
                            } else {
                                "Graba tu voz para entrenar tu modelo personalizado"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = if (isModelTrained) {
                                MaterialTheme.colorScheme.onTertiaryContainer
                            } else {
                                MaterialTheme.colorScheme.onSecondaryContainer
                            }
                        )
                    }
                }
            }
            
            if (!isModelTrained) {
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "💡 Tip: Para mejores resultados, graba en un ambiente silencioso",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSecondaryContainer
                )
            }
        }
    }
}

/**
 * Grid de opciones principales
 */
@Composable
private fun MainOptionsGrid(
    isModelTrained: Boolean,
    onRecordingClick: () -> Unit,
    onTrainingClick: () -> Unit,
    onTtsClick: () -> Unit
) {
    val options = mutableListOf<MainOption>().apply {
        add(MainOption(
            title = "Grabar Voz",
            description = "Captura tu voz para entrenar",
            icon = Icons.Default.Mic,
            color = MaterialTheme.colorScheme.primary,
            onClick = onRecordingClick
        ))
        
        if (isModelTrained) {
            add(MainOption(
                title = "Generar TTS",
                description = "Convierte texto a voz con tu modelo",
                icon = Icons.Default.TextToSpeech,
                color = MaterialTheme.colorScheme.secondary,
                onClick = onTtsClick
            ))
        } else {
            add(MainOption(
                title = "Entrenar Modelo",
                description = "Entrena el modelo con tu voz grabada",
                icon = Icons.Default.ModelTraining,
                color = MaterialTheme.colorScheme.secondary,
                onClick = onTrainingClick,
                enabled = false
            ))
        }
    }

    LazyVerticalGrid(
        columns = GridCells.Fixed(1),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.height(200.dp)
    ) {
        items(options) { option ->
            OptionCard(
                option = option,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

/**
 * Tarjeta de opción individual
 */
@Composable
private fun OptionCard(
    option: MainOption,
    modifier: Modifier = Modifier
) {
    Card(
        onClick = { if (option.enabled) option.onClick() },
        enabled = option.enabled,
        modifier = modifier,
        colors = CardDefaults.cardColors(
            containerColor = option.color.copy(alpha = 0.1f),
            disabledContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        )
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = option.color.copy(alpha = 0.2f),
                modifier = Modifier.size(48.dp)
            ) {
                Box(
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = option.icon,
                        contentDescription = option.title,
                        tint = option.color,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
            
            Spacer(modifier = Modifier.width(16.dp))
            
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = option.title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = option.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            
            if (!option.enabled) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = "No disponible",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(20.dp)
                )
            } else {
                Icon(
                    imageVector = Icons.Default.ChevronRight,
                    contentDescription = "Ir a ${option.title}",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

/**
 * Opciones secundarias
 */
@Composable
private fun SecondaryOptions(
    onSettingsClick: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Configuración
        Surface(
            onClick = onSettingsClick,
            shape = RoundedCornerShape(12.dp),
            color = MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier.weight(1f)
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Configuración",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

/**
 * Formatear fecha en formato legible
 */
private fun formatDate(timestamp: Long): String {
    // Implementación simple, en una app real usarías un formatter apropiado
    return "hace poco tiempo"
}

// Datos para las opciones
data class MainOption(
    val title: String,
    val description: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val color: Color,
    val onClick: () -> Unit,
    val enabled: Boolean = true
)