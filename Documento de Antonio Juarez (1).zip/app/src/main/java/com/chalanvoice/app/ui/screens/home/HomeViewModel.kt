package com.chalanvoice.app.ui.screens.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.chalanvoice.app.domain.repository.UserPreferencesRepository
import com.chalanvoice.app.domain.repository.VoiceModelRepository
import com.chalanvoice.app.domain.repository.AuthRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import timber.log.Timber
import javax.inject.Inject

/**
 * Estado de la UI para la pantalla de inicio
 */
data class HomeUiState(
    val userName: String? = null,
    val isModelTrained: Boolean = false,
    val lastTrainingTime: Long? = null,
    val isLoading: Boolean = false,
    val errorMessage: String? = null
)

/**
 * Eventos de la UI para la pantalla de inicio
 */
sealed class HomeUiEvent {
    data object RefreshData : HomeUiEvent()
    data object DismissError : HomeUiEvent()
}

/**
 * ViewModel para manejar la lógica de la pantalla de inicio
 */
@HiltViewModel
class HomeViewModel @Inject constructor(
    private val userPreferencesRepository: UserPreferencesRepository,
    private val voiceModelRepository: VoiceModelRepository,
    private val authRepository: AuthRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    init {
        refreshData()
    }

    fun onEvent(event: HomeUiEvent) {
        when (event) {
            is HomeUiEvent.RefreshData -> {
                refreshData()
            }
            is HomeUiEvent.DismissError -> {
                updateState(_uiState.value.copy(errorMessage = null))
            }
        }
    }

    /**
     * Actualizar todos los datos de la pantalla
     */
    private fun refreshData() {
        updateState(_uiState.value.copy(isLoading = true))

        viewModelScope.launch {
            try {
                combine(
                    userPreferencesRepository.getUserName(),
                    getModelStatus(),
                    getLastTrainingTime()
                ) { userName, isModelTrained, lastTrainingTime ->
                    HomeUiState(
                        userName = userName,
                        isModelTrained = isModelTrained,
                        lastTrainingTime = lastTrainingTime,
                        isLoading = false
                    )
                }.collect { newState ->
                    updateState(newState)
                }
            } catch (e: Exception) {
                Timber.e(e, "Error refreshing home data")
                updateState(_uiState.value.copy(
                    isLoading = false,
                    errorMessage = "Error al cargar los datos: ${e.message}"
                ))
            }
        }
    }

    /**
     * Obtener el estado del modelo de voz
     */
    private suspend fun getModelStatus(): kotlinx.coroutines.flow.Flow<Boolean> = kotlinx.coroutines.flow.flow {
        try {
            val authToken = authRepository.getCurrentAuthToken()
            if (authToken.isNullOrBlank()) {
                emit(false)
                return@flow
            }

            val modelStatus = voiceModelRepository.getModelStatus(authToken)
            emit(modelStatus.success && modelStatus.data?.isTrained == true)
        } catch (e: Exception) {
            Timber.w(e, "Error getting model status")
            emit(false)
        }
    }

    /**
     * Obtener la última vez que se entrenó el modelo
     */
    private suspend fun getLastTrainingTime(): kotlinx.coroutines.flow.Flow<Long?> = kotlinx.coroutines.flow.flow {
        try {
            val authToken = authRepository.getCurrentAuthToken()
            if (authToken.isNullOrBlank()) {
                emit(null)
                return@flow
            }

            val modelStatus = voiceModelRepository.getModelStatus(authToken)
            if (modelStatus.success && modelStatus.data != null) {
                emit(modelStatus.data.lastUpdate)
            } else {
                emit(null)
            }
        } catch (e: Exception) {
            Timber.w(e, "Error getting last training time")
            emit(null)
        }
    }

    /**
     * Actualizar el estado de la UI
     */
    private fun updateState(newState: HomeUiState) {
        _uiState.value = newState
    }
}