package com.chalanvoice.app.ui.screens.player

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import timber.log.Timber
import javax.inject.Inject

/**
 * Estado de la UI para el reproductor
 */
data class PlayerUiState(
    val audioUrl: String? = null,
    val audioTitle: String = "",
    val emotion: String = "",
    val isPlaying: Boolean = false,
    val isLoading: Boolean = false,
    val currentPosition: Long = 0L,
    val duration: Long = 0L,
    val isLooping: Boolean = false,
    val playbackSpeed: Float = 1.0f,
    val errorMessage: String? = null
)

/**
 * Eventos de la UI para el reproductor
 */
sealed class PlayerUiEvent {
    data object PlayPause : PlayerUiEvent()
    data object Stop : PlayerUiEvent()
    data object Previous : PlayerUiEvent()
    data object Next : PlayerUiEvent()
    data object Share : PlayerUiEvent()
    data object Download : PlayerUiEvent()
    data class SeekTo(val position: Long) : PlayerUiEvent()
    data object ToggleLoop : PlayerUiEvent()
    data class SetSpeed(val speed: Float) : PlayerUiEvent()
    data object DismissError : PlayerUiEvent()
}

/**
 * ViewModel para manejar la lógica del reproductor de audio
 */
@HiltViewModel
class PlayerViewModel @Inject.constructor(
    // Aquí se inyectarían repositorios para manejo de audio y compartir
) : ViewModel() {

    private val _uiState = MutableStateFlow(PlayerUiState())
    val uiState: StateFlow<PlayerUiState> = _uiState.asStateFlow()

    private var mediaPlayer: android.media.MediaPlayer? = null
    private var updateJob: kotlinx.coroutines.Job? = null

    fun onEvent(event: PlayerUiEvent) {
        when (event) {
            is PlayerUiEvent.PlayPause -> {
                togglePlayPause()
            }
            is PlayerUiEvent.Stop -> {
                stopPlayback()
            }
            is PlayerUiEvent.Previous -> {
                // Implementar navegación a audio anterior
                Timber.d("Previous audio requested")
            }
            is PlayerUiEvent.Next -> {
                // Implementar navegación a audio siguiente
                Timber.d("Next audio requested")
            }
            is PlayerUiEvent.Share -> {
                shareAudio()
            }
            is PlayerUiEvent.Download -> {
                downloadAudio()
            }
            is PlayerUiEvent.SeekTo -> {
                seekTo(event.position)
            }
            is PlayerUiEvent.ToggleLoop -> {
                toggleLoop()
            }
            is PlayerUiEvent.SetSpeed -> {
                setPlaybackSpeed(event.speed)
            }
            is PlayerUiEvent.DismissError -> {
                updateState(_uiState.value.copy(errorMessage = null))
            }
        }
    }

    /**
     * Inicializar con la URL del audio
     */
    fun initialize(audioUrl: String) {
        updateState(_uiState.value.copy(
            audioUrl = audioUrl,
            audioTitle = "Audio generado",
            emotion = "Custom",
            isLoading = true,
            currentPosition = 0L
        ))

        viewModelScope.launch {
            try {
                // En una implementación real, aquí se descargaría y cargaría el audio
                loadAudio(audioUrl)
            } catch (e: Exception) {
                Timber.e(e, "Error loading audio")
                updateState(_uiState.value.copy(
                    isLoading = false,
                    errorMessage = "Error al cargar el audio: ${e.message}"
                ))
            }
        }
    }

    /**
     * Cargar audio desde URL
     */
    private suspend fun loadAudio(audioUrl: String) {
        try {
            // Simular carga de audio (en una app real descargarías el archivo)
            kotlinx.coroutines.delay(1000)

            // Crear MediaPlayer simulado (en una app real usarías la URL real)
            mediaPlayer = android.media.MediaPlayer().apply {
                // En una implementación real: setDataSource(audioUrl)
                // Simular duración
                setOnPreparedListener {
                    updateState(_uiState.value.copy(
                        isLoading = false,
                        duration = it.duration.toLong()
                    ))
                    Timber.d("Audio loaded successfully")
                }
                // Simular preparación
                prepare()
            }

        } catch (e: Exception) {
            throw e
        }
    }

    /**
     * Alternar entre reproducir y pausar
     */
    private fun togglePlayPause() {
        val currentState = _uiState.value

        if (mediaPlayer == null) {
            updateState(currentState.copy(
                errorMessage = "No hay audio cargado para reproducir"
            ))
            return
        }

        try {
            if (currentState.isPlaying) {
                pausePlayback()
            } else {
                startPlayback()
            }
        } catch (e: Exception) {
            Timber.e(e, "Error toggling playback")
            updateState(currentState.copy(
                errorMessage = "Error al controlar la reproducción: ${e.message}"
            ))
        }
    }

    /**
     * Iniciar reproducción
     */
    private fun startPlayback() {
        mediaPlayer?.start()
        
        updateState(_uiState.value.copy(
            isPlaying = true
        ))

        // Iniciar actualización de posición
        startPositionUpdates()

        Timber.d("Playback started")
    }

    /**
     * Pausar reproducción
     */
    private fun pausePlayback() {
        mediaPlayer?.pause()
        
        updateState(_uiState.value.copy(
            isPlaying = false
        ))

        // Detener actualización de posición
        stopPositionUpdates()

        Timber.d("Playback paused")
    }

    /**
     * Detener reproducción
     */
    private fun stopPlayback() {
        mediaPlayer?.stop()
        mediaPlayer?.prepare()
        
        updateState(_uiState.value.copy(
            isPlaying = false,
            currentPosition = 0L
        ))

        // Detener actualización de posición
        stopPositionUpdates()

        Timber.d("Playback stopped")
    }

    /**
     * Ir a una posición específica
     */
    private fun seekTo(position: Long) {
        mediaPlayer?.seekTo(position.toInt())
        
        updateState(_uiState.value.copy(
            currentPosition = position
        ))

        Timber.d("Seeked to position: $position")
    }

    /**
     * Alternar reproducción en loop
     */
    private fun toggleLoop() {
        val currentState = _uiState.value
        val newLoopState = !currentState.isLooping

        mediaPlayer?.isLooping = newLoopState
        
        updateState(currentState.copy(
            isLooping = newLoopState
        ))

        Timber.d("Loop toggled to: $newLoopState")
    }

    /**
     * Establecer velocidad de reproducción
     */
    private fun setPlaybackSpeed(speed: Float) {
        try {
            mediaPlayer?.playbackParams = android.media.PlaybackParams().setSpeed(speed)
            
            updateState(_uiState.value.copy(
                playbackSpeed = speed
            ))

            Timber.d("Playback speed set to: $speed")
        } catch (e: Exception) {
            Timber.e(e, "Error setting playback speed")
            updateState(_uiState.value.copy(
                errorMessage = "Error al cambiar la velocidad: ${e.message}"
            ))
        }
    }

    /**
     * Compartir audio
     */
    private fun shareAudio() {
        val currentState = _uiState.value
        
        if (currentState.audioUrl.isNullOrBlank()) {
            updateState(currentState.copy(
                errorMessage = "No hay audio para compartir"
            ))
            return
        }

        viewModelScope.launch {
            try {
                // En una implementación real, aquí se compartiría el archivo de audio
                Timber.d("Sharing audio: ${currentState.audioUrl}")
                
                // Mostrar mensaje de éxito temporal
                updateState(currentState.copy(
                    // Aquí podrías agregar un campo para mostrar el estado de compartir
                ))
            } catch (e: Exception) {
                Timber.e(e, "Error sharing audio")
                updateState(currentState.copy(
                    errorMessage = "Error al compartir: ${e.message}"
                ))
            }
        }
    }

    /**
     * Descargar audio
     */
    private fun downloadAudio() {
        val currentState = _uiState.value
        
        if (currentState.audioUrl.isNullOrBlank()) {
            updateState(currentState.copy(
                errorMessage = "No hay audio para descargar"
            ))
            return
        }

        viewModelScope.launch {
            try {
                // En una implementación real, aquí se descargaría el audio al almacenamiento
                Timber.d("Downloading audio: ${currentState.audioUrl}")
                
                // Mostrar mensaje de éxito temporal
                updateState(currentState.copy(
                    // Aquí podrías agregar un campo para mostrar el estado de descarga
                ))
            } catch (e: Exception) {
                Timber.e(e, "Error downloading audio")
                updateState(currentState.value.copy(
                    errorMessage = "Error al descargar: ${e.message}"
                ))
            }
        }
    }

    /**
     * Iniciar actualizaciones de posición
     */
    private fun startPositionUpdates() {
        stopPositionUpdates() // Cancelar job anterior si existe
        
        updateJob = viewModelScope.launch {
            while (_uiState.value.isPlaying) {
                val currentPos = mediaPlayer?.currentPosition?.toLong() ?: 0L
                updateState(_uiState.value.copy(currentPosition = currentPos))
                
                kotlinx.coroutines.delay(1000) // Actualizar cada segundo
            }
        }
    }

    /**
     * Detener actualizaciones de posición
     */
    private fun stopPositionUpdates() {
        updateJob?.cancel()
        updateJob = null
    }

    /**
     * Actualizar el estado de la UI
     */
    private fun updateState(newState: PlayerUiState) {
        _uiState.value = newState
    }

    override fun onCleared() {
        super.onCleared()
        
        // Limpiar recursos
        stopPositionUpdates()
        mediaPlayer?.release()
        mediaPlayer = null
        
        Timber.d("PlayerViewModel cleared")
    }
}