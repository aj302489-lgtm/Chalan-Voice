package com.chalanvoice.app.ui.screens.recording

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.chalanvoice.app.R
import com.chalanvoice.app.ui.components.LoadingIndicator
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

/**
 * Pantalla principal para grabación de voz.
 * Permite al usuario grabar su voz con guía visual y controles intuitivos.
 */
@Composable
fun RecordingScreen(
    onRecordingComplete: (File) -> Unit,
    onNavigateBack: () -> Unit,
    viewModel: RecordingViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    // Manejar diálogo de permisos
    if (uiState.showPermissionDialog) {
        PermissionDialog(
            onRequestPermission = { viewModel.onEvent(RecordingUiEvent.RequestRecordingPermission) },
            onDismiss = { viewModel.onEvent(RecordingUiEvent.DismissPermissionDialog) }
        )
    }

    // Manejar guardado automático al completar grabación
    LaunchedEffect(uiState.canSaveRecording) {
        if (uiState.canSaveRecording && uiState.currentAudioFile != null) {
            // Auto-guardar después de 2 segundos para darle tiempo al usuario de revisar
            kotlinx.coroutines.delay(2000)
            viewModel.onEvent(RecordingUiEvent.SaveRecording)
        }
    }

    // Manejar navegación después de guardar
    LaunchedEffect(uiState.currentAudioFile) {
        if (uiState.currentAudioFile != null && !uiState.isLoading) {
            onRecordingComplete(uiState.currentAudioFile)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        if (uiState.isLoading) {
            LoadingIndicator(
                modifier = Modifier.align(Alignment.Center)
            )
        } else {
            RecordingContent(
                uiState = uiState,
                onEvent = viewModel::onEvent,
                onNavigateBack = onNavigateBack
            )
        }

        // Mostrar errores
        if (uiState.errorMessage != null) {
            AlertDialog(
                onDismissRequest = { viewModel.onEvent(RecordingUiEvent.DismissError) },
                title = { Text("Error") },
                text = { Text(uiState.errorMessage) },
                confirmButton = {
                    TextButton(
                        onClick = { viewModel.onEvent(RecordingUiEvent.DismissError) }
                    ) {
                        Text("Entendido")
                    }
                }
            )
        }
    }
}

/**
 * Contenido principal de la pantalla de grabación
 */
@Composable
private fun RecordingContent(
    uiState: RecordingUiState,
    onEvent: (RecordingUiEvent) -> Unit,
    onNavigateBack: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Header con botón de volver
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onNavigateBack
            ) {
                Icon(
                    Icons.Default.ArrowBack,
                    contentDescription = "Volver"
                )
            }
            
            Text(
                text = "Grabar Voz",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            
            Spacer(modifier = Modifier.width(48.dp)) // Spacer para balance
        }

        Spacer(modifier = Modifier.height(32.dp))

        // Guía de texto para grabación
        RecordingGuide()

        Spacer(modifier = Modifier.height(24.dp))

        // Visualizador de audio
        AudioVisualizer(
            isRecording = uiState.isRecording,
            audioLevel = uiState.audioLevel,
            modifier = Modifier.size(200.dp)
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Timer de grabación
        RecordingTimer(duration = uiState.recordingDuration)

        Spacer(modifier = Modifier.height(32.dp))

        // Controles de grabación
        RecordingControls(
            isRecording = uiState.isRecording,
            isPaused = uiState.isPaused,
            canStop = uiState.isRecording || uiState.isPaused,
            canSave = uiState.canSaveRecording,
            onToggleRecording = { onEvent(RecordingUiEvent.ToggleRecording) },
            onStopRecording = { onEvent(RecordingUiEvent.StopRecording) },
            onSaveRecording = { onEvent(RecordingUiEvent.SaveRecording) }
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Información adicional
        if (uiState.canSaveRecording) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                )
            ) {
                Column(
                    modifier = Modifier.padding(16.dp)
                ) {
                    Text(
                        text = "✓ Grabación completada",
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "La grabación se guardará automáticamente",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }
        }
    }
}

/**
 * Componente para la guía de grabación
 */
@Composable
private fun RecordingGuide() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Text(
                text = "Guía para una buena grabación",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            
            val tips = listOf(
                "• Habla de forma clara y natural",
                "• Evita ruidos de fondo",
                "• Mantén una distancia cómoda del micrófono",
                "• Graba entre 30 segundos a 2 minutos",
                "• Incluye variedad de entonaciones"
            )
            
            tips.forEach { tip ->
                Text(
                    text = tip,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(vertical = 2.dp)
                )
            }
        }
    }
}

/**
 * Visualizador de audio con forma de onda circular
 */
@Composable
private fun AudioVisualizer(
    isRecording: Boolean,
    audioLevel: Float,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier,
        contentAlignment = Alignment.Center
    ) {
        Canvas(
            modifier = Modifier.fillMaxSize()
        ) {
            val center = center
            val radius = minOf(size.width, size.height) / 2 - 16.dp.toPx()
            
            // Círculo base
            drawCircle(
                color = if (isRecording) MaterialTheme.colorScheme.primary 
                        else MaterialTheme.colorScheme.surfaceVariant,
                radius = radius,
                center = center
            )
            
            // Ondas de audio simuladas
            if (isRecording) {
                repeat(3) { index ->
                    val waveRadius = radius + (index + 1) * 8.dp.toPx()
                    val alpha = 1f - (index * 0.3f)
                    val strokeWidth = 4.dp.toPx()
                    
                    drawCircle(
                        color = MaterialTheme.colorScheme.onPrimary.copy(alpha = alpha * audioLevel),
                        radius = waveRadius,
                        center = center,
                        style = androidx.compose.ui.graphics.PaintingStyle.Stroke.copy(
                            strokeCap = StrokeCap.Round
                        ),
                        strokeWidth = strokeWidth
                    )
                }
            }
        }
        
        // Indicador central
        Surface(
            shape = CircleShape,
            color = if (isRecording) MaterialTheme.colorScheme.onPrimary 
                    else MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(80.dp)
        ) {
            Box(
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isRecording) Icons.Default.Stop else Icons.Default.Mic,
                    contentDescription = if (isRecording) "Detener" else "Grabar",
                    modifier = Modifier.size(32.dp),
                    tint = if (isRecording) MaterialTheme.colorScheme.primary 
                           else MaterialTheme.colorScheme.onPrimary
                )
            }
        }
    }
}

/**
 * Timer de grabación
 */
@Composable
private fun RecordingTimer(duration: Long) {
    val formattedTime = remember(duration) {
        val minutes = duration / 1000 / 60
        val seconds = (duration / 1000) % 60
        val millis = (duration % 1000) / 10
        String.format("%02d:%02d.%02d", minutes, seconds, millis)
    }

    Text(
        text = formattedTime,
        style = MaterialTheme.typography.displaySmall,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onBackground
    )
}

/**
 * Controles de grabación
 */
@Composable
private fun RecordingControls(
    isRecording: Boolean,
    isPaused: Boolean,
    canStop: Boolean,
    canSave: Boolean,
    onToggleRecording: () -> Unit,
    onStopRecording: () -> Unit,
    onSaveRecording: () -> Unit
) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Botón de pausa/reanudar
        if (canStop) {
            IconButton(
                onClick = onStopRecording,
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
            ) {
                Box(
                    contentAlignment = Alignment.Center
                ) {
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.fillMaxSize()
                    ) {
                        Icon(
                            imageVector = Icons.Default.Stop,
                            contentDescription = "Detener",
                            modifier = Modifier.size(24.dp),
                            tint = MaterialTheme.colorScheme.onSecondary
                        )
                    }
                }
            }
        }

        // Botón principal de grabación
        FloatingActionButton(
            onClick = onToggleRecording,
            modifier = Modifier.size(72.dp),
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary
        ) {
            Icon(
                imageVector = if (isRecording) Icons.Default.Pause else Icons.Default.Mic,
                contentDescription = if (isRecording) "Pausar" else "Grabar",
                modifier = Modifier.size(32.dp)
            )
        }

        // Botón de guardar
        if (canSave) {
            IconButton(
                onClick = onSaveRecording,
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
            ) {
                Box(
                    contentAlignment = Alignment.Center
                ) {
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.tertiary,
                        modifier = Modifier.fillMaxSize()
                    ) {
                        Icon(
                            imageVector = Icons.Default.Save,
                            contentDescription = "Guardar",
                            modifier = Modifier.size(24.dp),
                            tint = MaterialTheme.colorScheme.onTertiary
                        )
                    }
                }
            }
        }
    }
}

/**
 * Diálogo de permisos de grabación
 */
@Composable
private fun PermissionDialog(
    onRequestPermission: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Permiso de micrófono requerido") },
        text = { 
            Text("Chalan Voice necesita acceso al micrófono para grabar tu voz y crear tu modelo TTS personalizado.")
        },
        confirmButton = {
            TextButton(
                onClick = {
                    onRequestPermission()
                    onDismiss()
                }
            ) {
                Text("Conceder Permiso")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar")
            }
        }
    )
}