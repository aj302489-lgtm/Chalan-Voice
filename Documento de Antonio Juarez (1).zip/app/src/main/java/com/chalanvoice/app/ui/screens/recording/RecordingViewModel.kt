package com.chalanvoice.app.ui.screens.recording

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.chalanvoice.app.domain.model.AudioFile
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import timber.log.Timber
import java.io.File
import javax.inject.Inject

/**
 * Estado de la UI para la pantalla de grabación
 */
data class RecordingUiState(
    val isRecording: Boolean = false,
    val isPaused: Boolean = false,
    val recordingDuration: Long = 0L,
    val audioLevel: Float = 0f,
    val currentAudioFile: File? = null,
    val isLoading: Boolean = false,
    val showPermissionDialog: Boolean = false,
    val errorMessage: String? = null,
    val hasRecordingPermission: Boolean = false,
    val canSaveRecording: Boolean = false
)

/**
 * Eventos de la UI para la pantalla de grabación
 */
sealed class RecordingUiEvent {
    data object RequestRecordingPermission : RecordingUiEvent()
    data object ToggleRecording : RecordingUiEvent()
    data object PauseRecording : RecordingUiEvent()
    data object StopRecording : RecordingUiEvent()
    data object SaveRecording : RecordingUiEvent()
    data object DismissPermissionDialog : RecordingUiEvent()
    data object DismissError : RecordingUiEvent()
    data class UpdateAudioLevel(val level: Float) : RecordingUiEvent()
}

/**
 * ViewModel para manejar la lógica de grabación de voz
 */
@HiltViewModel
class RecordingViewModel @Inject constructor() : ViewModel() {

    private val _uiState = MutableStateFlow(RecordingUiState())
    val uiState: StateFlow<RecordingUiState> = _uiState.asStateFlow()

    // Variables para el MediaRecorder
    private var mediaRecorder: android.media.MediaRecorder? = null
    private var recordingFile: File? = null
    private var recordingStartTime: Long = 0L

    init {
        // Verificar permisos al inicializar
        checkRecordingPermission()
    }

    /**
     * Verificar si tenemos permiso de grabación
     */
    fun checkRecordingPermission() {
        // Esta función debería ser implementada usando Accompanist Permissions
        // Por ahora, asumimos que tenemos permisos
        updateState(_uiState.value.copy(
            hasRecordingPermission = true,
            showPermissionDialog = false
        ))
    }

    fun onEvent(event: RecordingUiEvent) {
        when (event) {
            is RecordingUiEvent.RequestRecordingPermission -> {
                updateState(_uiState.value.copy(
                    showPermissionDialog = true,
                    hasRecordingPermission = false
                ))
            }
            is RecordingUiEvent.ToggleRecording -> {
                if (_uiState.value.isRecording) {
                    pauseRecording()
                } else {
                    startRecording()
                }
            }
            is RecordingUiEvent.PauseRecording -> {
                pauseRecording()
            }
            is RecordingUiEvent.StopRecording -> {
                stopRecording()
            }
            is RecordingUiEvent.SaveRecording -> {
                saveRecording()
            }
            is RecordingUiEvent.DismissPermissionDialog -> {
                updateState(_uiState.value.copy(showPermissionDialog = false))
            }
            is RecordingUiEvent.DismissError -> {
                updateState(_uiState.value.copy(errorMessage = null))
            }
            is RecordingUiEvent.UpdateAudioLevel -> {
                updateState(_uiState.value.copy(audioLevel = event.level))
            }
        }
    }

    /**
     * Iniciar la grabación de audio
     */
    private fun startRecording() {
        try {
            if (_uiState.value.isPaused) {
                // Reanudar grabación pausada
                mediaRecorder?.resume()
                updateState(_uiState.value.copy(
                    isRecording = true,
                    isPaused = false
                ))
                return
            }

            // Crear archivo temporal para la grabación
            recordingFile = File.createTempFile("recording_${System.currentTimeMillis()}", ".3gp")
            
            // Configurar MediaRecorder
            mediaRecorder = android.media.MediaRecorder().apply {
                setAudioSource(android.media.MediaRecorder.AudioSource.MIC)
                setOutputFormat(android.media.MediaRecorder.OutputFormat.THREE_GPP)
                setAudioEncoder(android.media.MediaRecorder.AudioEncoder.AMR_NB)
                setOutputFile(recordingFile?.absolutePath)
                
                try {
                    prepare()
                } catch (e: Exception) {
                    Timber.e(e, "Error preparing MediaRecorder")
                    handleError("Error al preparar la grabación: ${e.message}")
                    return
                }
                
                start()
            }

            recordingStartTime = System.currentTimeMillis()
            updateState(_uiState.value.copy(
                isRecording = true,
                isPaused = false,
                currentAudioFile = recordingFile,
                recordingDuration = 0L,
                canSaveRecording = false
            ))

            // Simular actualización de duración (en una app real usarías un handler)
            startDurationTimer()

            Timber.d("Recording started")
            
        } catch (e: Exception) {
            Timber.e(e, "Error starting recording")
            handleError("Error al iniciar la grabación: ${e.message}")
        }
    }

    /**
     * Pausar la grabación
     */
    private fun pauseRecording() {
        mediaRecorder?.pause()
        updateState(_uiState.value.copy(
            isRecording = false,
            isPaused = true
        ))
        Timber.d("Recording paused")
    }

    /**
     * Detener la grabación
     */
    private fun stopRecording() {
        try {
            mediaRecorder?.apply {
                stop()
                release()
            }
            mediaRecorder = null

            val duration = System.currentTimeMillis() - recordingStartTime
            
            updateState(_uiState.value.copy(
                isRecording = false,
                isPaused = false,
                recordingDuration = duration,
                canSaveRecording = true
            ))

            Timber.d("Recording stopped, duration: ${duration}ms")
            
        } catch (e: Exception) {
            Timber.e(e, "Error stopping recording")
            handleError("Error al detener la grabación: ${e.message}")
        }
    }

    /**
     * Guardar la grabación
     */
    private fun saveRecording() {
        val currentState = _uiState.value
        
        viewModelScope.launch {
            updateState(currentState.copy(isLoading = true))
            
            try {
                // Aquí deberías copiar el archivo temporal a una ubicación permanente
                // y crear el objeto AudioFile correspondiente
                
                val savedFile = recordingFile?.let { tempFile ->
                    val finalFile = File(
                        tempFile.parentFile,
                        "chalan_voice_recording_${System.currentTimeMillis()}.3gp"
                    )
                    tempFile.copyTo(finalFile, overwrite = true)
                    tempFile.delete() // Eliminar archivo temporal
                    finalFile
                }

                val audioFile = AudioFile(
                    name = "Recording ${System.currentTimeMillis()}",
                    path = savedFile?.absolutePath ?: "",
                    duration = currentState.recordingDuration,
                    size = savedFile?.length() ?: 0L
                )

                updateState(currentState.copy(
                    isLoading = false,
                    canSaveRecording = false,
                    currentAudioFile = savedFile
                ))

                Timber.d("Recording saved: $audioFile")
                
            } catch (e: Exception) {
                Timber.e(e, "Error saving recording")
                updateState(currentState.copy(
                    isLoading = false,
                    errorMessage = "Error al guardar la grabación: ${e.message}"
                ))
            }
        }
    }

    /**
     * Timer para actualizar la duración de la grabación
     */
    private fun startDurationTimer() {
        viewModelScope.launch {
            kotlinx.coroutines.delay(100) // Actualizar cada 100ms
            if (_uiState.value.isRecording) {
                val newDuration = System.currentTimeMillis() - recordingStartTime
                updateState(_uiState.value.copy(recordingDuration = newDuration))
                startDurationTimer() // Continuar actualizando
            }
        }
    }

    /**
     * Actualizar el estado de la UI
     */
    private fun updateState(newState: RecordingUiState) {
        _uiState.value = newState
    }

    /**
     * Manejar errores
     */
    private fun handleError(message: String) {
        updateState(_uiState.value.copy(
            errorMessage = message,
            isRecording = false,
            isPaused = false,
            isLoading = false
        ))
    }

    override fun onCleared() {
        super.onCleared()
        mediaRecorder?.apply {
            try {
                stop()
                release()
            } catch (e: Exception) {
                Timber.e(e, "Error releasing MediaRecorder")
            }
        }
        mediaRecorder = null
        
        // Limpiar archivo temporal si existe
        recordingFile?.delete()
    }
}