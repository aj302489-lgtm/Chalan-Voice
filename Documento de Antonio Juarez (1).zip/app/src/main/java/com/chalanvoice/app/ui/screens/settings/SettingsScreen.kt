package com.chalanvoice.app.ui.screens.settings

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.chalanvoice.app.R
import com.chalanvoice.app.domain.model.TtsEmotion

/**
 * Pantalla de configuración de la aplicación.
 * Permite gestionar el modelo de voz, preferencias y información de la app.
 */
@Composable
fun SettingsScreen(
    onNavigateBack: () -> Unit,
    onLogout: () -> Unit,
    viewModel: SettingsViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    // Manejar acciones de logout
    LaunchedEffect(uiState.showLogoutConfirmation) {
        if (uiState.showLogoutConfirmation) {
            // Esperar un momento antes de proceder con el logout
            kotlinx.coroutines.delay(500)
            onLogout()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        SettingsContent(
            uiState = uiState,
            onEvent = viewModel::onEvent,
            onNavigateBack = onNavigateBack
        )
    }

    // Diálogos de confirmación
    if (uiState.showDeleteModelDialog) {
        DeleteModelDialog(
            onConfirm = { viewModel.onEvent(SettingsUiEvent.ConfirmDeleteModel) },
            onDismiss = { viewModel.onEvent(SettingsUiEvent.DismissDeleteModelDialog) }
        )
    }

    if (uiState.showLogoutConfirmation) {
        LogoutConfirmationDialog(
            onConfirm = { viewModel.onEvent(SettingsUiEvent.ConfirmLogout) },
            onDismiss = { viewModel.onEvent(SettingsUiEvent.DismissLogoutConfirmation) }
        )
    }

    // Mostrar errores
    if (uiState.errorMessage != null) {
        AlertDialog(
            onDismissRequest = { viewModel.onEvent(SettingsUiEvent.DismissError) },
            title = { Text("Error") },
            text = { Text(uiState.errorMessage) },
            confirmButton = {
                TextButton(
                    onClick = { viewModel.onEvent(SettingsUiEvent.DismissError) }
                ) {
                    Text("Entendido")
                }
            }
        )
    }
}

/**
 * Contenido principal de la pantalla de configuración
 */
@Composable
private fun SettingsContent(
    uiState: SettingsUiState,
    onEvent: (SettingsUiEvent) -> Unit,
    onNavigateBack: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onNavigateBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Volver")
                }
                
                Text(
                    text = "Configuración",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                
                Spacer(modifier = Modifier.width(48.dp))
            }
        }

        // Información del usuario
        item {
            UserInfoSection(
                userEmail = uiState.userEmail,
                userName = uiState.userName,
                modelStatus = uiState.modelStatus
            )
        }

        // Configuración del modelo de voz
        item {
            ModelSettingsSection(
                isModelTrained = uiState.isModelTrained,
                lastTrainingTime = uiState.lastTrainingTime,
                preferredEmotion = uiState.preferredEmotion,
                onDeleteModel = { onEvent(SettingsUiEvent.ShowDeleteModelDialog) },
                onPreferredEmotionChange = { emotion -> 
                    onEvent(SettingsUiEvent.UpdatePreferredEmotion(emotion)) 
                }
            )
        }

        // Preferencias de aplicación
        item {
            AppPreferencesSection(
                autoSaveRecordings = uiState.autoSaveRecordings,
                darkModeEnabled = uiState.darkModeEnabled,
                notificationsEnabled = uiState.notificationsEnabled,
                onAutoSaveToggle = { onEvent(SettingsUiEvent.ToggleAutoSave) },
                onDarkModeToggle = { onEvent(SettingsUiEvent.ToggleDarkMode) },
                onNotificationsToggle = { onEvent(SettingsUiEvent.ToggleNotifications) }
            )
        }

        // Información y ayuda
        item {
            InfoSection(
                onShowPrivacyPolicy = { onEvent(SettingsUiEvent.ShowPrivacyPolicy) },
                onShowTermsOfService = { onEvent(SettingsUiEvent.ShowTermsOfService) },
                onShowAbout = { onEvent(SettingsUiEvent.ShowAbout) },
                onContactSupport = { onEvent(SettingsUiEvent.ContactSupport) }
            )
        }

        // Información de la app
        item {
            AppInfoSection(
                versionName = uiState.versionName,
                buildNumber = uiState.buildNumber
            )
        }

        // Botón de cerrar sesión
        item {
            LogoutSection(
                onLogout = { onEvent(SettingsUiEvent.ShowLogoutConfirmation) }
            )
        }

        item {
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

/**
 * Sección de información del usuario
 */
@Composable
private fun UserInfoSection(
    userEmail: String?,
    userName: String?,
    modelStatus: String
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Text(
                text = "Información de Usuario",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onPrimaryContainer
            )
            
            Spacer(modifier = Modifier.height(12.dp))
            
            if (userName != null) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Person,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Nombre: $userName",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }
            
            if (userEmail != null) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Email,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Email: $userEmail",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }
            
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(vertical = 4.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.ModelTraining,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onPrimaryContainer,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Estado: $modelStatus",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
            }
        }
    }
}

/**
 * Sección de configuración del modelo de voz
 */
@Composable
private fun ModelSettingsSection(
    isModelTrained: Boolean,
    lastTrainingTime: Long?,
    preferredEmotion: TtsEmotion,
    onDeleteModel: () -> Unit,
    onPreferredEmotionChange: (TtsEmotion) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Text(
                text = "Modelo de Voz",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(bottom = 12.dp)
            )
            
            // Estado del modelo
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = if (isModelTrained) "Modelo entrenado" else "Modelo no entrenado",
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (isModelTrained && lastTrainingTime != null) {
                        Text(
                            text = "Último entrenamiento: ${formatDate(lastTrainingTime)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = if (isModelTrained) {
                        MaterialTheme.colorScheme.tertiary
                    } else {
                        MaterialTheme.colorScheme.error
                    },
                    modifier = Modifier.padding(4.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (isModelTrained) Icons.Default.CheckCircle else Icons.Default.Warning,
                            contentDescription = null,
                            tint = if (isModelTrained) {
                                MaterialTheme.colorScheme.onTertiary
                            } else {
                                MaterialTheme.colorScheme.onError
                            },
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (isModelTrained) "Activo" : "Inactivo",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (isModelTrained) {
                                MaterialTheme.colorScheme.onTertiary
                            } else {
                                MaterialTheme.colorScheme.onError
                            }
                        )
                    }
                }
            }
            
            if (isModelTrained) {
                Spacer(modifier = Modifier.height(16.dp))
                
                // Emoción preferida
                Text(
                    text = "Emoción preferida",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                
                DropdownMenuBox(
                    selectedItem = preferredEmotion,
                    items = TtsEmotion.values().toList(),
                    onItemSelected = onPreferredEmotionChange,
                    itemDisplayName = { it.displayName }
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // Botón eliminar modelo
                Button(
                    onClick = onDeleteModel,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error
                    )
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = null,
                        modifier = Modifier.padding(end = 8.dp)
                    )
                    Text("Eliminar Modelo de Voz")
                }
            } else {
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "📝 Ve a la pantalla de inicio para entrenar tu modelo de voz",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

/**
 * Sección de preferencias de la aplicación
 */
@Composable
private fun AppPreferencesSection(
    autoSaveRecordings: Boolean,
    darkModeEnabled: Boolean,
    notificationsEnabled: Boolean,
    onAutoSaveToggle: () -> Unit,
    onDarkModeToggle: () -> Unit,
    onNotificationsToggle: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.secondaryContainer
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Text(
                text = "Preferencias",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSecondaryContainer,
                modifier = Modifier.padding(bottom = 12.dp)
            )
            
            // Auto-guardar grabaciones
            PreferenceItem(
                title = "Auto-guardar grabaciones",
                description = "Guarda automáticamente las grabaciones de voz",
                checked = autoSaveRecordings,
                onToggle = onAutoSaveToggle
            )
            
            // Modo oscuro
            PreferenceItem(
                title = "Modo oscuro",
                description = "Usar tema oscuro en toda la aplicación",
                checked = darkModeEnabled,
                onToggle = onDarkModeToggle
            )
            
            // Notificaciones
            PreferenceItem(
                title = "Notificaciones",
                description = "Recibir notificaciones sobre el estado del entrenamiento",
                checked = notificationsEnabled,
                onToggle = onNotificationsToggle
            )
        }
    }
}

/**
 * Item de preferencia con switch
 */
@Composable
private fun PreferenceItem(
    title: String,
    description: String,
    checked: Boolean,
    onToggle: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSecondaryContainer
            )
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.8f)
            )
        }
        
        Switch(
            checked = checked,
            onCheckedChange = { onToggle() }
        )
    }
}

/**
 * Sección de información y ayuda
 */
@Composable
private fun InfoSection(
    onShowPrivacyPolicy: () -> Unit,
    onShowTermsOfService: () -> Unit,
    onShowAbout: () -> Unit,
    onContactSupport: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Text(
                text = "Información y Ayuda",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(bottom = 12.dp)
            )
            
            // Política de privacidad
            InfoItem(
                icon = Icons.Default.Privacy,
                title = "Política de Privacidad",
                description = "Ver cómo protegemos tus datos",
                onClick = onShowPrivacyPolicy
            )
            
            // Términos de servicio
            InfoItem(
                icon = Icons.Default.Article,
                title = "Términos de Servicio",
                description = "Términos y condiciones de uso",
                onClick = onShowTermsOfService
            )
            
            // Acerca de
            InfoItem(
                icon = Icons.Default.Info,
                title = "Acerca de Chalan Voice",
                description = "Información sobre la aplicación",
                onClick = onShowAbout
            )
            
            // Soporte
            InfoItem(
                icon = Icons.Default.Support,
                title = "Contactar Soporte",
                description = "Obtener ayuda y reportar problemas",
                onClick = onContactSupport
            )
        }
    }
}

/**
 * Item de información con icono
 */
@Composable
private fun InfoItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    description: String,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(8.dp),
        color = Color.Transparent,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(20.dp)
            )
            
            Spacer(modifier = Modifier.width(12.dp))
            
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            
            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = "Ir",
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(16.dp)
            )
        }
    }
}

/**
 * Información de la aplicación
 */
@Composable
private fun AppInfoSection(
    versionName: String,
    buildNumber: String
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.tertiaryContainer
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Chalan Voice",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onTertiaryContainer
            )
            
            Text(
                text = "Versión $versionName ($buildNumber)",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onTertiaryContainer,
                modifier = Modifier.padding(top = 4.dp)
            )
            
            Text(
                text = "Tu asistente de voz personalizado",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onTertiaryContainer.copy(alpha = 0.8f),
                modifier = Modifier.padding(top = 2.dp)
            )
        }
    }
}

/**
 * Sección de cerrar sesión
 */
@Composable
private fun LogoutSection(
    onLogout: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.errorContainer
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Text(
                text = "Cuenta",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onErrorContainer,
                modifier = Modifier.padding(bottom = 12.dp)
            )
            
            Button(
                onClick = onLogout,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.error
                )
            ) {
                Icon(
                    imageVector = Icons.Default.Logout,
                    contentDescription = null,
                    modifier = Modifier.padding(end = 8.dp)
                )
                Text("Cerrar Sesión")
            }
        }
    }
}

/**
 * Dropdown menu simplificado
 */
@Composable
private fun <T> DropdownMenuBox(
    selectedItem: T,
    items: List<T>,
    onItemSelected: (T) -> Unit,
    itemDisplayName: (T) -> String
) {
    var expanded by remember { mutableStateOf(false) }
    
    Box {
        Surface(
            onClick = { expanded = true },
            shape = RoundedCornerShape(8.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = itemDisplayName(selectedItem),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Icon(
                    imageVector = Icons.Default.ArrowDropDown,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurface
                )
            }
        }
        
        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            items.forEach { item ->
                DropdownMenuItem(
                    text = { Text(itemDisplayName(item)) },
                    onClick = {
                        onItemSelected(item)
                        expanded = false
                    }
                )
            }
        }
    }
}

/**
 * Formatear fecha para mostrar
 */
private fun formatDate(timestamp: Long): String {
    // Implementación simple - en una app real usarías un DateFormatter
    return "hace poco tiempo"
}

/**
 * Diálogo de confirmación para eliminar modelo
 */
@Composable
private fun DeleteModelDialog(
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Eliminar Modelo de Voz") },
        text = { 
            Text("¿Estás seguro de que deseas eliminar tu modelo de voz personalizado? Esta acción no se puede deshacer y tendrás que volver a entrenar tu modelo si quieres generar audio con tu voz.") 
        },
        confirmButton = {
            TextButton(
                onClick = onConfirm,
                colors = ButtonDefaults.textButtonColors(
                    contentColor = MaterialTheme.colorScheme.error
                )
            ) {
                Text("Eliminar")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar")
            }
        }
    )
}

/**
 * Diálogo de confirmación para cerrar sesión
 */
@Composable
private fun LogoutConfirmationDialog(
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Cerrar Sesión") },
        text = { 
            Text("¿Estás seguro de que deseas cerrar sesión? Tendrás que volver a iniciar sesión para usar la aplicación.") 
        },
        confirmButton = {
            TextButton(
                onClick = onConfirm,
                colors = ButtonDefaults.textButtonColors(
                    contentColor = MaterialTheme.colorScheme.error
                )
            ) {
                Text("Cerrar Sesión")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar")
            }
        }
    )
}