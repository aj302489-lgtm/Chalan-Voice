package com.chalanvoice.app.ui.screens.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.chalanvoice.app.domain.model.TtsEmotion
import com.chalanvoice.app.domain.repository.AuthRepository
import com.chalanvoice.app.domain.repository.UserPreferencesRepository
import com.chalanvoice.app.domain.repository.VoiceModelRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import timber.log.Timber
import javax.inject.Inject

/**
 * Estado de la UI para la pantalla de configuración
 */
data class SettingsUiState(
    // Información del usuario
    val userEmail: String? = null,
    val userName: String? = null,
    val modelStatus: String = "No entrenado",
    
    // Estado del modelo
    val isModelTrained: Boolean = false,
    val lastTrainingTime: Long? = null,
    val preferredEmotion: TtsEmotion = TtsEmotion.NEUTRAL,
    
    // Preferencias
    val autoSaveRecordings: Boolean = true,
    val darkModeEnabled: Boolean = true,
    val notificationsEnabled: Boolean = true,
    
    // Estados de diálogo
    val showDeleteModelDialog: Boolean = false,
    val showLogoutConfirmation: Boolean = false,
    
    // Estados de carga
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
    
    // Información de la app
    val versionName: String = "1.0.0",
    val buildNumber: String = "1"
)

/**
 * Eventos de la UI para la pantalla de configuración
 */
sealed class SettingsUiEvent {
    data object ShowDeleteModelDialog : SettingsUiEvent()
    data object DismissDeleteModelDialog : SettingsUiEvent()
    data object ConfirmDeleteModel : SettingsUiEvent()
    data object ShowLogoutConfirmation : SettingsUiEvent()
    data object DismissLogoutConfirmation : SettingsUiEvent()
    data object ConfirmLogout : SettingsUiEvent()
    
    data class UpdatePreferredEmotion(val emotion: TtsEmotion) : SettingsUiEvent()
    
    data object ToggleAutoSave : SettingsUiEvent()
    data object ToggleDarkMode : SettingsUiEvent()
    data object ToggleNotifications : SettingsUiEvent()
    
    data object ShowPrivacyPolicy : SettingsUiEvent()
    data object ShowTermsOfService : SettingsUiEvent()
    data object ShowAbout : SettingsUiEvent()
    data object ContactSupport : SettingsUiEvent()
    
    data object DismissError : SettingsUiEvent()
}

/**
 * ViewModel para manejar la lógica de la pantalla de configuración
 */
@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val userPreferencesRepository: UserPreferencesRepository,
    private val voiceModelRepository: VoiceModelRepository,
    private val authRepository: AuthRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(SettingsUiState())
    val uiState: StateFlow<SettingsUiState> = _uiState.asStateFlow()

    init {
        loadSettingsData()
    }

    fun onEvent(event: SettingsUiEvent) {
        when (event) {
            is SettingsUiEvent.ShowDeleteModelDialog -> {
                updateState(_uiState.value.copy(showDeleteModelDialog = true))
            }
            is SettingsUiEvent.DismissDeleteModelDialog -> {
                updateState(_uiState.value.copy(showDeleteModelDialog = false))
            }
            is SettingsUiEvent.ConfirmDeleteModel -> {
                deleteModel()
            }
            is SettingsUiEvent.ShowLogoutConfirmation -> {
                updateState(_uiState.value.copy(showLogoutConfirmation = true))
            }
            is SettingsUiEvent.DismissLogoutConfirmation -> {
                updateState(_uiState.value.copy(showLogoutConfirmation = false))
            }
            is SettingsUiEvent.ConfirmLogout -> {
                performLogout()
            }
            is SettingsUiEvent.UpdatePreferredEmotion -> {
                updatePreferredEmotion(event.emotion)
            }
            is SettingsUiEvent.ToggleAutoSave -> {
                toggleAutoSave()
            }
            is SettingsUiEvent.ToggleDarkMode -> {
                toggleDarkMode()
            }
            is SettingsUiEvent.ToggleNotifications -> {
                toggleNotifications()
            }
            is SettingsUiEvent.ShowPrivacyPolicy -> {
                showPrivacyPolicy()
            }
            is SettingsUiEvent.ShowTermsOfService -> {
                showTermsOfService()
            }
            is SettingsUiEvent.ShowAbout -> {
                showAbout()
            }
            is SettingsUiEvent.ContactSupport -> {
                contactSupport()
            }
            is SettingsUiEvent.DismissError -> {
                updateState(_uiState.value.copy(errorMessage = null))
            }
        }
    }

    /**
     * Cargar todos los datos de configuración
     */
    private fun loadSettingsData() {
        updateState(_uiState.value.copy(isLoading = true))

        viewModelScope.launch {
            try {
                combine(
                    userPreferencesRepository.getAuthTokenFlow(),
                    userPreferencesRepository.getAutoSaveRecordings(),
                    getUserInfo(),
                    getModelStatus(),
                    getPreferredEmotion(),
                    getLastTrainingTime()
                ) { authToken, autoSave, userInfo, modelStatus, preferredEmotion, lastTraining ->
                    SettingsUiState(
                        userEmail = userInfo.first,
                        userName = userInfo.second,
                        modelStatus = modelStatus,
                        isModelTrained = modelStatus == "Entrenado",
                        lastTrainingTime = lastTraining,
                        preferredEmotion = preferredEmotion,
                        autoSaveRecordings = autoSave,
                        darkModeEnabled = true, // Asumimos modo oscuro por defecto
                        notificationsEnabled = true,
                        isLoading = false
                    )
                }.collect { newState ->
                    updateState(newState)
                }
            } catch (e: Exception) {
                Timber.e(e, "Error loading settings data")
                updateState(_uiState.value.copy(
                    isLoading = false,
                    errorMessage = "Error al cargar la configuración: ${e.message}"
                ))
            }
        }
    }

    /**
     * Eliminar el modelo de voz
     */
    private fun deleteModel() {
        updateState(_uiState.value.copy(
            isLoading = true,
            showDeleteModelDialog = false
        ))

        viewModelScope.launch {
            try {
                val authToken = authRepository.getCurrentAuthToken()
                if (authToken.isNullOrBlank()) {
                    throw Exception("No hay token de autenticación")
                }

                // En una implementación real, aquí se haría la llamada al API
                // voiceModelRepository.deleteModel(authToken)
                
                // Simular eliminación
                kotlinx.coroutines.delay(1000)

                // Actualizar estado local
                updateState(_uiState.value.copy(
                    isLoading = false,
                    isModelTrained = false,
                    lastTrainingTime = null,
                    modelStatus = "No entrenado"
                ))

                Timber.d("Model deleted successfully")

            } catch (e: Exception) {
                Timber.e(e, "Error deleting model")
                updateState(_uiState.value.copy(
                    isLoading = false,
                    errorMessage = "Error al eliminar el modelo: ${e.message}"
                ))
            }
        }
    }

    /**
     * Realizar logout
     */
    private fun performLogout() {
        viewModelScope.launch {
            try {
                authRepository.logout()
                
                // Limpiar todas las preferencias
                userPreferencesRepository.clearAuthToken()
                
                // Navegar de vuelta (esto se maneja en el composable)
                updateState(_uiState.value.copy(showLogoutConfirmation = false))
                
                Timber.d("User logged out successfully")
                
            } catch (e: Exception) {
                Timber.e(e, "Error logging out")
                updateState(_uiState.value.copy(
                    showLogoutConfirmation = false,
                    errorMessage = "Error al cerrar sesión: ${e.message}"
                ))
            }
        }
    }

    /**
     * Actualizar emoción preferida
     */
    private fun updatePreferredEmotion(emotion: TtsEmotion) {
        // En una implementación real, guardarías la preferencia en el servidor
        updateState(_uiState.value.copy(
            preferredEmotion = emotion,
            errorMessage = null
        ))
        Timber.d("Preferred emotion updated to: $emotion")
    }

    /**
     * Alternar auto-guardado
     */
    private fun toggleAutoSave() {
        val currentState = _uiState.value
        val newValue = !currentState.autoSaveRecordings
        
        viewModelScope.launch {
            try {
                userPreferencesRepository.saveAutoSaveRecordings(newValue)
                updateState(currentState.copy(autoSaveRecordings = newValue))
                Timber.d("Auto-save toggled to: $newValue")
            } catch (e: Exception) {
                Timber.e(e, "Error toggling auto-save")
                updateState(currentState.copy(
                    errorMessage = "Error al cambiar la configuración: ${e.message}"
                ))
            }
        }
    }

    /**
     * Alternar modo oscuro
     */
    private fun toggleDarkMode() {
        val currentState = _uiState.value
        val newValue = !currentState.darkModeEnabled
        
        updateState(currentState.copy(darkModeEnabled = newValue))
        Timber.d("Dark mode toggled to: $newValue")
    }

    /**
     * Alternar notificaciones
     */
    private fun toggleNotifications() {
        val currentState = _uiState.value
        val newValue = !currentState.notificationsEnabled
        
        updateState(currentState.copy(notificationsEnabled = newValue))
        Timber.d("Notifications toggled to: $newValue")
    }

    /**
     * Mostrar política de privacidad
     */
    private fun showPrivacyPolicy() {
        // En una implementación real, abrirías una URL o mostrarías contenido
        Timber.d("Privacy policy requested")
    }

    /**
     * Mostrar términos de servicio
     */
    private fun showTermsOfService() {
        // En una implementación real, abrirías una URL o mostrarías contenido
        Timber.d("Terms of service requested")
    }

    /**
     * Mostrar información sobre la app
     */
    private fun showAbout() {
        // En una implementación real, mostrarías información detallada
        Timber.d("About dialog requested")
    }

    /**
     * Contactar soporte
     */
    private fun contactSupport() {
        // En una implementación real, abrirías un email o formulario de soporte
        Timber.d("Support contact requested")
    }

    /**
     * Obtener información del usuario
     */
    private suspend fun getUserInfo(): kotlinx.coroutines.flow.Flow<Pair<String?, String?>> = 
        kotlinx.coroutines.flow.flow {
            try {
                val token = authRepository.getCurrentAuthToken()
                // En una implementación real, decodificarías el JWT o harías una llamada al API
                emit(Pair("usuario@ejemplo.com", "Usuario"))
            } catch (e: Exception) {
                emit(Pair(null, null))
            }
        }

    /**
     * Obtener estado del modelo
     */
    private suspend fun getModelStatus(): kotlinx.coroutines.flow.Flow<String> = 
        kotlinx.coroutines.flow.flow {
            try {
                val authToken = authRepository.getCurrentAuthToken()
                if (authToken.isNullOrBlank()) {
                    emit("No entrenado")
                    return@flow
                }

                val modelStatus = voiceModelRepository.getModelStatus(authToken)
                if (modelStatus.success && modelStatus.data?.isTrained == true) {
                    emit("Entrenado")
                } else {
                    emit("No entrenado")
                }
            } catch (e: Exception) {
                Timber.w(e, "Error getting model status")
                emit("No entrenado")
            }
        }

    /**
     * Obtener emoción preferida
     */
    private suspend fun getPreferredEmotion(): kotlinx.coroutines.flow.Flow<TtsEmotion> = 
        kotlinx.coroutines.flow.flow {
            // En una implementación real, esto vendría del servidor o preferencias
            emit(TtsEmotion.NEUTRAL)
        }

    /**
     * Obtener último tiempo de entrenamiento
     */
    private suspend fun getLastTrainingTime(): kotlinx.coroutines.flow.Flow<Long?> = 
        kotlinx.coroutines.flow.flow {
            try {
                val authToken = authRepository.getCurrentAuthToken()
                if (authToken.isNullOrBlank()) {
                    emit(null)
                    return@flow
                }

                val modelStatus = voiceModelRepository.getModelStatus(authToken)
                if (modelStatus.success && modelStatus.data != null) {
                    emit(modelStatus.data.lastUpdate)
                } else {
                    emit(null)
                }
            } catch (e: Exception) {
                Timber.w(e, "Error getting last training time")
                emit(null)
            }
        }

    /**
     * Actualizar el estado de la UI
     */
    private fun updateState(newState: SettingsUiState) {
        _uiState.value = newState
    }
}