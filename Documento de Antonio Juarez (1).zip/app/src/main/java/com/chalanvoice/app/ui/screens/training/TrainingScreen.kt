package com.chalanvoice.app.ui.screens.training

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.chalanvoice.app.R
import com.chalanvoice.app.ui.components.LoadingIndicator
import com.chalanvoice.app.ui.components.EmptyState

/**
 * Pantalla de entrenamiento del modelo de voz.
 * Muestra el progreso de subida del audio y entrenamiento del modelo.
 */
@Composable
fun TrainingScreen(
    audioFilePath: String?,
    onTrainingComplete: () -> Unit,
    onNavigateBack: () -> Unit,
    viewModel: TrainingViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    // Inicializar ViewModel con el archivo de audio
    LaunchedEffect(audioFilePath) {
        viewModel.initialize(audioFilePath)
    }

    // Manejar finalización del entrenamiento
    LaunchedEffect(uiState.canProceed) {
        if (uiState.canProceed) {
            kotlinx.coroutines.delay(2000) // Dar tiempo para mostrar mensaje de éxito
            onTrainingComplete()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        if (uiState.isUploading || uiState.isTraining) {
            TrainingProgressContent(
                uiState = uiState,
                onDismissError = { viewModel.onEvent(TrainingUiEvent.DismissError) },
                onDismissSuccess = { viewModel.onEvent(TrainingUiEvent.DismissSuccess) }
            )
        } else {
            TrainingInitialContent(
                audioFilePath = audioFilePath,
                onStartTraining = { viewModel.onEvent(TrainingUiEvent.StartTraining) },
                onNavigateBack = onNavigateBack
            )
        }
    }
}

/**
 * Contenido inicial antes de comenzar el entrenamiento
 */
@Composable
private fun TrainingInitialContent(
    audioFilePath: String?,
    onStartTraining: () -> Unit,
    onNavigateBack: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onNavigateBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Volver")
            }
            
            Text(
                text = "Entrenar Modelo",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            
            Spacer(modifier = Modifier.width(48.dp))
        }

        Spacer(modifier = Modifier.height(32.dp))

        if (audioFilePath.isNullOrBlank()) {
            // Estado sin archivo
            EmptyState(
                title = "No hay archivo de audio",
                message = "Regresa a la pantalla de grabación para capturar tu voz."
            )
        } else {
            // Información del archivo y botón para comenzar
            TrainingPreparationContent(
                audioFilePath = audioFilePath,
                onStartTraining = onStartTraining
            )
        }
    }
}

/**
 * Contenido de preparación para el entrenamiento
 */
@Composable
private fun TrainingPreparationContent(
    audioFilePath: String,
    onStartTraining: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(24.dp)
    ) {
        // Icono de modelo de voz
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.primaryContainer,
            modifier = Modifier.size(120.dp)
        ) {
            Box(
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.ModelTraining,
                    contentDescription = "Entrenamiento",
                    modifier = Modifier.size(64.dp),
                    tint = MaterialTheme.colorScheme.onPrimaryContainer
                )
            }
        }

        Text(
            text = "Tu archivo de voz está listo",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.Center
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant
            )
        ) {
            Column(
                modifier = Modifier.padding(16.dp)
            ) {
                Text(
                    text = "Información del archivo",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Archivo:",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Text(
                        text = audioFilePath.substringAfterLast('/'),
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium
                    )
                }
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Estado:",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Text(
                        text = "Listo para entrenar",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        // Proceso de entrenamiento
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.secondaryContainer
            )
        ) {
            Column(
                modifier = Modifier.padding(16.dp)
            ) {
                Text(
                    text = "¿Qué sucederá a continuación?",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                
                val steps = listOf(
                    "Subiremos tu grabación al servidor de forma segura",
                    "Procesaremos el audio para extraer las características de tu voz",
                    "Entrenaremos un modelo personalizado con tu voz",
                    "El proceso tomará entre 2-5 minutos"
                )
                
                steps.forEachIndexed { index, step ->
                    Row(
                        verticalAlignment = Alignment.Top,
                        modifier = Modifier.padding(vertical = 2.dp)
                    ) {
                        Text(
                            text = "${index + 1}.",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                            modifier = Modifier.padding(end = 8.dp)
                        )
                        Text(
                            text = step,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = onStartTraining,
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.primary
            )
        ) {
            Icon(
                imageVector = Icons.Default.PlayArrow,
                contentDescription = null,
                modifier = Modifier.padding(end = 8.dp)
            )
            Text(
                text = "Comenzar Entrenamiento",
                style = MaterialTheme.typography.labelLarge
            )
        }
    }
}

/**
 * Contenido durante el progreso del entrenamiento
 */
@Composable
private fun TrainingProgressContent(
    uiState: TrainingUiState,
    onDismissError: () -> Unit,
    onDismissSuccess: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(32.dp))

        // Estado del entrenamiento
        TrainingStatusCard(
            uiState = uiState
        )

        Spacer(modifier = Modifier.height(32.dp))

        // Indicador de progreso
        if (uiState.isUploading) {
            UploadingProgressIndicator(
                progress = uiState.uploadProgress,
                currentStep = uiState.currentStep
            )
        } else if (uiState.isTraining) {
            TrainingProgressIndicator(
                progress = uiState.trainingProgress,
                currentStep = uiState.currentStep
            )
        }

        Spacer(modifier = Modifier.weight(1f))

        // Mensaje de éxito
        if (uiState.successMessage != null) {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.tertiaryContainer
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onTertiaryContainer,
                        modifier = Modifier.padding(end = 12.dp)
                    )
                    Text(
                        text = uiState.successMessage,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onTertiaryContainer
                    )
                }
            }
        }
    }

    // Mostrar error
    if (uiState.errorMessage != null) {
        AlertDialog(
            onDismissRequest = onDismissError,
            title = { Text("Error en el entrenamiento") },
            text = { Text(uiState.errorMessage) },
            confirmButton = {
                TextButton(onClick = onDismissError) {
                    Text("Entendido")
                }
            }
        )
    }
}

/**
 * Tarjeta de estado del entrenamiento
 */
@Composable
private fun TrainingStatusCard(
    uiState: TrainingUiState
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = when (uiState.currentStep) {
                TrainingStep.COMPLETED -> MaterialTheme.colorScheme.tertiaryContainer
                else -> MaterialTheme.colorScheme.primaryContainer
            }
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            when (uiState.currentStep) {
                TrainingStep.UPLOADING -> {
                    LoadingIndicator(
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Subiendo audio al servidor...",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
                TrainingStep.PROCESSING -> {
                    CircularProgressIndicator(
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Procesando audio...",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
                TrainingStep.TRAINING -> {
                    CircularProgressIndicator(
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Entrenando modelo personalizado...",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
                TrainingStep.COMPLETED -> {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onTertiaryContainer,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "¡Entrenamiento completado!",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onTertiaryContainer
                    )
                }
            }
        }
    }
}

/**
 * Indicador de progreso de subida
 */
@Composable
private fun UploadingProgressIndicator(
    progress: Float,
    currentStep: TrainingStep
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Paso 1 de 3: Subida de Audio",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold
        )
        
        Spacer(modifier = Modifier.height(16.dp))
        
        LinearProgressIndicator(
            progress = progress,
            modifier = Modifier.fillMaxWidth()
        )
        
        Spacer(modifier = Modifier.height(8.dp))
        
        Text(
            text = "${(progress * 100).toInt()}% completado",
            style = MaterialTheme.typography.bodyMedium
        )
    }
}

/**
 * Indicador de progreso de entrenamiento
 */
@Composable
private fun TrainingProgressIndicator(
    progress: Float,
    currentStep: TrainingStep
) {
    val isTrainingPhase = progress > 0.3f
    
    Column(
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = if (isTrainingPhase) {
                "Paso 3 de 3: Entrenamiento del Modelo"
            } else {
                "Paso 2 de 3: Procesamiento de Audio"
            },
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold
        )
        
        Spacer(modifier = Modifier.height(16.dp))
        
        LinearProgressIndicator(
            progress = progress,
            modifier = Modifier.fillMaxWidth()
        )
        
        Spacer(modifier = Modifier.height(8.dp))
        
        Text(
            text = "${(progress * 100).toInt()}% completado",
            style = MaterialTheme.typography.bodyMedium
        )
        
        if (isTrainingPhase) {
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "⏱️ Este proceso puede tomar varios minutos",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}