package com.chalanvoice.app.ui.screens.training

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.chalanvoice.app.domain.model.LoadingState
import com.chalanvoice.app.domain.model.ApiResponse
import com.chalanvoice.app.domain.repository.AuthRepository
import com.chalanvoice.app.domain.repository.VoiceModelRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import timber.log.Timber
import java.io.File
import javax.inject.Inject

/**
 * Estado de la UI para la pantalla de entrenamiento
 */
data class TrainingUiState(
    val audioFilePath: String? = null,
    val isUploading: Boolean = false,
    val isTraining: Boolean = false,
    val uploadProgress: Float = 0f,
    val trainingProgress: Float = 0f,
    val currentStep: TrainingStep = TrainingStep.UPLOADING,
    val errorMessage: String? = null,
    val successMessage: String? = null,
    val canProceed: Boolean = false
)

/**
 * Pasos del proceso de entrenamiento
 */
enum class TrainingStep(val displayName: String) {
    UPLOADING("Subiendo audio"),
    PROCESSING("Procesando audio"),
    TRAINING("Entrenando modelo"),
    COMPLETED("Entrenamiento completado")
}

/**
 * Eventos de la UI para la pantalla de entrenamiento
 */
sealed class TrainingUiEvent {
    data object StartTraining : TrainingUiEvent()
    data object DismissError : TrainingUiEvent()
    data object DismissSuccess : TrainingUiEvent()
    data object RetryTraining : TrainingUiEvent()
}

/**
 * ViewModel para manejar el proceso de entrenamiento del modelo de voz
 */
@HiltViewModel
class TrainingViewModel @Inject constructor(
    private val voiceModelRepository: VoiceModelRepository,
    private val authRepository: AuthRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(TrainingUiState())
    val uiState: StateFlow<TrainingUiState> = _uiState.asStateFlow()

    /**
     * Inicializar con el archivo de audio
     */
    fun initialize(audioFilePath: String?) {
        updateState(_uiState.value.copy(
            audioFilePath = audioFilePath
        ))
    }

    fun onEvent(event: TrainingUiEvent) {
        when (event) {
            is TrainingUiEvent.StartTraining -> {
                startTraining()
            }
            is TrainingUiEvent.DismissError -> {
                updateState(_uiState.value.copy(errorMessage = null))
            }
            is TrainingUiEvent.DismissSuccess -> {
                updateState(_uiState.value.copy(successMessage = null))
            }
            is TrainingUiEvent.RetryTraining -> {
                startTraining()
            }
        }
    }

    /**
     * Iniciar el proceso de entrenamiento
     */
    private fun startTraining() {
        val currentState = _uiState.value
        
        if (currentState.audioFilePath.isNullOrBlank()) {
            updateState(currentState.copy(
                errorMessage = "No se encontró el archivo de audio para entrenar."
            ))
            return
        }

        val audioFile = File(currentState.audioFilePath)
        if (!audioFile.exists()) {
            updateState(currentState.copy(
                errorMessage = "El archivo de audio no existe o no es accesible."
            ))
            return
        }

        viewModelScope.launch {
            updateState(currentState.copy(
                isUploading = true,
                uploadProgress = 0f,
                trainingProgress = 0f,
                currentStep = TrainingStep.UPLOADING,
                errorMessage = null,
                successMessage = null,
                canProceed = false
            ))

            try {
                // Paso 1: Subir audio al servidor
                uploadAudioToServer(audioFile)
                
                // Paso 2: Iniciar entrenamiento
                startModelTraining()
                
                // Paso 3: Monitorear progreso
                monitorTrainingProgress()
                
            } catch (e: Exception) {
                Timber.e(e, "Error during training process")
                updateState(currentState.copy(
                    isUploading = false,
                    isTraining = false,
                    errorMessage = "Error durante el entrenamiento: ${e.message}"
                ))
            }
        }
    }

    /**
     * Subir audio al servidor
     */
    private suspend fun uploadAudioToServer(audioFile: File) {
        try {
            updateState(_uiState.value.copy(
                currentStep = TrainingStep.UPLOADING
            ))

            val authToken = authRepository.getCurrentAuthToken()
            if (authToken.isNullOrBlank()) {
                throw Exception("No hay token de autenticación disponible")
            }

            val uploadResponse = voiceModelRepository.uploadVoiceSample(
                audioFile = audioFile,
                authToken = authToken,
                onProgress = { progress ->
                    updateState(_uiState.value.copy(uploadProgress = progress))
                }
            )

            if (!uploadResponse.success) {
                throw Exception(uploadResponse.message ?: "Error al subir el audio")
            }

            Timber.d("Audio uploaded successfully")

        } catch (e: Exception) {
            Timber.e(e, "Error uploading audio")
            throw e
        }
    }

    /**
     * Iniciar entrenamiento del modelo
     */
    private suspend fun startModelTraining() {
        try {
            updateState(_uiState.value.copy(
                currentStep = TrainingStep.PROCESSING
            ))

            val authToken = authRepository.getCurrentAuthToken()
            if (authToken.isNullOrBlank()) {
                throw Exception("No hay token de autenticación disponible")
            }

            val trainingResponse = voiceModelRepository.startModelTraining(
                authToken = authToken
            )

            if (!trainingResponse.success) {
                throw Exception(trainingResponse.message ?: "Error al iniciar el entrenamiento")
            }

            updateState(_uiState.value.copy(
                isUploading = false,
                isTraining = true,
                currentStep = TrainingStep.TRAINING,
                uploadProgress = 1f
            ))

            Timber.d("Model training started successfully")

        } catch (e: Exception) {
            Timber.e(e, "Error starting training")
            throw e
        }
    }

    /**
     * Monitorear el progreso del entrenamiento
     */
    private suspend fun monitorTrainingProgress() {
        val authToken = authRepository.getCurrentAuthToken()
        if (authToken.isNullOrBlank()) return

        try {
            // Simular progreso del entrenamiento (en una app real, esto vendría del servidor)
            var progress = 0f
            while (progress < 1f) {
                kotlinx.coroutines.delay(1000) // Actualizar cada segundo
                progress += 0.1f // Simular progreso incremental
                
                // Determinar el paso basado en el progreso
                val currentStep = when {
                    progress < 0.3f -> TrainingStep.PROCESSING
                    progress < 0.8f -> TrainingStep.TRAINING
                    else -> TrainingStep.COMPLETED
                }

                updateState(_uiState.value.copy(
                    trainingProgress = progress.coerceAtMost(1f),
                    currentStep = currentStep
                ))

                // Verificar si el entrenamiento ha terminado
                if (progress >= 1f) {
                    onTrainingCompleted()
                    break
                }
            }
        } catch (e: Exception) {
            Timber.e(e, "Error monitoring training progress")
            throw e
        }
    }

    /**
     * Manejar la finalización del entrenamiento
     */
    private suspend fun onTrainingCompleted() {
        try {
            val authToken = authRepository.getCurrentAuthToken()
            if (authToken.isNullOrBlank()) return

            // Verificar que el modelo esté listo
            val modelStatus = voiceModelRepository.getModelStatus(authToken)
            
            updateState(_uiState.value.copy(
                isTraining = false,
                trainingProgress = 1f,
                currentStep = TrainingStep.COMPLETED,
                successMessage = "¡Modelo de voz entrenado exitosamente! Ahora puedes generar audio con tu voz.",
                canProceed = true
            ))

            Timber.d("Training completed successfully")

        } catch (e: Exception) {
            Timber.e(e, "Error completing training")
            updateState(_uiState.value.copy(
                isTraining = false,
                errorMessage = "Error al verificar el estado del modelo: ${e.message}"
            ))
        }
    }

    /**
     * Actualizar el estado de la UI
     */
    private fun updateState(newState: TrainingUiState) {
        _uiState.value = newState
    }

    override fun onCleared() {
        super.onCleared()
        // Limpiar cualquier recurso si es necesario
    }
}