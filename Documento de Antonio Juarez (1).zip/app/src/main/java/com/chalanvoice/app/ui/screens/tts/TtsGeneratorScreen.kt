package com.chalanvoice.app.ui.screens.tts

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.chalanvoice.app.R
import com.chalanvoice.app.domain.model.TtsEmotion
import com.chalanvoice.app.ui.components.LoadingButton

/**
 * Pantalla de generación de TTS.
 * Permite al usuario convertir texto a voz usando su modelo personalizado.
 */
@Composable
fun TtsGeneratorScreen(
    onAudioGenerated: (String) -> Unit,
    onNavigateBack: () -> Unit,
    viewModel: TtsGeneratorViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    // Manejar generación exitosa de audio
    LaunchedEffect(uiState.generatedAudioUrl) {
        uiState.generatedAudioUrl?.let { audioUrl ->
            kotlinx.coroutines.delay(1000) // Dar tiempo para mostrar mensaje de éxito
            onAudioGenerated(audioUrl)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        TtsGeneratorContent(
            uiState = uiState,
            onEvent = viewModel::onEvent,
            onNavigateBack = onNavigateBack
        )

        // Mostrar errores
        if (uiState.errorMessage != null) {
            AlertDialog(
                onDismissRequest = { viewModel.onEvent(TtsGeneratorUiEvent.DismissError) },
                title = { Text("Error al generar TTS") },
                text = { Text(uiState.errorMessage) },
                confirmButton = {
                    TextButton(
                        onClick = { viewModel.onEvent(TtsGeneratorUiEvent.DismissError) }
                    ) {
                        Text("Entendido")
                    }
                }
            )
        }

        // Mostrar éxito
        if (uiState.successMessage != null) {
            AlertDialog(
                onDismissRequest = { viewModel.onEvent(TtsGeneratorUiEvent.DismissSuccess) },
                title = { Text("¡Éxito!") },
                text = { Text(uiState.successMessage) },
                confirmButton = {
                    TextButton(
                        onClick = { 
                            viewModel.onEvent(TtsGeneratorUiEvent.DismissSuccess)
                            viewModel.onEvent(TtsGeneratorUiEvent.ClearGeneratedAudio)
                        }
                    ) {
                        Text("Continuar")
                    }
                }
            )
        }
    }
}

/**
 * Contenido principal de la pantalla de generación TTS
 */
@Composable
private fun TtsGeneratorContent(
    uiState: TtsGeneratorUiState,
    onEvent: (TtsGeneratorUiEvent) -> Unit,
    onNavigateBack: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize()
    ) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onNavigateBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Volver")
            }
            
            Text(
                text = "Generar TTS",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            
            Spacer(modifier = Modifier.width(48.dp))
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Campo de texto
            item {
                TextInputSection(
                    textInput = uiState.textInput,
                    onTextChange = { onEvent(TtsGeneratorUiEvent.UpdateTextInput(it)) },
                    characterCount = uiState.textInput.length,
                    maxCharacters = 1000
                )
            }

            // Selector de emoción
            item {
                EmotionSelector(
                    selectedEmotion = uiState.selectedEmotion,
                    availableEmotions = uiState.availableEmotions,
                    onEmotionSelected = { onEvent(TtsGeneratorUiEvent.SelectEmotion(it)) }
                )
            }

            // Vista previa del texto
            if (uiState.textInput.isNotBlank()) {
                item {
                    TextPreviewSection(
                        text = uiState.textInput
                    )
                }
            }

            // Indicador de progreso
            if (uiState.isGenerating) {
                item {
                    GenerationProgressSection(
                        progress = uiState.generationProgress
                    )
                }
            }

            // Botón de generar
            item {
                GenerateButton(
                    isGenerating = uiState.isGenerating,
                    isEnabled = viewModel.isTextValid(),
                    onGenerateClick = { onEvent(TtsGeneratorUiEvent.GenerateTts) }
                )
            }

            // Información adicional
            item {
                AdditionalInfoSection()
            }
        }
    }
}

/**
 * Sección del campo de texto
 */
@Composable
private fun TextInputSection(
    textInput: String,
    onTextChange: (String) -> Unit,
    characterCount: Int,
    maxCharacters: Int
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Text(
                text = "Texto a convertir",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            
            OutlinedTextField(
                value = textInput,
                onValueChange = onTextChange,
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Escribe aquí el texto que deseas convertir a voz...") },
                minLines = 4,
                maxLines = 6,
                textStyle = MaterialTheme.typography.bodyLarge
            )
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "$characterCount / $maxCharacters",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (characterCount > maxCharacters * 0.9) {
                        MaterialTheme.colorScheme.error
                    } else {
                        MaterialTheme.colorScheme.onSurfaceVariant
                    }
                )
                
                if (characterCount > maxCharacters * 0.8) {
                    Text(
                        text = "Límite próximo",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }
            }
        }
    }
}

/**
 * Selector de emoción
 */
@Composable
private fun EmotionSelector(
    selectedEmotion: TtsEmotion,
    availableEmotions: List<TtsEmotion>,
    onEmotionSelected: (TtsEmotion) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.secondaryContainer
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Text(
                text = "Emoción de la voz",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSecondaryContainer,
                modifier = Modifier.padding(bottom = 12.dp)
            )
            
            Text(
                text = "Selecciona cómo quieres que suene tu voz",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSecondaryContainer,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            // Grid de emociones (usando LazyColumn con arrangement para simplicidad)
            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                availableEmotions.chunked(3).forEach { emotionRow ->
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        emotionRow.forEach { emotion ->
                            EmotionChip(
                                emotion = emotion,
                                isSelected = emotion == selectedEmotion,
                                onSelected = { onEmotionSelected(emotion) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                        // Rellenar espacios vacíos en la última fila
                        repeat(3 - emotionRow.size) {
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
        }
    }
}

/**
 * Chip de emoción individual
 */
@Composable
private fun EmotionChip(
    emotion: TtsEmotion,
    isSelected: Boolean,
    onSelected: () -> Unit,
    modifier: Modifier = Modifier
) {
    val backgroundColor = if (isSelected) {
        MaterialTheme.colorScheme.primary
    } else {
        MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.1f)
    }
    
    val textColor = if (isSelected) {
        MaterialTheme.colorScheme.onPrimary
    } else {
        MaterialTheme.colorScheme.onSecondaryContainer
    }

    Surface(
        onClick = onSelected,
        shape = RoundedCornerShape(20.dp),
        color = backgroundColor,
        modifier = modifier.clip(RoundedCornerShape(20.dp))
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = emotion.displayName,
                style = MaterialTheme.typography.labelMedium,
                color = textColor,
                textAlign = TextAlign.Center
            )
        }
    }
}

/**
 * Sección de vista previa del texto
 */
@Composable
private fun TextPreviewSection(
    text: String
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.tertiaryContainer
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Text(
                text = "Vista previa",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onTertiaryContainer,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            
            Text(
                text = if (text.length > 150) {
                    "${text.take(150)}..."
                } else {
                    text
                },
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onTertiaryContainer
            )
        }
    }
}

/**
 * Sección de progreso de generación
 */
@Composable
private fun GenerationProgressSection(
    progress: Float
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            CircularProgressIndicator(
                progress = progress,
                modifier = Modifier.size(48.dp),
                color = MaterialTheme.colorScheme.onPrimaryContainer
            )
            
            Spacer(modifier = Modifier.height(12.dp))
            
            Text(
                text = "Generando audio...",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onPrimaryContainer
            )
            
            Text(
                text = "${(progress * 100).toInt()}% completado",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onPrimaryContainer
            )
        }
    }
}

/**
 * Botón de generar
 */
@Composable
private fun GenerateButton(
    isGenerating: Boolean,
    isEnabled: Boolean,
    onGenerateClick: () -> Unit
) {
    LoadingButton(
        text = if (isGenerating) "Generando..." else "Generar Audio",
        isLoading = isGenerating,
        enabled = isEnabled,
        onClick = onGenerateClick,
        modifier = Modifier
            .fillMaxWidth()
            .height(48.dp)
    )
}

/**
 * Sección de información adicional
 */
@Composable
private fun AdditionalInfoSection() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Text(
                text = "Consejos para mejores resultados",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            
            val tips = listOf(
                "• Usa puntuación adecuada para pausas naturales",
                "• Evita textos demasiado largos",
                "• Prueba diferentes emociones según el contexto",
                "• Tu modelo aprende de las grabaciones previas"
            )
            
            tips.forEach { tip ->
                Text(
                    text = tip,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(vertical = 2.dp)
                )
            }
        }
    }
}