package com.chalanvoice.app.ui.screens.tts

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.chalanvoice.app.domain.model.LoadingState
import com.chalanvoice.app.domain.model.ApiResponse
import com.chalanvoice.app.domain.model.TtsEmotion
import com.chalanvoice.app.domain.repository.AuthRepository
import com.chalanvoice.app.domain.repository.VoiceModelRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import timber.log.Timber
import javax.inject.Inject

/**
 * Estado de la UI para la pantalla de generación TTS
 */
data class TtsGeneratorUiState(
    val textInput: String = "",
    val selectedEmotion: TtsEmotion = TtsEmotion.NEUTRAL,
    val isGenerating: Boolean = false,
    val generatedAudioUrl: String? = null,
    val generationProgress: Float = 0f,
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
    val successMessage: String? = null,
    val availableEmotions: List<TtsEmotion> = TtsEmotion.values().toList()
)

/**
 * Eventos de la UI para la pantalla de generación TTS
 */
sealed class TtsGeneratorUiEvent {
    data class UpdateTextInput(val text: String) : TtsGeneratorUiEvent()
    data class SelectEmotion(val emotion: TtsEmotion) : TtsGeneratorUiEvent()
    data object GenerateTts : TtsGeneratorUiEvent()
    data object DismissError : TtsGeneratorUiEvent()
    data object DismissSuccess : TtsGeneratorUiEvent()
    data object ClearGeneratedAudio : TtsGeneratorUiEvent()
}

/**
 * ViewModel para manejar la generación de TTS
 */
@HiltViewModel
class TtsGeneratorViewModel @Inject constructor(
    private val voiceModelRepository: VoiceModelRepository,
    private val authRepository: AuthRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(TtsGeneratorUiState())
    val uiState: StateFlow<TtsGeneratorUiState> = _uiState.asStateFlow()

    fun onEvent(event: TtsGeneratorUiEvent) {
        when (event) {
            is TtsGeneratorUiEvent.UpdateTextInput -> {
                updateState(_uiState.value.copy(
                    textInput = event.text,
                    errorMessage = null
                ))
            }
            is TtsGeneratorUiEvent.SelectEmotion -> {
                updateState(_uiState.value.copy(
                    selectedEmotion = event.emotion,
                    errorMessage = null
                ))
            }
            is TtsGeneratorUiEvent.GenerateTts -> {
                generateTts()
            }
            is TtsGeneratorUiEvent.DismissError -> {
                updateState(_uiState.value.copy(errorMessage = null))
            }
            is TtsGeneratorUiEvent.DismissSuccess -> {
                updateState(_uiState.value.copy(successMessage = null))
            }
            is TtsGeneratorUiEvent.ClearGeneratedAudio -> {
                updateState(_uiState.value.copy(
                    generatedAudioUrl = null,
                    generationProgress = 0f
                ))
            }
        }
    }

    /**
     * Generar audio TTS con el texto y emoción seleccionados
     */
    private fun generateTts() {
        val currentState = _uiState.value

        // Validaciones
        if (currentState.textInput.trim().isEmpty()) {
            updateState(currentState.copy(
                errorMessage = "Por favor ingresa el texto que deseas convertir a voz"
            ))
            return
        }

        if (currentState.textInput.length > 1000) {
            updateState(currentState.copy(
                errorMessage = "El texto debe tener máximo 1000 caracteres"
            ))
            return
        }

        val authToken = authRepository.getCurrentAuthToken()
        if (authToken.isNullOrBlank()) {
            updateState(currentState.copy(
                errorMessage = "Debes estar autenticado para generar TTS"
            ))
            return
        }

        viewModelScope.launch {
            updateState(currentState.copy(
                isGenerating = true,
                generationProgress = 0f,
                errorMessage = null,
                successMessage = null,
                generatedAudioUrl = null
            ))

            try {
                // Simular progreso de generación
                simulateGenerationProgress()

                val response = voiceModelRepository.generateTts(
                    text = currentState.textInput.trim(),
                    emotion = currentState.selectedEmotion.value,
                    authToken = authToken
                )

                if (response.success && !response.data.isNullOrBlank()) {
                    updateState(currentState.copy(
                        isGenerating = false,
                        generationProgress = 1f,
                        generatedAudioUrl = response.data,
                        successMessage = "¡Audio generado exitosamente! Ahora puedes reproducirlo."
                    ))
                    Timber.d("TTS generated successfully: ${response.data}")
                } else {
                    throw Exception(response.message ?: "Error al generar el audio")
                }

            } catch (e: Exception) {
                Timber.e(e, "Error generating TTS")
                updateState(currentState.copy(
                    isGenerating = false,
                    generationProgress = 0f,
                    errorMessage = "Error al generar el audio: ${e.message}"
                ))
            }
        }
    }

    /**
     * Simular progreso de generación de audio
     */
    private suspend fun simulateGenerationProgress() {
        val currentState = _uiState.value
        var progress = 0f

        while (progress < 0.9f) {
            kotlinx.coroutines.delay(500)
            progress += 0.1f + kotlin.random.Random.nextFloat() * 0.1f
            updateState(currentState.copy(generationProgress = progress.coerceAtMost(0.9f)))
        }
    }

    /**
     * Obtener vista previa del texto (primeras líneas)
     */
    fun getTextPreview(): String {
        val text = _uiState.value.textInput
        return if (text.length > 100) {
            "${text.take(100)}..."
        } else {
            text
        }
    }

    /**
     * Verificar si el texto es válido para generar
     */
    fun isTextValid(): Boolean {
        val text = _uiState.value.textInput.trim()
        return text.isNotEmpty() && text.length <= 1000 && !_uiState.value.isGenerating
    }

    /**
     * Actualizar el estado de la UI
     */
    private fun updateState(newState: TtsGeneratorUiState) {
        _uiState.value = newState
    }
}