package com.chalanvoice.app.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

// Esquema de colores Material 3 personalizado para Chalan Voice
private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFF6B46C1), // Púrpura principal
    onPrimary = Color.White,
    primaryContainer = Color(0xFF4C1D95),
    onPrimaryContainer = Color(0xFFE9D5FF),
    secondary = Color(0xFF0891B2), // Cian secundario
    onSecondary = Color.White,
    secondaryContainer = Color(0xFF164E63),
    onSecondaryContainer = Color(0xFFBAE6FD),
    tertiary = Color(0xFFEC4899), // Rosa terciario
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFF9F1239),
    onTertiaryContainer = Color(0xFFFECDD3),
    error = Color(0xFFEF4444),
    onError = Color.White,
    errorContainer = Color(0xFF7F1D1D),
    onErrorContainer = Color(0xFFFEF2F2),
    background = Color(0xFF0F0F23), // Azul oscuro profundo
    onBackground = Color(0xFFE4E4E7),
    surface = Color(0xFF1E1B4B), // Índigo oscuro
    onSurface = Color(0xFFE4E4E7),
    surfaceVariant = Color(0xFF312E81),
    onSurfaceVariant = Color(0xFFCAC4D0),
    outline = Color(0xFF938F99),
    outlineVariant = Color(0xFF4A4458),
    surfaceContainerHigh = Color(0xFF2D2A5A),
    surfaceContainerHighest = Color(0xFF26253F)
)

private val LightColorScheme = lightColorScheme(
    primary = Color(0xFF8B5CF6), // Púrpura claro
    onPrimary = Color.White,
    primaryContainer = Color(0xFFF3E8FF),
    onPrimaryContainer = Color(0xFF5B21B6),
    secondary = Color(0xFF06B6D4), // Cian claro
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFCFFAFE),
    onSecondaryContainer = Color(0xFF0C4A6E),
    tertiary = Color(0xFFEC4899), // Rosa
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFFFDF2F8),
    onTertiaryContainer = Color(0xFFBE185D),
    error = Color(0xFFDC2626),
    onError = Color.White,
    errorContainer = Color(0xFFFEF2F2),
    onErrorContainer = Color(0xFF7F1D1D),
    background = Color(0xFFFAFAFA),
    onBackground = Color(0xFF1C1C1C),
    surface = Color.White,
    onSurface = Color(0xFF1C1C1C),
    surfaceVariant = Color(0xFFF5F5F5),
    onSurfaceVariant = Color(0xFF666666),
    outline = Color(0xFF999999),
    outlineVariant = Color(0xFFE0E0E0),
    surfaceContainerHigh = Color(0xFFF9F9F9),
    surfaceContainerHighest = Color(0xFFEEEEEE)
)

/**
 * Tema principal de la aplicación Chalan Voice.
 * Utiliza Material 3 con soporte para modo oscuro y colores personalizados.
 */
@Composable
fun ChalanVoiceTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        // Usar colores dinámicos en Android 12+ si está habilitado
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }

        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colorScheme.primary.toArgb()
            window.navigationBarColor = colorScheme.surfaceContainerHighest.toArgb()
            
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
            WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = !darkTheme
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}