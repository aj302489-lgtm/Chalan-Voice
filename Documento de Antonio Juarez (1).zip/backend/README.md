# 🔧 Chalan Voice - Backend Documentation

## 📋 Índice

1. [Arquitectura del Sistema](#arquitectura-del-sistema)
2. [Instalación y Configuración](#instalación-y-configuración)
3. [Despliegue](#despliegue)
4. [API Reference](#api-reference)
5. [Modelos de IA](#modelos-de-ia)
6. [Watermarking](#watermarking)
7. [Base de Datos](#base-de-datos)
8. [Seguridad](#seguridad)
9. [Monitoreo](#monitoreo)
10. [Troubleshooting](#troubleshooting)

## 🏗️ Arquitectura del Sistema

### Estructura del Proyecto

```
backend/
├── main.py                     # Punto de entrada principal
├── app/                        # Aplicación principal
│   ├── core/                   # Configuración y utilidades base
│   │   ├── auth.py            # Autenticación JWT
│   │   ├── config.py          # Configuración centralizada
│   │   └── database.py        # Conexión y operaciones DB
│   ├── routers/               # Endpoints de la API
│   │   ├── auth.py            # Endpoints de autenticación
│   │   ├── voice.py           # Endpoints de voz
│   │   ├── training.py        # Endpoints de entrenamiento
│   │   └── models.py          # Endpoints de modelos
│   ├── services/              # Lógica de negocio
│   │   ├── audio_processor.py # Procesamiento con IA
│   │   └── watermark.py       # Watermarking acústico
│   └── schemas/               # Modelos Pydantic
│       └── models.py          # Esquemas de datos
├── uploads/                   # Archivos subidos por usuarios
├── generated/                 # Audio generado
├── models/                    # Modelos personalizados
├── logs/                      # Logs del sistema
├── requirements.txt           # Dependencias Python
├── Dockerfile                 # Imagen Docker
└── docker-compose.yml         # Orquestación Docker
```

### Componentes Principales

#### 1. FastAPI Application (`main.py`)
- **Framework**: FastAPI 0.104.1
- **Puerto**: 8000
- **CORS**: Habilitado para Android
- **Lifespan**: Gestión del ciclo de vida
- **Middleware**: Logging, CORS, autenticación

#### 2. Audio Processor (`app/services/audio_processor.py`)
- **XTTSv2**: Clonación multilingüe
- **Bark**: Síntesis expresiva
- **Tortoise-TTS**: Alta calidad
- **Dispositivo**: Auto-detección GPU/CPU

#### 3. Audio Watermarker (`app/services/watermark.py`)
- **Tecnología**: VoiceMark-based
- **Inserción**: Dominio de frecuencia
- **Robustez**: Resistente a transformaciones
- **Configurable**: Activación/desactivación

## 📦 Instalación y Configuración

### Desarrollo Local

#### 1. Prerequisitos

```bash
# Python 3.9+
python --version

# NVIDIA GPU (opcional pero recomendado)
nvidia-smi

# CUDA 11.8+ (para GPU)
nvcc --version
```

#### 2. Instalación

```bash
# Clonar repositorio
git clone https://github.com/tu-usuario/chalan-voice.git
cd chalan-voice/backend

# Crear entorno virtual
python -m venv venv
source venv/bin/activate  # Linux/Mac
# venv\Scripts\activate  # Windows

# Instalar dependencias
pip install -r requirements.txt

# Instalar PyTorch con CUDA (si tienes GPU)
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu118
```

#### 3. Configuración

```bash
# Copiar archivo de configuración
cp .env.example .env

# Editar configuración
nano .env
```

**Variables de entorno:**

```env
# Base
DEBUG=true
SECRET_KEY=tu-clave-secreta-desarrollo
WATERMARK_SECRET_KEY=clave-watermarking

# Base de datos
DATABASE_URL=sqlite:///./chalan_voice.db

# Configuración de audio
XTTS_MODEL_NAME=tts_models/multilingual/multi-dataset/xtts_v2
BARK_MODEL_NAME=suno/bark
MAX_UPLOAD_SIZE=52428800
MAX_AUDIO_DURATION=300
GPU_ENABLED=true

# CORS
ALLOWED_ORIGINS=http://localhost:3000,http://localhost:8080

# Logging
LOG_LEVEL=INFO
```

#### 4. Ejecutar

```bash
# Modo desarrollo con recarga automática
python main.py

# O con uvicorn directamente
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

La API estará disponible en:
- **Swagger UI**: http://localhost:8000/docs
- **ReDoc**: http://localhost:8000/redoc
- **API**: http://localhost:8000/api/v1/

## 🚢 Despliegue

### Docker (Recomendado)

#### 1. Configuración

```bash
# Variables de entorno para producción
cp .env.example .env.production
nano .env.production
```

**Configuración de producción:**

```env
# Seguridad
DEBUG=false
SECRET_KEY=clave-super-secreta-produccion-muy-larga-y-segura
WATERMARK_SECRET_KEY=clave-watermarking-produccion

# Base de datos (PostgreSQL recomendado)
DATABASE_URL=postgresql://chalan:password@db:5432/chalan_voice

# Configuración de audio
XTTS_MODEL_NAME=tts_models/multilingual/multi-dataset/xtts_v2
GPU_ENABLED=true
MAX_UPLOAD_SIZE=104857600
MAX_AUDIO_DURATION=600

# CORS (dominios específicos)
ALLOWED_ORIGINS=https://app.tu-dominio.com

# Logging
LOG_LEVEL=WARNING
```

#### 2. Despliegue

```bash
# Construir e iniciar servicios
docker-compose up -d

# Ver logs
docker-compose logs -f chalan-voice-api

# Verificar estado
curl http://localhost:8000/health
```

#### 3. Persistencia de Datos

```yaml
# docker-compose.yml
services:
  chalan-voice-api:
    volumes:
      - uploads_data:/app/uploads
      - generated_data:/app/generated
      - models_data:/app/models
      - logs_data:/app/logs

volumes:
  uploads_data:
  generated_data:
  models_data:
  logs_data:
```

### Cloud Platforms

#### AWS ECS

```bash
# 1. Construir imagen
docker build -t chalan-voice:latest .

# 2. Tag para ECR
aws ecr get-login-password --region us-east-1 | docker login --username AWS --password-stdin 123456789.dkr.ecr.us-east-1.amazonaws.com
docker tag chalan-voice:latest 123456789.dkr.ecr.us-east-1.amazonaws.com/chalan-voice:latest

# 3. Push a ECR
docker push 123456789.dkr.ecr.us-east-1.amazonaws.com/chalan-voice:latest
```

**Task Definition (task-definition.json):**

```json
{
  "family": "chalan-voice",
  "networkMode": "awsvpc",
  "requiresCompatibilities": ["FARGATE"],
  "cpu": "2048",
  "memory": "4096",
  "executionRoleArn": "arn:aws:iam::123456789:role/ecsTaskExecutionRole",
  "taskRoleArn": "arn:aws:iam::123456789:role/ecsTaskRole",
  "containerDefinitions": [
    {
      "name": "chalan-voice-api",
      "image": "123456789.dkr.ecr.us-east-1.amazonaws.com/chalan-voice:latest",
      "portMappings": [
        {
          "containerPort": 8000,
          "protocol": "tcp"
        }
      ],
      "environment": [
        {
          "name": "DEBUG",
          "value": "false"
        }
      ],
      "logConfiguration": {
        "logDriver": "awslogs",
        "options": {
          "awslogs-group": "/ecs/chalan-voice",
          "awslogs-region": "us-east-1",
          "awslogs-stream-prefix": "ecs"
        }
      }
    }
  ]
}
```

#### Google Cloud Run

```bash
# 1. Habilitar servicios
gcloud services enable run.googleapis.com
gcloud services enable cloudbuild.googleapis.com

# 2. Construir y desplegar
gcloud run deploy chalan-voice \
  --source . \
  --platform managed \
  --region us-central1 \
  --allow-unauthenticated \
  --memory 4Gi \
  --cpu 2 \
  --set-env-vars DEBUG=false,SECRET_KEY=tu-clave-secreta
```

#### Azure Container Instances

```bash
# 1. Crear grupo de recursos
az group create --name chalan-voice-rg --location eastus

# 2. Desplegar contenedor
az container create \
  --resource-group chalan-voice-rg \
  --name chalan-voice-api \
  --image 123456789.dkr.ecr.amazonaws.com/chalan-voice:latest \
  --cpu 2 \
  --memory 4 \
  --ports 8000 \
  --environment-variables DEBUG=false SECRET_KEY=tu-clave-secreta
```

## 🔌 API Reference

### Autenticación

#### Registro de Usuario
```http
POST /api/v1/auth/register
Content-Type: application/json

{
  "email": "usuario@example.com",
  "password": "secure_password",
  "name": "Usuario Prueba"
}
```

**Respuesta:**
```json
{
  "id": "uuid",
  "email": "usuario@example.com",
  "name": "Usuario Prueba",
  "created_at": "2025-01-01T00:00:00Z"
}
```

#### Inicio de Sesión
```http
POST /api/v1/auth/login
Content-Type: application/json

{
  "email": "usuario@example.com",
  "password": "secure_password"
}
```

**Respuesta:**
```json
{
  "access_token": "eyJhbGciOiJIUzI1NiIs...",
  "token_type": "bearer",
  "expires_in": 3600
}
```

#### Obtener Usuario Actual
```http
GET /api/v1/auth/me
Authorization: Bearer {token}
```

### Subida de Voz

#### Subir Muestra de Voz
```http
POST /api/v1/voice/upload-voice
Authorization: Bearer {token}
Content-Type: multipart/form-data

file: [archivo audio]
emotion: "neutral"  # optional: neutral, happy, sad, angry, etc.
```

**Respuesta:**
```json
{
  "id": "voice_sample_id",
  "filename": "muestra_voz.wav",
  "duration": 5.2,
  "format": "wav",
  "upload_time": "2025-01-01T00:00:00Z"
}
```

### Generación de Audio

#### Generar Síntesis de Voz
```http
POST /api/v1/voice/generate
Authorization: Bearer {token}
Content-Type: application/json

{
  "text": "Hola, este es mi texto sintetizado",
  "voice_sample_id": "voice_sample_id",
  "emotion": "happy",
  "language": "es"
}
```

**Respuesta:**
```json
{
  "id": "generation_id",
  "status": "processing",
  "estimated_time": 30,
  "file_path": "generated/audio/generation_id.wav"
}
```

#### Obtener Estado de Generación
```http
GET /api/v1/voice/status/{generation_id}
Authorization: Bearer {token}
```

#### Descargar Audio Generado
```http
GET /api/v1/voice/download/{generation_id}
Authorization: Bearer {token}
```

**Respuesta:** Archivo de audio (WAV/MP3)

### Entrenamiento

#### Iniciar Entrenamiento
```http
POST /api/v1/training/train
Authorization: Bearer {token}
Content-Type: application/json

{
  "voice_sample_ids": ["id1", "id2", "id3"],
  "model_name": "Mi_Voz_Personalizada",
  "language": "es"
}
```

#### Listar Modelos del Usuario
```http
GET /api/v1/training/models
Authorization: Bearer {token}
```

### Modelos

#### Obtener Modelos del Usuario
```http
GET /api/v1/models/{userId}
Authorization: Bearer {token}
```

#### Estado de Modelos
```http
GET /api/v1/models/status/{userId}
Authorization: Bearer {token}
```

### Sistema

#### Health Check
```http
GET /health
```

**Respuesta:**
```json
{
  "status": "healthy",
  "timestamp": "2025-01-01T00:00:00Z",
  "services": {
    "ai_models": "active",
    "watermarking": "active",
    "database": "active"
  }
}
```

#### Información de la API
```http
GET /api/v1/info
```

## 🤖 Modelos de IA

### XTTSv2

**Características:**
- Clonación zero-shot multilingüe
- 17 idiomas soportados
- Transferencia de emociones
- Calidad de audio profesional

**Configuración:**
```python
# app/core/config.py
XTTS_MODEL_NAME = "tts_models/multilingual/multi-dataset/xtts_v2"
```

**Uso:**
```python
from TTS.api import TTS

# Cargar modelo
tts = TTS("tts_models/multilingual/multi-dataset/xtts_v2")

# Generar audio
tts.tts_to_file(
    text="Hola, esto es una prueba",
    speaker_wav="muestra_voz.wav",
    file_path="output.wav",
    language="es"
)
```

### Bark

**Características:**
- Síntesis expresiva
- +100 presets de voz
- Efectos de audio (risas, suspiros)
- Controles semánticos

**Configuración:**
```python
BARK_MODEL_NAME = "suno/bark"
```

**Uso:**
```python
from transformers import BarkModel, BarkProcessor

# Cargar modelo
processor = BarkProcessor.from_pretrained("suno/bark")
model = BarkModel.from_pretrained("suno/bark")

# Generar audio
inputs = processor(text=["Hola, ¿cómo estás?"], return_tensors="pt")
audio_array = model.generate(**inputs, semantic_prompt_advance=0.5)
```

### Tortoise-TTS

**Características:**
- Alta calidad de audio
- Control fino de prosodia
- Ideal para contenido largo
- Personalización avanzada

**Instalación:**
```bash
pip install tortoise-tts
```

## 🔒 Watermarking

### Configuración

```python
# Habilitar/deshabilitar watermarking
WATERMARK_ENABLED = True

# Clave secreta para watermarking
WATERMARK_SECRET_KEY = "tu-clave-secreta-watermarking"
```

### Implementación

El watermarking se basa en técnicas de VoiceMark:

1. **Análisis de frecuencia** del audio original
2. **Inserción imperceptible** de marcadores
3. **Codificación de metadatos** (timestamp, user_id)
4. **Detección robusta** en contenido generado

### Uso

```python
from app.services.watermark import AudioWatermarker

# Inicializar watermarker
watermarker = await AudioWatermarker.initialize()

# Agregar watermark a audio generado
watermarked_audio = await watermarker.add_watermark(
    audio_path="generated_audio.wav",
    user_id="user_uuid",
    timestamp="2025-01-01T00:00:00Z"
)

# Detectar watermark en audio
watermark_info = await watermarker.detect_watermark(
    audio_path="audio_to_check.wav"
)
```

## 🗄️ Base de Datos

### Esquema Principal

```sql
-- Tabla de usuarios
CREATE TABLE users (
    id TEXT PRIMARY KEY,
    email TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE
);

-- Tabla de muestras de voz
CREATE TABLE voice_samples (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    filename TEXT NOT NULL,
    file_path TEXT NOT NULL,
    duration REAL NOT NULL,
    format TEXT NOT NULL,
    emotion TEXT,
    upload_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Tabla de generaciones
CREATE TABLE audio_generations (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    voice_sample_id TEXT NOT NULL,
    text TEXT NOT NULL,
    emotion TEXT,
    language TEXT,
    file_path TEXT NOT NULL,
    status TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (voice_sample_id) REFERENCES voice_samples(id)
);

-- Tabla de modelos entrenados
CREATE TABLE trained_models (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    name TEXT NOT NULL,
    model_path TEXT NOT NULL,
    language TEXT NOT NULL,
    status TEXT NOT NULL,
    training_time REAL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Tabla de logs del sistema
CREATE TABLE system_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT,
    action TEXT NOT NULL,
    details TEXT,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);
```

### Operaciones

```python
from app.core.database import execute_query

# Ejecutar query personalizada
result = await execute_query(
    "SELECT * FROM users WHERE email = ?",
    ("usuario@example.com",)
)

# Obtener estadísticas de usuario
stats = await execute_query(
    """
    SELECT 
        COUNT(*) as total_generations,
        AVG(duration) as avg_duration
    FROM audio_generations 
    WHERE user_id = ?
    """,
    (user_id,)
)
```

## 🔐 Seguridad

### Autenticación JWT

```python
from app.core.auth import create_access_token, verify_token

# Crear token
token = create_access_token(user_id="user_uuid")

# Verificar token
user_id = verify_token(token)
```

### Hashing de Contraseñas

```python
from passlib.context import CryptContext

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# Hash de contraseña
hash = pwd_context.hash("password")

# Verificar contraseña
is_valid = pwd_context.verify("password", hash)
```

### Validación de Archivos

```python
import magic

# Validar tipo de archivo
def validate_audio_file(file_path):
    mime_type = magic.from_file(file_path, mime=True)
    allowed_types = ['audio/wav', 'audio/mp3', 'audio/m4a']
    return mime_type in allowed_types

# Validar tamaño
def validate_file_size(file_path, max_size=50*1024*1024):
    return os.path.getsize(file_path) <= max_size
```

### Rate Limiting

```python
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded

limiter = Limiter(key_func=get_remote_address)
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

# Aplicar límite
@app.post("/api/v1/voice/generate")
@limiter.limit("10/minute")
async def generate_audio(request: Request, ...):
    ...
```

## 📊 Monitoreo

### Logging

```python
import logging

# Configurar logger
logger = logging.getLogger(__name__)
logger.info("Audio generado exitosamente", extra={
    "user_id": user_id,
    "generation_id": generation_id,
    "duration": audio_duration
})
```

### Métricas

```python
from prometheus_client import Counter, Histogram, Gauge

# Contadores
generation_counter = Counter(
    'audio_generations_total', 
    'Total de generaciones de audio'
)

# Histogramas
generation_duration = Histogram(
    'audio_generation_duration_seconds',
    'Tiempo de generación de audio'
)

# Gauges
active_users = Gauge('active_users', 'Usuarios activos')
```

### Health Checks

```python
@app.get("/health")
async def health_check():
    """Endpoint de health check para monitoreo"""
    
    health_status = {
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "services": {}
    }
    
    # Verificar base de datos
    try:
        await execute_query("SELECT 1")
        health_status["services"]["database"] = "healthy"
    except Exception as e:
        health_status["services"]["database"] = f"unhealthy: {str(e)}"
        health_status["status"] = "unhealthy"
    
    # Verificar modelos de IA
    try:
        if audio_processor and audio_processor.xtts_model:
            health_status["services"]["ai_models"] = "healthy"
        else:
            health_status["services"]["ai_models"] = "loading"
    except Exception as e:
        health_status["services"]["ai_models"] = f"unhealthy: {str(e)}"
    
    return health_status
```

## 🔧 Troubleshooting

### Problemas Comunes

#### 1. "No se puede cargar el modelo"

**Síntomas:**
```
ERROR: Failed to load model tts_models/multilingual/multi-dataset/xtts_v2
```

**Soluciones:**
```bash
# Verificar CUDA
python -c "import torch; print(torch.cuda.is_available())"

# Reinstalar PyTorch con CUDA
pip uninstall torch torchvision torchaudio
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu118

# Verificar espacio en disco
df -h

# Limpiar caché de modelos
rm -rf ~/.cache/torch/
```

#### 2. "Memoria insuficiente"

**Síntomas:**
```
RuntimeError: CUDA out of memory. Tried to allocate X GB
```

**Soluciones:**
```python
# app/core/config.py
# Reducir uso de memoria
GPU_MEMORY_FRACTION = 0.6
BATCH_SIZE = 1

# Usar modelo más pequeño
XTTS_MODEL_NAME = "tts_models/en/ljspeech/xtts_v2"
```

**Variables de entorno:**
```bash
export PYTORCH_CUDA_MEMORY_FRACTION=0.6
export CUDA_VISIBLE_DEVICES=0
```

#### 3. "Base de datos bloqueada"

**Síntomas:**
```
sqlite3.OperationalError: database is locked
```

**Soluciones:**
```bash
# Verificar procesos que usan la BD
lsof chalan_voice.db

# Cambiar a PostgreSQL para producción
DATABASE_URL=postgresql://user:pass@host:5432/db

# Verificar permisos
chmod 664 chalan_voice.db
chown app:app data/
```

#### 4. "Error de CORS"

**Síntomas:**
```
Access to fetch at 'http://localhost:8000/api/v1/...' 
from origin 'http://localhost:3000' has been blocked by CORS policy
```

**Solución:**
```python
# main.py - Configurar CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000",
        "http://localhost:8080",
        "https://tu-dominio.com"
    ],
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE"],
    allow_headers=["*"],
)
```

#### 5. "Watermarking falla"

**Síntomas:**
```
WARNING: Watermarking failed for audio file
```

**Solución:**
```python
# Verificar configuración
print(f"WATERMARK_ENABLED: {WATERMARK_ENABLED}")
print(f"WATERMARK_SECRET_KEY: {WATERMARK_SECRET_KEY[:8]}...")

# Deshabilitar temporalmente para debugging
WATERMARK_ENABLED = False

# Verificar dependencias
pip install librosa soundfile numpy
```

### Logs de Debug

```bash
# Ver logs en tiempo real
tail -f logs/chalan_voice.log

# Logs de Docker
docker-compose logs -f chalan-voice-api

# Logs con nivel de debug
LOG_LEVEL=DEBUG python main.py

# Verificar recursos del sistema
htop
nvidia-smi
```

### Optimización de Rendimiento

```python
# app/core/config.py - Optimizaciones
class Settings(BaseSettings):
    # GPU
    GPU_ENABLED: bool = True
    GPU_MEMORY_FRACTION: float = 0.8
    
    # Audio
    MAX_CONCURRENT_GENERATIONS: int = 2
    AUDIO_SAMPLE_RATE: int = 22050
    
    # Database
    DB_POOL_SIZE: int = 10
    DB_MAX_OVERFLOW: int = 20
    
    # Caching
    ENABLE_MODEL_CACHING: bool = True
    CACHE_SIZE: int = 100
```

---

**Chalan Voice Backend** - Documentación técnica completa 🔧🚀

*Para más ayuda, consulta el [README principal](../README.md) o abre un issue en GitHub.*