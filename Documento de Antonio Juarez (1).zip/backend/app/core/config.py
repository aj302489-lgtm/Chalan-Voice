"""
Configuración principal de la aplicación Chalan Voice
"""

import os
from typing import List
from pydantic_settings import BaseSettings
from pathlib import Path


class Settings(BaseSettings):
    """Configuraciones de la aplicación"""
    
    # Configuración básica
    APP_NAME: str = "Chalan Voice API"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = False
    
    # Servidor
    HOST: str = "0.0.0.0"
    PORT: int = 8000
    
    # CORS
    ALLOWED_ORIGINS: List[str] = [
        "http://localhost:3000",
        "http://localhost:8080",
        "http://127.0.0.1:3000",
        "http://127.0.0.1:8080",
        "https://*.minimax.io",
        "https://*.space.minimax.io",
        "https://*.minimaxi.com"
    ]
    
    # Base de datos
    DATABASE_URL: str = "sqlite:///./chalan_voice.db"
    
    # JWT
    SECRET_KEY: str = "your-secret-key-change-in-production"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    
    # Modelos de IA
    XTTS_MODEL_NAME: str = "tts_models/multilingual/multi-dataset/xtts_v2"
    BARK_MODEL_NAME: str = "suno/bark"
    TORCH_SEED: int = 42
    
    # Audio
    SAMPLE_RATE: int = 24000
    MAX_AUDIO_DURATION: int = 300  # 5 minutos en segundos
    UPLOAD_DIR: str = "uploads/audio"
    GENERATED_DIR: str = "generated/audio"
    MODELS_DIR: str = "models/user_models"
    
    # Idiomas soportados
    SUPPORTED_LANGUAGES: List[str] = [
        "es", "en", "fr", "de", "it", "pt", "pl", "tr", "ru", 
        "nl", "cs", "ar", "zh-cn", "ja", "hu", "ko", "hi"
    ]
    
    # Marcas de agua
    WATERMARK_ENABLED: bool = True
    WATERMARK_SECRET_KEY: str = "watermark-secret-key"
    
    # Logs
    LOG_LEVEL: str = "INFO"
    LOG_FILE: str = "logs/chalan_voice.log"
    
    # Tamaño de archivos
    MAX_UPLOAD_SIZE: int = 50 * 1024 * 1024  # 50MB
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


# Instancia global de configuración
settings = Settings()


def create_directories():
    """Crear directorios necesarios"""
    directories = [
        settings.UPLOAD_DIR,
        settings.GENERATED_DIR,
        settings.MODELS_DIR,
        "logs",
        "temp"
    ]
    
    for directory in directories:
        Path(directory).mkdir(parents=True, exist_ok=True)


# Crear directorios al importar
create_directories()