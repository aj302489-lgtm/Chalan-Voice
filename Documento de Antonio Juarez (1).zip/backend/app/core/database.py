"""
Configuración y manejo de base de datos SQLite
"""

import sqlite3
import aiosqlite
from typing import List, Dict, Optional, Any
from datetime import datetime
from pathlib import Path

from .config import settings


async def init_db():
    """Inicializar base de datos y crear tablas"""
    db_path = Path(settings.DATABASE_URL.replace("sqlite:///", ""))
    db_path.parent.mkdir(parents=True, exist_ok=True)
    
    async with aiosqlite.connect(db_path) as db:
        # Tabla de usuarios
        await db.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id TEXT PRIMARY KEY,
                email TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                name TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                is_active BOOLEAN DEFAULT 1
            )
        ''')
        
        # Tabla de modelos de voz de usuario
        await db.execute('''
            CREATE TABLE IF NOT EXISTS voice_models (
                id TEXT PRIMARY KEY,
                user_id TEXT NOT NULL,
                model_name TEXT NOT NULL,
                model_path TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'training',
                language TEXT NOT NULL,
                sample_count INTEGER DEFAULT 0,
                total_duration REAL DEFAULT 0.0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                training_progress REAL DEFAULT 0.0,
                error_message TEXT,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        ''')
        
        # Tabla de muestras de audio para entrenamiento
        await db.execute('''
            CREATE TABLE IF NOT EXISTS audio_samples (
                id TEXT PRIMARY KEY,
                user_id TEXT NOT NULL,
                model_id TEXT NOT NULL,
                file_path TEXT NOT NULL,
                transcript TEXT,
                emotion TEXT,
                duration REAL,
                sample_rate INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (id),
                FOREIGN KEY (model_id) REFERENCES voice_models (id)
            )
        ''')
        
        # Tabla de logs del sistema
        await db.execute('''
            CREATE TABLE IF NOT EXISTS system_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id TEXT,
                action TEXT NOT NULL,
                details TEXT,
                emotion TEXT,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                success BOOLEAN DEFAULT 1,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        ''')
        
        # Tabla de generación de audio
        await db.execute('''
            CREATE TABLE IF NOT EXISTS audio_generations (
                id TEXT PRIMARY KEY,
                user_id TEXT NOT NULL,
                model_id TEXT,
                input_text TEXT NOT NULL,
                emotion TEXT,
                language TEXT NOT NULL,
                output_file_path TEXT NOT NULL,
                generation_time REAL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (id),
                FOREIGN KEY (model_id) REFERENCES voice_models (id)
            )
        ''')
        
        await db.commit()


async def execute_query(
    query: str, 
    params: tuple = (), 
    fetch: bool = False
) -> Optional[List[Dict]]:
    """Ejecutar consulta en base de datos"""
    db_path = Path(settings.DATABASE_URL.replace("sqlite:///", ""))
    
    async with aiosqlite.connect(db_path) as db:
        cursor = await db.execute(query, params)
        
        if fetch:
            columns = [description[0] for description in cursor.description]
            rows = await cursor.fetchall()
            return [dict(zip(columns, row)) for row in rows]
        else:
            await db.commit()
            return cursor.lastrowid


async def get_user_by_id(user_id: str) -> Optional[Dict]:
    """Obtener usuario por ID"""
    result = await execute_query(
        "SELECT * FROM users WHERE id = ?", 
        (user_id,), 
        fetch=True
    )
    return result[0] if result else None


async def get_user_by_email(email: str) -> Optional[Dict]:
    """Obtener usuario por email"""
    result = await execute_query(
        "SELECT * FROM users WHERE email = ?", 
        (email,), 
        fetch=True
    )
    return result[0] if result else None


async def create_user(user_data: Dict) -> str:
    """Crear nuevo usuario"""
    return await execute_query(
        """INSERT INTO users (id, email, password_hash, name) 
           VALUES (?, ?, ?, ?)""",
        (user_data["id"], user_data["email"], user_data["password_hash"], user_data["name"])
    )


async def update_user_model_status(
    model_id: str, 
    status: str, 
    progress: float = 0.0,
    error_message: str = None
):
    """Actualizar estado de modelo de usuario"""
    await execute_query(
        """UPDATE voice_models 
           SET status = ?, training_progress = ?, error_message = ?, updated_at = CURRENT_TIMESTAMP
           WHERE id = ?""",
        (status, progress, error_message, model_id)
    )


async def log_system_action(
    user_id: str, 
    action: str, 
    details: str = None, 
    emotion: str = None, 
    success: bool = True
):
    """Registrar acción en logs del sistema"""
    await execute_query(
        """INSERT INTO system_logs (user_id, action, details, emotion, success) 
           VALUES (?, ?, ?, ?, ?)""",
        (user_id, action, details, emotion, success)
    )