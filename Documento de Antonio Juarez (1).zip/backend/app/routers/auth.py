"""
Router para endpoints de autenticación
"""

from fastapi import APIRouter, HTTPException, Depends, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import ValidationError
from datetime import datetime, timedelta
import uuid

from ..core.auth import (
    create_access_token, 
    verify_token, 
    get_password_hash, 
    verify_password
)
from ..core.database import get_user_by_email, create_user, get_user_by_id
from ..schemas.models import UserCreate, UserLogin, UserResponse, TokenResponse
from ..core.config import settings

router = APIRouter()
security = HTTPBearer()


@router.post("/register", response_model=TokenResponse)
async def register_user(user_data: UserCreate):
    """Registrar nuevo usuario"""
    try:
        # Verificar si el usuario ya existe
        existing_user = await get_user_by_email(user_data.email)
        if existing_user:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="El email ya está registrado"
            )
        
        # Crear nuevo usuario
        user_id = str(uuid.uuid4())
        user_dict = {
            "id": user_id,
            "email": user_data.email,
            "password_hash": get_password_hash(user_data.password),
            "name": user_data.name
        }
        
        await create_user(user_dict)
        
        # Crear token
        access_token = create_user_token(
            user_id=user_id,
            email=user_data.email,
            name=user_data.name
        )
        
        # Calcular tiempo de expiración
        expire_minutes = settings.ACCESS_TOKEN_EXPIRE_MINUTES
        expires_delta = timedelta(minutes=expire_minutes)
        
        return TokenResponse(
            access_token=access_token,
            expires_in=expire_minutes * 60,
            user=UserResponse(
                id=user_id,
                email=user_data.email,
                name=user_data.name,
                created_at=datetime.now(),
                is_active=True
            )
        )
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error registrando usuario: {str(e)}"
        )


@router.post("/login", response_model=TokenResponse)
async def login_user(credentials: UserLogin):
    """Iniciar sesión de usuario"""
    try:
        # Buscar usuario
        user = await get_user_by_email(credentials.email)
        if not user:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Credenciales incorrectas"
            )
        
        # Verificar contraseña
        if not verify_password(credentials.password, user["password_hash"]):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Credenciales incorrectas"
            )
        
        # Crear token
        access_token = create_user_token(
            user_id=user["id"],
            email=user["email"],
            name=user["name"]
        )
        
        # Calcular tiempo de expiración
        expire_minutes = settings.ACCESS_TOKEN_EXPIRE_MINUTES
        expires_delta = timedelta(minutes=expire_minutes)
        
        return TokenResponse(
            access_token=access_token,
            expires_in=expire_minutes * 60,
            user=UserResponse(
                id=user["id"],
                email=user["email"],
                name=user["name"],
                created_at=datetime.fromisoformat(user["created_at"]) if user["created_at"] else datetime.now(),
                is_active=user["is_active"]
            )
        )
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error en login: {str(e)}"
        )


@router.get("/me", response_model=UserResponse)
async def get_current_user(token_data: dict = Depends(verify_token)):
    """Obtener información del usuario actual"""
    try:
        user_id = token_data.get("sub")
        if not user_id:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Token inválido"
            )
        
        user = await get_user_by_id(user_id)
        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Usuario no encontrado"
            )
        
        return UserResponse(
            id=user["id"],
            email=user["email"],
            name=user["name"],
            created_at=datetime.fromisoformat(user["created_at"]) if user["created_at"] else datetime.now(),
            is_active=user["is_active"]
        )
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error obteniendo usuario: {str(e)}"
        )


@router.post("/refresh")
async def refresh_token(current_token: HTTPAuthorizationCredentials = Depends(security)):
    """Renovar token de acceso"""
    try:
        # Verificar token actual
        token_data = verify_token(current_token)
        
        # Crear nuevo token
        new_token = create_access_token(
            data={
                "sub": token_data["sub"],
                "email": token_data["email"],
                "name": token_data["name"],
                "type": "refresh"
            }
        )
        
        return {
            "access_token": new_token,
            "token_type": "bearer",
            "expires_in": settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="No se pudo renovar el token"
        )


@router.post("/logout")
async def logout_user():
    """Cerrar sesión (en implementación real invalidaría el token)"""
    return {"message": "Sesión cerrada exitosamente"}


@router.get("/verify")
async def verify_token_endpoint(token_data: dict = Depends(verify_token)):
    """Verificar validez de token"""
    return {
        "valid": True,
        "user_id": token_data.get("sub"),
        "email": token_data.get("email"),
        "name": token_data.get("name")
    }