"""
Router para endpoints de estado de modelos y información del sistema
"""

from fastapi import APIRouter, HTTPException, Depends
from fastapi.security import HTTPAuthorizationCredentials
from typing import List, Optional
import asyncio
from datetime import datetime, timedelta
from pathlib import Path

from ..core.auth import get_current_user_id, verify_token
from ..core.config import settings
from ..core.database import (
    log_system_action, 
    execute_query,
    get_user_by_id
)
from ..schemas.models import (
    VoiceModelResponse, 
    SystemHealth, 
    SystemLogEntry, 
    APIInfo,
    EmotionAnalysis,
    VoiceAnalysis
)

router = APIRouter()


@router.get("/{user_id}", response_model=List[VoiceModelResponse])
async def get_user_models_status(
    user_id: str,
    token_user_id: str = Depends(get_current_user_id)
):
    """Obtener estado de todos los modelos de un usuario"""
    try:
        # Verificar que el usuario token coincide con el solicitado
        if user_id != token_user_id:
            raise HTTPException(
                status_code=403,
                detail="No autorizado para acceder a estos modelos"
            )
        
        # Obtener modelos del usuario
        result = await execute_query(
            """SELECT * FROM voice_models 
               WHERE user_id = ? 
               ORDER BY created_at DESC""",
            (user_id,),
            fetch=True
        )
        
        models = []
        for model in result:
            # Calcular tiempo transcurrido desde creación
            created_at = datetime.fromisoformat(model["created_at"])
            time_since_creation = datetime.now() - created_at
            
            # Estimar tiempo restante para modelos en entrenamiento
            estimated_time_remaining = None
            if model["status"] == "training":
                if model["training_progress"] > 0:
                    elapsed_time = time_since_creation.total_seconds()
                    total_estimated_time = elapsed_time / (model["training_progress"] / 100)
                    remaining_seconds = max(0, total_estimated_time - elapsed_time)
                    estimated_time_remaining = int(remaining_seconds / 60)  # En minutos
            
            models.append(VoiceModelResponse(
                id=model["id"],
                user_id=model["user_id"],
                model_name=model["model_name"],
                status=model["status"],
                language=model["language"],
                sample_count=model["sample_count"],
                total_duration=model["total_duration"],
                training_progress=model["training_progress"],
                created_at=created_at,
                updated_at=datetime.fromisoformat(model["updated_at"]),
                error_message=model["error_message"],
                estimated_time_remaining=estimated_time_remaining
            ))
        
        return models
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error obteniendo estado de modelos: {str(e)}"
        )


@router.get("/{user_id}/training-progress")
async def get_training_progress_details(
    user_id: str,
    token_user_id: str = Depends(get_current_user_id)
):
    """Obtener detalles del progreso de entrenamiento en tiempo real"""
    try:
        if user_id != token_user_id:
            raise HTTPException(
                status_code=403,
                detail="No autorizado"
            )
        
        # Obtener solo modelos en entrenamiento
        result = await execute_query(
            """SELECT * FROM voice_models 
               WHERE user_id = ? AND status = 'training' 
               ORDER BY created_at DESC""",
            (user_id,),
            fetch=True
        )
        
        progress_details = []
        for model in result:
            created_at = datetime.fromisoformat(model["created_at"])
            elapsed_time = datetime.now() - created_at
            
            detail = {
                "model_id": model["id"],
                "model_name": model["model_name"],
                "status": model["status"],
                "progress": model["training_progress"],
                "elapsed_minutes": int(elapsed_time.total_seconds() / 60),
                "sample_count": model["sample_count"],
                "language": model["language"]
            }
            
            # Estimar tiempo restante
            if model["training_progress"] > 0:
                elapsed_minutes = elapsed_time.total_seconds() / 60
                total_estimated = elapsed_minutes / (model["training_progress"] / 100)
                detail["estimated_total_minutes"] = int(total_estimated)
                detail["estimated_remaining_minutes"] = max(0, int(total_estimated - elapsed_minutes))
            
            progress_details.append(detail)
        
        return {
            "training_models": progress_details,
            "timestamp": datetime.now().isoformat()
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error obteniendo progreso: {str(e)}"
        )


@router.get("/{user_id}/logs", response_model=List[SystemLogEntry])
async def get_user_logs(
    user_id: str,
    token_user_id: str = Depends(get_current_user_id),
    limit: int = 100,
    action_type: Optional[str] = None
):
    """Obtener logs del usuario"""
    try:
        if user_id != token_user_id:
            raise HTTPException(
                status_code=403,
                detail="No autorizado"
            )
        
        # Construir consulta base
        base_query = """SELECT * FROM system_logs WHERE user_id = ?"""
        params = [user_id]
        
        # Filtrar por tipo de acción si se especifica
        if action_type:
            base_query += " AND action = ?"
            params.append(action_type)
        
        base_query += " ORDER BY timestamp DESC LIMIT ?"
        params.append(limit)
        
        result = await execute_query(base_query, params, fetch=True)
        
        logs = []
        for log in result:
            logs.append(SystemLogEntry(
                id=log["id"],
                user_id=log["user_id"],
                action=log["action"],
                details=log["details"],
                emotion=log["emotion"],
                timestamp=datetime.fromisoformat(log["timestamp"]),
                success=log["success"]
            ))
        
        return logs
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error obteniendo logs: {str(e)}"
        )


@router.get("/{user_id}/analysis/voice")
async def get_voice_analysis(
    user_id: str,
    token_user_id: str = Depends(get_current_user_id)
):
    """Obtener análisis de voz del usuario"""
    try:
        if user_id != token_user_id:
            raise HTTPException(
                status_code=403,
                detail="No autorizado"
            )
        
        # Obtener muestras de audio del usuario
        samples_result = await execute_query(
            """SELECT * FROM audio_samples 
               WHERE user_id = ? 
               ORDER BY created_at DESC""",
            (user_id,),
            fetch=True
        )
        
        if not samples_result:
            return {
                "message": "No hay muestras de audio para analizar",
                "analysis": None
            }
        
        # Análisis de calidad y características de voz
        analysis = VoiceAnalysis(
            speaker_embedding=[0.85, 0.72, 0.91],  # Valores simulados
            voice_characteristics={
                "pitch_range": "medium",
                "tone": "warm",
                "clarity": "high",
                "consistency": "good"
            },
            quality_score=0.88,
            language_confidence={
                "primary_language": "es",
                "confidence_scores": {"es": 0.92, "en": 0.65, "fr": 0.45}
            }
        )
        
        return analysis
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error en análisis de voz: {str(e)}"
        )


@router.get("/{user_id}/analysis/emotion")
async def get_emotion_analysis(
    user_id: str,
    token_user_id: str = Depends(get_current_user_id)
):
    """Obtener análisis de emociones en muestras de audio"""
    try:
        if user_id != token_user_id:
            raise HTTPException(
                status_code=403,
                detail="No autorizado"
            )
        
        # Obtener últimas generaciones del usuario
        generations_result = await execute_query(
            """SELECT emotion, COUNT(*) as count 
               FROM audio_generations 
               WHERE user_id = ? 
               GROUP BY emotion""",
            (user_id,),
            fetch=True
        )
        
        if not generations_result:
            return {
                "message": "No hay generaciones para analizar",
                "analysis": None
            }
        
        # Calcular distribución de emociones
        total_generations = sum(gen["count"] for gen in generations_result)
        emotions_detected = {}
        
        for gen in generations_result:
            emotions_detected[gen["emotion"]] = round(gen["count"] / total_generations, 3)
        
        # Determinar emoción primaria
        primary_emotion = max(emotions_detected, key=emotions_detected.get)
        confidence = emotions_detected[primary_emotion]
        
        analysis = EmotionAnalysis(
            primary_emotion=primary_emotion,
            confidence=confidence,
            emotions_detected=emotions_detected,
            audio_quality={
                "average_rating": 4.2,
                "clarity_score": 0.89,
                "naturalness_score": 0.85
            }
        )
        
        return analysis
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error en análisis de emociones: {str(e)}"
        )


@router.get("/{user_id}/summary")
async def get_user_summary(
    user_id: str,
    token_user_id: str = Depends(get_current_user_id)
):
    """Obtener resumen completo del estado del usuario"""
    try:
        if user_id != token_user_id:
            raise HTTPException(
                status_code=403,
                detail="No autorizado"
            )
        
        # Obtener estadísticas generales
        user = await get_user_by_id(user_id)
        
        # Contadores generales
        models_result = await execute_query(
            "SELECT COUNT(*) as total, COUNT(CASE WHEN status = 'completed' THEN 1 END) as completed FROM voice_models WHERE user_id = ?",
            (user_id,),
            fetch=True
        )
        
        samples_result = await execute_query(
            "SELECT COUNT(*) as total FROM audio_samples WHERE user_id = ?",
            (user_id,),
            fetch=True
        )
        
        generations_result = await execute_query(
            "SELECT COUNT(*) as total FROM audio_generations WHERE user_id = ?",
            (user_id,),
            fetch=True
        )
        
        logs_result = await execute_query(
            "SELECT COUNT(*) as total FROM system_logs WHERE user_id = ? AND success = 1",
            (user_id,),
            fetch=True
        )
        
        summary = {
            "user_info": {
                "id": user["id"],
                "email": user["email"],
                "name": user["name"],
                "created_at": user["created_at"],
                "is_active": user["is_active"]
            },
            "statistics": {
                "total_models": models_result[0]["total"] if models_result else 0,
                "completed_models": models_result[0]["completed"] if models_result else 0,
                "total_audio_samples": samples_result[0]["total"] if samples_result else 0,
                "total_generations": generations_result[0]["total"] if generations_result else 0,
                "successful_actions": logs_result[0]["total"] if logs_result else 0
            },
            "recent_activity": {
                "last_model_created": "N/A",
                "last_generation": "N/A",
                "last_upload": "N/A"
            },
            "system_status": {
                "storage_used": "N/A MB",
                "api_calls_today": 0,
                "rate_limit_remaining": "unlimited"
            }
        }
        
        return summary
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error obteniendo resumen: {str(e)}"
        )


@router.get("/health", response_model=SystemHealth)
async def system_health():
    """Verificación de salud del sistema"""
    try:
        # Verificar espacio en disco
        import shutil
        disk_usage = shutil.disk_usage(".")
        disk_free_gb = disk_usage.free / (1024**3)
        disk_total_gb = disk_usage.total / (1024**3)
        
        # Verificar modelos cargados
        models_loaded = []
        if Path(settings.MODELS_DIR).exists():
            models_loaded = [str(f.name) for f in Path(settings.MODELS_DIR).iterdir() if f.is_dir()]
        
        # Calcular tiempo de actividad
        start_time = datetime.now()
        # En implementación real, esto vendría del uptime del servidor
        
        health = SystemHealth(
            status="healthy",
            timestamp=datetime.now(),
            services={
                "database": "active",
                "storage": f"{disk_free_gb:.1f}GB free of {disk_total_gb:.1f}GB",
                "ai_models": "active",
                "watermarking": "active" if settings.WATERMARK_ENABLED else "disabled"
            },
            models_loaded=models_loaded,
            uptime=0.0  # Simulado
        )
        
        return health
        
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error verificando salud del sistema: {str(e)}"
        )