"""
Router para endpoints de entrenamiento de modelos de voz
"""

from fastapi import APIRouter, HTTPException, Depends, BackgroundTasks
from fastapi.security import HTTPAuthorizationCredentials
from typing import List, Optional
import uuid
import json
from pathlib import Path
from datetime import datetime

from ..core.auth import get_current_user_id, verify_token
from ..core.config import settings
from ..core.database import (
    log_system_action, 
    execute_query, 
    update_user_model_status
)
from ..schemas.models import VoiceModelCreate, VoiceModelResponse, ModelStatus, TrainingStats
from ..services.audio_processor import AudioProcessor

router = APIRouter()

# Instancia global del procesador de audio
audio_processor = None


async def get_audio_processor():
    """Dependencia para obtener instancia de AudioProcessor"""
    global audio_processor
    if audio_processor is None:
        audio_processor = await AudioProcessor.initialize()
    return audio_processor


@router.post("/train", response_model=VoiceModelResponse)
async def train_voice_model(
    background_tasks: BackgroundTasks,
    model_data: VoiceModelCreate,
    user_id: str = Depends(get_current_user_id),
    audio_processor: AudioProcessor = Depends(get_audio_processor)
):
    """Iniciar entrenamiento de modelo de voz personalizado"""
    try:
        model_id = str(uuid.uuid4())
        
        # Crear directorio para el modelo
        model_dir = Path(settings.MODELS_DIR) / model_id
        model_dir.mkdir(parents=True, exist_ok=True)
        
        # Obtener muestras de audio del usuario para este modelo
        samples_result = await execute_query(
            """SELECT * FROM audio_samples 
               WHERE user_id = ? 
               ORDER BY created_at DESC""",
            (user_id,),
            fetch=True
        )
        
        if not samples_result:
            raise HTTPException(
                status_code=400,
                detail="No hay muestras de audio disponibles para entrenar"
            )
        
        # Filtrar muestras por idioma si se especifica
        language_samples = [
            sample for sample in samples_result 
            if sample.get('language') == model_data.language
        ]
        
        if not language_samples:
            raise HTTPException(
                status_code=400,
                detail=f"No hay muestras de audio en el idioma {model_data.language}"
            )
        
        # Crear registro del modelo en base de datos
        await execute_query(
            """INSERT INTO voice_models 
               (id, user_id, model_name, status, language, sample_count, total_duration)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (
                model_id,
                user_id,
                model_data.model_name,
                "training",
                model_data.language,
                len(language_samples),
                sum(sample['duration'] for sample in language_samples if sample['duration'])
            )
        )
        
        # Iniciar entrenamiento en background
        background_tasks.add_task(
            audio_processor.train_voice_model,
            user_id=user_id,
            model_name=model_data.model_name,
            language=model_data.language,
            audio_files=language_samples
        )
        
        await log_system_action(
            user_id=user_id,
            action="model_training_started",
            details=f"Modelo {model_data.model_name} en idioma {model_data.language}"
        )
        
        # Retornar información del modelo
        return VoiceModelResponse(
            id=model_id,
            user_id=user_id,
            model_name=model_data.model_name,
            status="training",
            language=model_data.language,
            sample_count=len(language_samples),
            total_duration=sum(sample['duration'] for sample in language_samples if sample['duration']),
            training_progress=0.0,
            created_at=datetime.now(),
            updated_at=datetime.now()
        )
        
    except HTTPException:
        raise
    except Exception as e:
        await log_system_action(
            user_id=user_id,
            action="model_training_failed",
            details=str(e),
            success=False
        )
        raise HTTPException(
            status_code=500,
            detail=f"Error iniciando entrenamiento: {str(e)}"
        )


@router.get("/models", response_model=List[VoiceModelResponse])
async def list_user_models(
    user_id: str = Depends(get_current_user_id)
):
    """Listar modelos de voz del usuario"""
    try:
        result = await execute_query(
            """SELECT * FROM voice_models 
               WHERE user_id = ? 
               ORDER BY created_at DESC""",
            (user_id,),
            fetch=True
        )
        
        models = []
        for model in result:
            models.append(VoiceModelResponse(
                id=model["id"],
                user_id=model["user_id"],
                model_name=model["model_name"],
                status=model["status"],
                language=model["language"],
                sample_count=model["sample_count"],
                total_duration=model["total_duration"],
                training_progress=model["training_progress"],
                created_at=datetime.fromisoformat(model["created_at"]),
                updated_at=datetime.fromisoformat(model["updated_at"]),
                error_message=model["error_message"]
            ))
        
        return models
        
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error listando modelos: {str(e)}"
        )


@router.get("/models/{model_id}", response_model=VoiceModelResponse)
async def get_model_info(
    model_id: str,
    user_id: str = Depends(get_current_user_id)
):
    """Obtener información detallada de un modelo"""
    try:
        result = await execute_query(
            "SELECT * FROM voice_models WHERE id = ? AND user_id = ?",
            (model_id, user_id),
            fetch=True
        )
        
        if not result:
            raise HTTPException(
                status_code=404,
                detail="Modelo no encontrado"
            )
        
        model = result[0]
        return VoiceModelResponse(
            id=model["id"],
            user_id=model["user_id"],
            model_name=model["model_name"],
            status=model["status"],
            language=model["language"],
            sample_count=model["sample_count"],
            total_duration=model["total_duration"],
            training_progress=model["training_progress"],
            created_at=datetime.fromisoformat(model["created_at"]),
            updated_at=datetime.fromisoformat(model["updated_at"]),
            error_message=model["error_message"]
        )
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error obteniendo modelo: {str(e)}"
        )


@router.delete("/models/{model_id}")
async def delete_model(
    model_id: str,
    user_id: str = Depends(get_current_user_id)
):
    """Eliminar modelo de voz"""
    try:
        # Verificar que pertenece al usuario
        result = await execute_query(
            "SELECT * FROM voice_models WHERE id = ? AND user_id = ?",
            (model_id, user_id),
            fetch=True
        )
        
        if not result:
            raise HTTPException(
                status_code=404,
                detail="Modelo no encontrado"
            )
        
        # Eliminar archivos físicos del modelo
        model_dir = Path(settings.MODELS_DIR) / model_id
        if model_dir.exists():
            shutil.rmtree(model_dir)
        
        # Eliminar de base de datos
        await execute_query(
            "DELETE FROM voice_models WHERE id = ?",
            (model_id,)
        )
        
        # Eliminar muestras asociadas
        await execute_query(
            "DELETE FROM audio_samples WHERE model_id = ?",
            (model_id,)
        )
        
        await log_system_action(
            user_id=user_id,
            action="model_deleted",
            details=f"Modelo {model_id} eliminado"
        )
        
        return {"message": "Modelo eliminado exitosamente"}
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error eliminando modelo: {str(e)}"
        )


@router.get("/stats", response_model=TrainingStats)
async def get_training_stats(
    user_id: str = Depends(get_current_user_id)
):
    """Obtener estadísticas de entrenamiento del usuario"""
    try:
        # Obtener todas las muestras del usuario
        samples_result = await execute_query(
            "SELECT * FROM audio_samples WHERE user_id = ?",
            (user_id,),
            fetch=True
        )
        
        if not samples_result:
            return TrainingStats(
                total_samples=0,
                total_duration=0.0,
                average_sample_duration=0.0,
                language_distribution={},
                emotion_distribution={},
                quality_metrics={}
            )
        
        # Calcular estadísticas
        total_samples = len(samples_result)
        total_duration = sum(sample['duration'] or 0 for sample in samples_result)
        average_duration = total_duration / total_samples if total_samples > 0 else 0
        
        # Distribución por idioma
        language_distribution = {}
        for sample in samples_result:
            lang = sample.get('language', 'unknown')
            language_distribution[lang] = language_distribution.get(lang, 0) + 1
        
        # Distribución por emoción
        emotion_distribution = {}
        for sample in samples_result:
            emotion = sample.get('emotion', 'neutral')
            emotion_distribution[emotion] = emotion_distribution.get(emotion, 0) + 1
        
        # Métricas de calidad (simuladas)
        quality_metrics = {
            "average_quality_score": 0.85,
            "noise_level": 0.12,
            "clarity_score": 0.88,
            "consistency_score": 0.82
        }
        
        return TrainingStats(
            total_samples=total_samples,
            total_duration=round(total_duration, 2),
            average_sample_duration=round(average_duration, 2),
            language_distribution=language_distribution,
            emotion_distribution=emotion_distribution,
            quality_metrics=quality_metrics
        )
        
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error obteniendo estadísticas: {str(e)}"
        )


@router.post("/models/{model_id}/retrain")
async def retrain_model(
    model_id: str,
    user_id: str = Depends(get_current_user_id),
    audio_processor: AudioProcessor = Depends(get_audio_processor)
):
    """Re-entrenar modelo existente"""
    try:
        # Verificar que el modelo existe y pertenece al usuario
        result = await execute_query(
            "SELECT * FROM voice_models WHERE id = ? AND user_id = ?",
            (model_id, user_id),
            fetch=True
        )
        
        if not result:
            raise HTTPException(
                status_code=404,
                detail="Modelo no encontrado"
            )
        
        model = result[0]
        
        # Obtener muestras actualizadas
        samples_result = await execute_query(
            """SELECT * FROM audio_samples 
               WHERE user_id = ? AND language = ? 
               ORDER BY created_at DESC""",
            (user_id, model['language']),
            fetch=True
        )
        
        if not samples_result:
            raise HTTPException(
                status_code=400,
                detail="No hay muestras disponibles para re-entrenar"
            )
        
        # Actualizar estado del modelo
        await update_user_model_status(
            model_id=model_id,
            status="training",
            progress=0.0
        )
        
        # Iniciar re-entrenamiento
        import asyncio
        asyncio.create_task(
            audio_processor.train_voice_model(
                user_id=user_id,
                model_name=model["model_name"],
                language=model["language"],
                audio_files=samples_result
            )
        )
        
        await log_system_action(
            user_id=user_id,
            action="model_retrain_started",
            details=f"Re-entrenando modelo {model_id}"
        )
        
        return {"message": "Re-entrenamiento iniciado exitosamente"}
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error en re-entrenamiento: {str(e)}"
        )