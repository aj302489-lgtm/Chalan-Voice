"""
Router para endpoints de voz (upload y generación)
"""

from fastapi import APIRouter, HTTPException, Depends, File, UploadFile, Form, BackgroundTasks
from fastapi.responses import FileResponse
from fastapi.security import HTTPAuthorizationCredentials
from typing import List, Optional
import uuid
import os
from pathlib import Path
import shutil

from ..core.auth import get_current_user_id, verify_token
from ..core.config import settings
from ..core.database import log_system_action, execute_query
from ..schemas.models import (
    AudioUploadResponse, 
    AudioGenerationRequest, 
    AudioGenerationResponse,
    EmotionType
)
from ..services.audio_processor import AudioProcessor
from ..services.watermark import AudioWatermarker

router = APIRouter()

# Instancia global del procesador de audio (se inicializa en main.py)
audio_processor = None
watermarker = None


async def get_audio_processor():
    """Dependencia para obtener instancia de AudioProcessor"""
    global audio_processor
    if audio_processor is None:
        audio_processor = await AudioProcessor.initialize()
    return audio_processor


async def get_watermarker():
    """Dependencia para obtener instancia de AudioWatermarker"""
    global watermarker
    if watermarker is None:
        watermarker = await AudioWatermarker.initialize()
    return watermarker


@router.post("/upload-voice", response_model=AudioUploadResponse)
async def upload_voice_sample(
    background_tasks: BackgroundTasks,
    file: UploadFile = File(..., description="Archivo de audio para clonar voz"),
    emotion: str = Form("neutral", description="Emoción del audio"),
    user_id: str = Depends(get_current_user_id),
    audio_processor: AudioProcessor = Depends(get_audio_processor)
):
    """Subir muestra de voz para crear embedding"""
    try:
        # Validar tipo de archivo
        if not file.content_type.startswith('audio/'):
            raise HTTPException(
                status_code=400, 
                detail="El archivo debe ser de tipo audio"
            )
        
        # Validar extensión
        allowed_extensions = {'.wav', '.mp3', '.m4a', '.flac'}
        file_ext = Path(file.filename).suffix.lower()
        if file_ext not in allowed_extensions:
            raise HTTPException(
                status_code=400,
                detail=f"Extensión no soportada. Permitidas: {', '.join(allowed_extensions)}"
            )
        
        # Leer contenido del archivo
        audio_data = await file.read()
        
        # Validar tamaño
        if len(audio_data) > settings.MAX_UPLOAD_SIZE:
            raise HTTPException(
                status_code=400,
                detail=f"Archivo muy grande. Tamaño máximo: {settings.MAX_UPLOAD_SIZE} bytes"
            )
        
        # Procesar audio
        result = await audio_processor.process_voice_upload(
            audio_data=audio_data,
            user_id=user_id,
            filename=file.filename,
            emotion=emotion
        )
        
        return AudioUploadResponse(
            file_id=result["file_id"],
            file_path=result["file_path"],
            duration=result["duration"],
            sample_rate=result["sample_rate"],
            format=result["format"],
            message="Muestra de voz procesada exitosamente"
        )
        
    except HTTPException:
        raise
    except Exception as e:
        await log_system_action(
            user_id=user_id,
            action="voice_upload_failed",
            details=str(e),
            emotion=emotion,
            success=False
        )
        raise HTTPException(
            status_code=500,
            detail=f"Error procesando archivo: {str(e)}"
        )


@router.post("/generate", response_model=AudioGenerationResponse)
async def generate_speech(
    background_tasks: BackgroundTasks,
    request: AudioGenerationRequest,
    user_id: str = Depends(get_current_user_id),
    audio_processor: AudioProcessor = Depends(get_audio_processor),
    watermarker: AudioWatermarker = Depends(get_watermarker)
):
    """Generar síntesis de voz con texto y emoción"""
    try:
        # Validar idioma soportado
        if request.language not in settings.SUPPORTED_LANGUAGES:
            raise HTTPException(
                status_code=400,
                detail=f"Idioma no soportado. Soportados: {', '.join(settings.SUPPORTED_LANGUAGES)}"
            )
        
        # Validar longitud de texto
        if len(request.text) > 1000:
            raise HTTPException(
                status_code=400,
                detail="Texto muy largo. Máximo 1000 caracteres"
            )
        
        # Generar audio
        generation_result = await audio_processor.generate_speech(
            text=request.text,
            emotion=request.emotion,
            language=request.language,
            user_id=user_id,
            model_id=request.model_id,
            speed=request.speed,
            volume=request.volume
        )
        
        # Cargar y marcar el audio generado
        audio_path = Path(generation_result["file_path"])
        if audio_path.exists():
            import torchaudio
            audio_data, sample_rate = torchaudio.load(str(audio_path))
            
            # Aplicar watermarking
            watermarked_audio = await watermarker.embed_watermark(
                audio_data=audio_data,
                user_id=user_id,
                model_id=request.model_id,
                metadata={
                    "text": request.text,
                    "emotion": request.emotion,
                    "language": request.language
                }
            )
            
            # Guardar versión marcada
            torchaudio.save(str(audio_path), watermarked_audio, sample_rate)
        
        # Registrar en base de datos
        await execute_query(
            """INSERT INTO audio_generations 
               (id, user_id, model_id, input_text, emotion, language, output_file_path, generation_time)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                generation_result["generation_id"],
                user_id,
                request.model_id,
                request.text,
                request.emotion,
                request.language,
                generation_result["file_path"],
                generation_result["generation_time"]
            )
        )
        
        return AudioGenerationResponse(
            generation_id=generation_result["generation_id"],
            file_path=generation_result["file_path"],
            duration=generation_result["duration"],
            emotion=request.emotion,
            language=request.language,
            generation_time=generation_result["generation_time"],
            message="Audio generado y marcado exitosamente"
        )
        
    except HTTPException:
        raise
    except Exception as e:
        await log_system_action(
            user_id=user_id,
            action="speech_generation_failed",
            details=str(e),
            emotion=request.emotion,
            success=False
        )
        raise HTTPException(
            status_code=500,
            detail=f"Error generando audio: {str(e)}"
        )


@router.get("/download/{generation_id}")
async def download_generated_audio(
    generation_id: str,
    user_id: str = Depends(get_current_user_id)
):
    """Descargar audio generado"""
    try:
        # Buscar información del audio
        result = await execute_query(
            "SELECT * FROM audio_generations WHERE id = ? AND user_id = ?",
            (generation_id, user_id),
            fetch=True
        )
        
        if not result:
            raise HTTPException(
                status_code=404,
                detail="Audio no encontrado"
            )
        
        audio_info = result[0]
        file_path = Path(audio_info["output_file_path"])
        
        if not file_path.exists():
            raise HTTPException(
                status_code=404,
                detail="Archivo de audio no encontrado"
            )
        
        # Determinar tipo de contenido basado en extensión
        media_type = "audio/wav"
        if file_path.suffix.lower() == ".mp3":
            media_type = "audio/mpeg"
        elif file_path.suffix.lower() == ".m4a":
            media_type = "audio/mp4"
        
        return FileResponse(
            path=str(file_path),
            media_type=media_type,
            filename=f"chalan_voice_{generation_id}{file_path.suffix}",
            headers={
                "X-Generated-Text": audio_info["input_text"],
                "X-Emotion": audio_info["emotion"],
                "X-Language": audio_info["language"],
                "X-Generation-Time": str(audio_info["generation_time"])
            }
        )
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error descargando archivo: {str(e)}"
        )


@router.get("/generations")
async def list_user_generations(
    user_id: str = Depends(get_current_user_id),
    limit: int = 50,
    offset: int = 0
):
    """Listar generaciones de audio del usuario"""
    try:
        result = await execute_query(
            """SELECT * FROM audio_generations 
               WHERE user_id = ? 
               ORDER BY created_at DESC 
               LIMIT ? OFFSET ?""",
            (user_id, limit, offset),
            fetch=True
        )
        
        return {
            "generations": result,
            "total": len(result),
            "limit": limit,
            "offset": offset
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error listando generaciones: {str(e)}"
        )


@router.delete("/generations/{generation_id}")
async def delete_generated_audio(
    generation_id: str,
    user_id: str = Depends(get_current_user_id)
):
    """Eliminar audio generado"""
    try:
        # Verificar que pertenece al usuario
        result = await execute_query(
            "SELECT * FROM audio_generations WHERE id = ? AND user_id = ?",
            (generation_id, user_id),
            fetch=True
        )
        
        if not result:
            raise HTTPException(
                status_code=404,
                detail="Audio no encontrado"
            )
        
        # Eliminar archivo físico
        audio_info = result[0]
        file_path = Path(audio_info["output_file_path"])
        if file_path.exists():
            file_path.unlink()
        
        # Eliminar de base de datos
        await execute_query(
            "DELETE FROM audio_generations WHERE id = ?",
            (generation_id,)
        )
        
        await log_system_action(
            user_id=user_id,
            action="audio_deleted",
            details=f"Audio {generation_id} eliminado"
        )
        
        return {"message": "Audio eliminado exitosamente"}
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error eliminando audio: {str(e)}"
        )