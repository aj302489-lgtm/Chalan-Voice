"""
Esquemas Pydantic para validación de datos
"""

from pydantic import BaseModel, EmailStr, Field
from typing import Optional, List
from datetime import datetime
from enum import Enum


# Enums
class EmotionType(str, Enum):
    """Tipos de emoción soportados"""
    neutral = "neutral"
    happy = "happy"
    sad = "sad"
    angry = "angry"
    surprised = "surprised"
    fearful = "fearful"
    disgusted = "disgusted"


class ModelStatus(str, Enum):
    """Estados del modelo de entrenamiento"""
    training = "training"
    completed = "completed"
    failed = "failed"
    pending = "pending"


# Schemas de Autenticación
class UserCreate(BaseModel):
    """Esquema para crear usuario"""
    email: EmailStr
    password: str = Field(min_length=6)
    name: str = Field(min_length=2, max_length=100)


class UserLogin(BaseModel):
    """Esquema para login de usuario"""
    email: EmailStr
    password: str


class UserResponse(BaseModel):
    """Respuesta de usuario"""
    id: str
    email: str
    name: str
    created_at: datetime
    is_active: bool

    class Config:
        from_attributes = True


class TokenResponse(BaseModel):
    """Respuesta de token"""
    access_token: str
    token_type: str = "bearer"
    expires_in: int
    user: UserResponse


# Schemas de Modelos de Voz
class VoiceModelCreate(BaseModel):
    """Esquema para crear modelo de voz"""
    model_name: str = Field(min_length=1, max_length=100)
    language: str = Field(min_length=2, max_length=5)


class VoiceModelResponse(BaseModel):
    """Respuesta de modelo de voz"""
    id: str
    user_id: str
    model_name: str
    status: ModelStatus
    language: str
    sample_count: int
    total_duration: float
    training_progress: float
    created_at: datetime
    updated_at: datetime
    error_message: Optional[str] = None

    class Config:
        from_attributes = True


# Schemas de Audio
class AudioUploadResponse(BaseModel):
    """Respuesta de subida de audio"""
    file_id: str
    file_path: str
    duration: float
    sample_rate: int
    format: str
    message: str


class AudioGenerationRequest(BaseModel):
    """Request para generar audio"""
    text: str = Field(min_length=1, max_length=1000)
    emotion: EmotionType = EmotionType.neutral
    language: str = Field(min_length=2, max_length=5)
    model_id: Optional[str] = None
    speed: float = Field(default=1.0, ge=0.5, le=2.0)
    volume: float = Field(default=1.0, ge=0.1, le=2.0)


class AudioGenerationResponse(BaseModel):
    """Respuesta de generación de audio"""
    generation_id: str
    file_path: str
    duration: float
    emotion: EmotionType
    language: str
    generation_time: float
    message: str


# Schemas de Sistema
class SystemHealth(BaseModel):
    """Estado del sistema"""
    status: str
    timestamp: datetime
    services: dict
    models_loaded: List[str]
    uptime: float


class SystemLogEntry(BaseModel):
    """Entrada de log del sistema"""
    id: int
    user_id: Optional[str]
    action: str
    details: Optional[str]
    emotion: Optional[str]
    timestamp: datetime
    success: bool


class APIInfo(BaseModel):
    """Información de la API"""
    name: str
    version: str
    supported_languages: List[str]
    max_audio_duration: int
    supported_audio_formats: List[str]
    features: List[str]


# Schemas de Análisis
class EmotionAnalysis(BaseModel):
    """Análisis de emoción"""
    primary_emotion: EmotionType
    confidence: float
    emotions_detected: dict
    audio_quality: dict


class VoiceAnalysis(BaseModel):
    """Análisis de voz"""
    speaker_embedding: List[float]
    voice_characteristics: dict
    quality_score: float
    language_confidence: dict


class TrainingStats(BaseModel):
    """Estadísticas de entrenamiento"""
    total_samples: int
    total_duration: float
    average_sample_duration: float
    language_distribution: dict
    emotion_distribution: dict
    quality_metrics: dict