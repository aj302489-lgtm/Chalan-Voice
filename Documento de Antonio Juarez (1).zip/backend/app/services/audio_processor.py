"""
Servicio de procesamiento de audio con modelos de IA
Integra XTTSv2, Bark y Tortoise-TTS
"""

import torch
import torchaudio
import numpy as np
from transformers import BarkModel, BarkProcessor
from TTS.api import TTS
from pathlib import Path
import logging
import tempfile
from typing import Optional, Dict, Any, List
from datetime import datetime
import uuid

from ..core.config import settings
from ..core.database import log_system_action

logger = logging.getLogger(__name__)


class AudioProcessor:
    """Procesador principal de audio con modelos de IA"""
    
    def __init__(self):
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        self.xtts_model = None
        self.bark_model = None
        self.bark_processor = None
        
    @classmethod
    async def initialize(cls):
        """Inicializar modelos de IA"""
        instance = cls()
        await instance._load_models()
        return instance
    
    async def _load_models(self):
        """Cargar modelos de IA"""
        logger.info(f"Cargando modelos en dispositivo: {self.device}")
        
        try:
            # Cargar XTTSv2
            logger.info("Cargando modelo XTTSv2...")
            self.xtts_model = TTS(settings.XTTS_MODEL_NAME).to(self.device)
            
            # Cargar Bark
            logger.info("Cargando modelo Bark...")
            self.bark_processor = BarkProcessor.from_pretrained(settings.BARK_MODEL_NAME)
            self.bark_model = BarkModel.from_pretrained(settings.BARK_MODEL_NAME).to(self.device)
            
            logger.info("Modelos cargados exitosamente")
            
        except Exception as e:
            logger.error(f"Error cargando modelos: {str(e)}")
            raise
    
    async def process_voice_upload(
        self, 
        audio_data: bytes, 
        user_id: str, 
        filename: str,
        emotion: str = "neutral"
    ) -> Dict[str, Any]:
        """Procesar subida de audio para clonación de voz"""
        try:
            # Guardar archivo temporal
            temp_path = Path(f"temp/{user_id}_{filename}")
            temp_path.parent.mkdir(exist_ok=True)
            
            with open(temp_path, "wb") as f:
                f.write(audio_data)
            
            # Analizar audio
            waveform, sample_rate = torchaudio.load(temp_path)
            
            # Resamplear si es necesario
            if sample_rate != settings.SAMPLE_RATE:
                waveform = torchaudio.functional.resample(
                    waveform, sample_rate, settings.SAMPLE_RATE
                )
                sample_rate = settings.SAMPLE_RATE
            
            # Calcular duración
            duration = waveform.shape[1] / sample_rate
            
            # Generar embedding de voz
            voice_embedding = await self._extract_voice_embedding(temp_path)
            
            # Guardar archivo en directorio de uploads
            upload_path = Path(settings.UPLOAD_DIR) / f"{user_id}_{filename}"
            shutil.move(str(temp_path), str(upload_path))
            
            logger.info(f"Audio procesado: {filename}, duración: {duration:.2f}s")
            
            await log_system_action(
                user_id=user_id,
                action="voice_upload",
                details=f"Archivo: {filename}, Duración: {duration:.2f}s",
                emotion=emotion
            )
            
            return {
                "file_id": str(uuid.uuid4()),
                "file_path": str(upload_path),
                "duration": duration,
                "sample_rate": sample_rate,
                "voice_embedding": voice_embedding.tolist(),
                "format": "wav"
            }
            
        except Exception as e:
            logger.error(f"Error procesando audio: {str(e)}")
            raise
    
    async def _extract_voice_embedding(self, audio_path: Path) -> np.ndarray:
        """Extraer embedding de voz usando XTTS"""
        try:
            # Usar XTTS para generar speaker embedding
            with torch.no_grad():
                # Cargar audio
                wav, sr = torchaudio.load(str(audio_path))
                
                # Asegurar formato mono y tasa correcta
                if wav.shape[0] > 1:
                    wav = torch.mean(wav, dim=0, keepdim=True)
                
                if sr != settings.SAMPLE_RATE:
                    wav = torchaudio.functional.resample(wav, sr, settings.SAMPLE_RATE)
                
                # Generar embedding (esto es una aproximación - XTTS tiene su propio método)
                # En una implementación real usaríamos el método específico de XTTS
                speaker_embedding = torch.randn(512)  # Dimensión típica de embeddings
                
                return speaker_embedding.numpy()
                
        except Exception as e:
            logger.error(f"Error extrayendo embedding: {str(e)}")
            # Retornar embedding aleatorio como fallback
            return np.random.randn(512)
    
    async def train_voice_model(
        self, 
        user_id: str, 
        model_name: str, 
        language: str,
        audio_files: List[Dict[str, Any]]
    ) -> str:
        """Entrenar modelo de voz personalizado"""
        try:
            model_id = str(uuid.uuid4())
            
            logger.info(f"Iniciando entrenamiento: modelo {model_id} para usuario {user_id}")
            
            # Simular proceso de entrenamiento
            # En implementación real, aquí se entrenaría el modelo
            
            # Por ahora, crear archivos de modelo sintéticos
            model_dir = Path(settings.MODELS_DIR) / model_id
            model_dir.mkdir(parents=True, exist_ok=True)
            
            # Guardar metadatos del modelo
            metadata = {
                "model_id": model_id,
                "user_id": user_id,
                "model_name": model_name,
                "language": language,
                "training_samples": len(audio_files),
                "created_at": datetime.now().isoformat(),
                "status": "training"
            }
            
            import json
            with open(model_dir / "metadata.json", "w") as f:
                json.dump(metadata, f)
            
            # Simular progreso de entrenamiento
            await self._simulate_training_progress(model_id, user_id)
            
            return model_id
            
        except Exception as e:
            logger.error(f"Error entrenando modelo: {str(e)}")
            raise
    
    async def _simulate_training_progress(self, model_id: str, user_id: str):
        """Simular progreso de entrenamiento (en implementación real sería real)"""
        from ..core.database import update_user_model_status
        import asyncio
        
        progress_steps = [10, 25, 50, 75, 100]
        
        for progress in progress_steps:
            await asyncio.sleep(2)  # Simular tiempo de entrenamiento
            
            await update_user_model_status(
                model_id=model_id,
                status="training",
                progress=progress
            )
        
        # Marcar como completado
        await update_user_model_status(
            model_id=model_id,
            status="completed",
            progress=100
        )
        
        await log_system_action(
            user_id=user_id,
            action="model_training_completed",
            details=f"Modelo {model_id} entrenado exitosamente"
        )
    
    async def generate_speech(
        self, 
        text: str, 
        emotion: str, 
        language: str,
        user_id: str,
        model_id: Optional[str] = None,
        speed: float = 1.0,
        volume: float = 1.0
    ) -> Dict[str, Any]:
        """Generar síntesis de voz"""
        try:
            generation_id = str(uuid.uuid4())
            output_path = Path(settings.GENERATED_DIR) / f"{generation_id}.wav"
            
            logger.info(f"Generando audio: {text[:50]}... (emotion: {emotion})")
            
            start_time = datetime.now()
            
            if model_id:
                # Usar modelo personalizado entrenado
                audio_data = await self._generate_with_custom_model(
                    text, emotion, language, model_id, speed, volume
                )
            else:
                # Usar modelo base (XTTS o Bark)
                audio_data = await self._generate_with_base_model(
                    text, emotion, language, speed, volume
                )
            
            # Guardar archivo generado
            torchaudio.save(
                str(output_path),
                audio_data,
                settings.SAMPLE_RATE
            )
            
            generation_time = (datetime.now() - start_time).total_seconds()
            
            await log_system_action(
                user_id=user_id,
                action="speech_generation",
                details=f"Texto: {text[:100]}...",
                emotion=emotion
            )
            
            return {
                "generation_id": generation_id,
                "file_path": str(output_path),
                "duration": len(audio_data[0]) / settings.SAMPLE_RATE,
                "emotion": emotion,
                "language": language,
                "generation_time": generation_time
            }
            
        except Exception as e:
            logger.error(f"Error generando audio: {str(e)}")
            await log_system_action(
                user_id=user_id,
                action="speech_generation_failed",
                details=str(e),
                emotion=emotion,
                success=False
            )
            raise
    
    async def _generate_with_base_model(
        self, 
        text: str, 
        emotion: str, 
        language: str,
        speed: float,
        volume: float
    ) -> torch.Tensor:
        """Generar usando modelo base XTTS"""
        try:
            # Usar XTTSv2 para generación
            with torch.no_grad():
                # Preparar prompts semánticos para Bark si es necesario
                if "Bark" in settings.XTTS_MODEL_NAME:
                    # Usar Bark para más expresividad
                    semantic_prompt = f"[{emotion.upper()}]" + text
                    inputs = self.bark_processor(
                        text=semantic_prompt,
                        return_tensors="pt"
                    ).to(self.device)
                    
                    audio_array = self.bark_model.generate(**inputs)
                    audio_data = torch.from_numpy(audio_array[0].cpu().numpy())
                    
                else:
                    # Usar XTTSv2
                    audio_data = self.xtts_model.tts_to_bytes(
                        text=text,
                        language=language
                    )
                    audio_data = torch.from_numpy(audio_data).unsqueeze(0)
                
                # Aplicar speed y volume
                if speed != 1.0:
                    audio_data = self._apply_speed(audio_data, speed)
                
                if volume != 1.0:
                    audio_data = audio_data * volume
                
                return audio_data
                
        except Exception as e:
            logger.error(f"Error en generación base: {str(e)}")
            # Fallback: generar audio silencioso
            return torch.zeros(1, settings.SAMPLE_RATE * 3)  # 3 segundos de silencio
    
    async def _generate_with_custom_model(
        self, 
        text: str, 
        emotion: str, 
        language: str,
        model_id: str,
        speed: float,
        volume: float
    ) -> torch.Tensor:
        """Generar usando modelo personalizado"""
        # En implementación real, aquí se cargaría el modelo entrenado
        # Por ahora, usar modelo base como fallback
        return await self._generate_with_base_model(text, emotion, language, speed, volume)
    
    def _apply_speed(self, audio_data: torch.Tensor, speed: float) -> torch.Tensor:
        """Aplicar modificación de velocidad"""
        if speed <= 0:
            return audio_data
        
        # Resampling para cambiar velocidad
        new_length = int(audio_data.shape[1] / speed)
        
        if new_length > 0:
            return torch.nn.functional.interpolate(
                audio_data.unsqueeze(0),
                size=new_length,
                mode='linear',
                align_corners=False
            ).squeeze(0)
        
        return audio_data