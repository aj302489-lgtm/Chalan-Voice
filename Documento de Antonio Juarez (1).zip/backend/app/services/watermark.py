"""
Servicio de watermarking acústico para protección de contenido
Basado en técnicas de VoiceMark y watermarking robusto
"""

import torch
import torchaudio
import numpy as np
from pathlib import Path
import logging
from typing import Tuple, Dict, Any
from scipy.signal import butter, lfilter
import random
import hashlib
from datetime import datetime

from ..core.config import settings

logger = logging.getLogger(__name__)


class AudioWatermarker:
    """Marcador de agua acústico para audio generado"""
    
    def __init__(self):
        self.secret_key = settings.WATERMARK_SECRET_KEY.encode()
        self.watermark_enabled = settings.WATERMARK_ENABLED
        
    @classmethod
    async def initialize(cls):
        """Inicializar watermarker"""
        return cls()
    
    async def embed_watermark(
        self, 
        audio_data: torch.Tensor, 
        user_id: str, 
        model_id: str = None,
        metadata: Dict[str, Any] = None
    ) -> torch.Tensor:
        """Insertar marca de agua en audio"""
        if not self.watermark_enabled:
            return audio_data
        
        try:
            logger.info("Insertando marca de agua acústica")
            
            # Generar marca de agua basada en usuario y contenido
            watermark_signal = await self._generate_watermark_signal(
                audio_data.shape[1], user_id, model_id, metadata
            )
            
            # Aplicar marca de agua usando técnicas de VoiceMark
            watermarked_audio = await self._embed_voice_mark_watermark(
                audio_data, watermark_signal
            )
            
            return watermarked_audio
            
        except Exception as e:
            logger.error(f"Error insertando marca de agua: {str(e)}")
            return audio_data  # Retornar audio sin marca en caso de error
    
    async def detect_watermark(
        self, 
        audio_data: torch.Tensor
    ) -> Dict[str, Any]:
        """Detectar marca de agua en audio"""
        if not self.watermark_enabled:
            return {"watermarked": False, "confidence": 0.0}
        
        try:
            # Aplicar detección de VoiceMark
            detection_result = await self._detect_voice_mark(audio_data)
            
            return detection_result
            
        except Exception as e:
            logger.error(f"Error detectando marca de agua: {str(e)}")
            return {"watermarked": False, "confidence": 0.0, "error": str(e)}
    
    async def _generate_watermark_signal(
        self, 
        audio_length: int, 
        user_id: str, 
        model_id: str = None,
        metadata: Dict[str, Any] = None
    ) -> torch.Tensor:
        """Generar señal de marca de agua específica"""
        try:
            # Crear semilla basada en usuario y metadatos
            seed_data = f"{user_id}_{model_id}_{metadata or {}}".encode()
            seed = int(hashlib.sha256(seed_data).hexdigest()[:8], 16)
            
            # Configuración de watermarking
            watermark_length = min(audio_length // 100, 1000)  # 1% del audio o 1000 samples
            watermark_freq = 8000  # Frecuencia en Hz (por encima del rango de voz)
            sample_rate = settings.SAMPLE_RATE
            
            # Generar señal de marca de agua
            t = torch.linspace(0, watermark_length / sample_rate, watermark_length)
            base_watermark = torch.sin(2 * torch.pi * watermark_freq * t)
            
            # Modulación con patrón único del usuario
            np.random.seed(seed)
            pattern = torch.from_numpy(np.random.randn(watermark_length))
            
            # Combinar señal base con patrón
            watermark_signal = base_watermark * (0.01 + 0.005 * pattern)  # Amplitud muy baja
            
            return watermark_signal
            
        except Exception as e:
            logger.error(f"Error generando señal de marca: {str(e)}")
            # Retornar señal vacía como fallback
            return torch.zeros(min(audio_length // 100, 1000))
    
    async def _embed_voice_mark_watermark(
        self, 
        audio_data: torch.Tensor, 
        watermark_signal: torch.Tensor
    ) -> torch.Tensor:
        """Implementar algoritmo de watermarking VoiceMark"""
        try:
            device = audio_data.device
            watermark_signal = watermark_signal.to(device)
            
            # Separar canales si es estéreo
            if audio_data.shape[0] == 2:
                watermarked_audio = audio_data.clone()
                
                # Insertar en ambos canales con fase invertida
                channel1_start = audio_data.shape[1] // 4
                channel1_end = channel1_start + len(watermark_signal)
                
                channel2_start = 3 * audio_data.shape[1] // 4
                channel2_end = channel2_start + len(watermark_signal)
                
                # Canal izquierdo: suma directa
                if channel1_end <= audio_data.shape[1]:
                    watermarked_audio[0, channel1_start:channel1_end] += watermark_signal
                
                # Canal derecho: resta para robustez
                if channel2_end <= audio_data.shape[1]:
                    watermarked_audio[1, channel2_start:channel2_end] -= watermark_signal
                
            else:
                # Mono: insertar en múltiples posiciones
                watermarked_audio = audio_data.clone()
                positions = [0, len(watermark_signal)]
                
                for i, pos in enumerate(positions):
                    end_pos = pos + len(watermark_signal)
                    if end_pos <= audio_data.shape[1]:
                        # Alternar fase para robustez
                        phase = 1 if i % 2 == 0 else -1
                        watermarked_audio[0, pos:end_pos] += phase * watermark_signal
            
            # Aplicar filtro para enmascarar la marca de agua
            watermarked_audio = await self._apply_perceptual_masking(
                watermarked_audio, watermark_signal
            )
            
            return torch.clamp(watermarked_audio, -1.0, 1.0)
            
        except Exception as e:
            logger.error(f"Error en VoiceMark embedding: {str(e)}")
            return audio_data
    
    async def _apply_perceptual_masking(
        self, 
        audio_data: torch.Tensor, 
        watermark_signal: torch.Tensor
    ) -> torch.Tensor:
        """Aplicar enmascaramiento perceptual para ocultar la marca"""
        try:
            # Filtro pasa-altos para la marca de agua (frecuencias altas son menos perceptibles)
            nyquist = settings.SAMPLE_RATE / 2
            cutoff = 8000 / nyquist
            
            # Diseño del filtro
            b, a = butter(4, cutoff, btype='high')
            
            # Convertir a tensor para procesamiento con PyTorch
            watermark_np = watermark_signal.cpu().numpy()
            filtered_watermark = lfilter(b, a, watermark_np)
            filtered_watermark = torch.from_numpy(filtered_watermark).to(audio_data.device)
            
            # Modulación de amplitud basada en el audio original
            audio_energy = torch.sqrt(torch.mean(audio_data ** 2))
            watermark_energy = torch.sqrt(torch.mean(filtered_watermark ** 2))
            
            if watermark_energy > 0:
                # Ajustar amplitud para que sea inaudible pero detectable
                target_ratio = 0.001  # 0.1% de la energía del audio
                amplitude_ratio = target_ratio * audio_energy / watermark_energy
                filtered_watermark = filtered_watermark * amplitude_ratio
            
            return audio_data + filtered_watermark
            
        except Exception as e:
            logger.error(f"Error en enmascaramiento: {str(e)}")
            return audio_data
    
    async def _detect_voice_mark(self, audio_data: torch.Tensor) -> Dict[str, Any]:
        """Detectar marca de agua usando técnicas de VoiceMark"""
        try:
            # En implementación real, aquí se aplicarían los algoritmos de detección
            # Por simplicidad, retornamos un resultado positivo con confianza simulada
            
            # Análisis de correlación para detección
            device = audio_data.device
            
            # Dividir audio en segmentos
            segment_length = min(audio_data.shape[1] // 4, 1000)
            
            correlations = []
            for i in range(3):  # Analizar 3 segmentos
                start_pos = i * audio_data.shape[1] // 4
                end_pos = start_pos + segment_length
                
                if end_pos <= audio_data.shape[1]:
                    segment = audio_data[0, start_pos:end_pos]  # Usar canal 0
                    
                    # Calcular correlación con patrón esperado
                    correlation = await self._calculate_watermark_correlation(segment)
                    correlations.append(correlation)
            
            # Calcular confianza basada en correlaciones
            avg_correlation = np.mean(correlations)
            confidence = min(avg_correlation * 10, 1.0)  # Normalizar a 0-1
            
            # Determinar si está marcado
            is_watermarked = avg_correlation > 0.3
            
            return {
                "watermarked": is_watermarked,
                "confidence": confidence,
                "correlation_scores": correlations,
                "detection_method": "voice_mark",
                "timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Error en detección: {str(e)}")
            return {
                "watermarked": False,
                "confidence": 0.0,
                "error": str(e)
            }
    
    async def _calculate_watermark_correlation(self, audio_segment: torch.Tensor) -> float:
        """Calcular correlación con patrón de marca de agua esperado"""
        try:
            # Generar patrón esperado
            pattern_length = min(len(audio_segment), 1000)
            t = torch.linspace(0, pattern_length / settings.SAMPLE_RATE, pattern_length)
            expected_pattern = torch.sin(2 * torch.pi * 8000 * t)
            
            # Ajustar tamaños
            if len(expected_pattern) > len(audio_segment):
                expected_pattern = expected_pattern[:len(audio_segment)]
            else:
                audio_segment = audio_segment[:len(expected_pattern)]
            
            # Calcular correlación cruzada normalizada
            correlation = torch.nn.functional.cosine_similarity(
                audio_segment.unsqueeze(0),
                expected_pattern.unsqueeze(0)
            ).item()
            
            return abs(correlation)  # Valor absoluto para robustez
            
        except Exception:
            return 0.0