#!/bin/bash

# Script de instalación y despliegue para Chalan Voice Backend
# Ejecutar con: bash install.sh

set -e

echo "🚀 Chalan Voice Backend - Script de Instalación"
echo "==============================================="

# Colores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Funciones de utilidad
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[OK]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Verificar sistema operativo
check_os() {
    if [[ "$OSTYPE" == "linux-gnu"* ]]; then
        OS="linux"
        print_success "Sistema operativo: Linux"
    elif [[ "$OSTYPE" == "darwin"* ]]; then
        OS="macos"
        print_success "Sistema operativo: macOS"
    else
        print_error "Sistema operativo no soportado: $OSTYPE"
        exit 1
    fi
}

# Verificar dependencias del sistema
check_dependencies() {
    print_status "Verificando dependencias del sistema..."
    
    # Python 3.9+
    if command -v python3 &> /dev/null; then
        PYTHON_VERSION=$(python3 --version | cut -d' ' -f2)
        print_success "Python encontrado: $PYTHON_VERSION"
    else
        print_error "Python 3.9+ no encontrado. Instalar desde https://python.org"
        exit 1
    fi
    
    # pip
    if command -v pip3 &> /dev/null; then
        print_success "pip3 encontrado"
    else
        print_error "pip3 no encontrado"
        exit 1
    fi
    
    # Git
    if command -v git &> /dev/null; then
        print_success "Git encontrado"
    else
        print_error "Git no encontrado"
        exit 1
    fi
}

# Instalar dependencias del sistema
install_system_deps() {
    print_status "Instalando dependencias del sistema..."
    
    if [[ "$OS" == "linux" ]]; then
        # Ubuntu/Debian
        if command -v apt-get &> /dev/null; then
            sudo apt-get update
            sudo apt-get install -y \
                python3-dev \
                python3-pip \
                python3-venv \
                git \
                wget \
                curl \
                build-essential \
                libsndfile1 \
                libsndfile1-dev \
                libasound2-dev \
                portaudio19-dev \
                ffmpeg \
                nginx
        # CentOS/RHEL
        elif command -v yum &> /dev/null; then
            sudo yum groupinstall -y "Development Tools"
            sudo yum install -y \
                python3-devel \
                python3-pip \
                git \
                wget \
                curl \
                alsa-lib-devel \
                portaudio-devel \
                ffmpeg \
                nginx
        else
            print_warning "Gestor de paquetes no reconocido. Instalar dependencias manualmente."
        fi
    elif [[ "$OS" == "macos" ]]; then
        # Verificar Homebrew
        if ! command -v brew &> /dev/null; then
            print_status "Instalando Homebrew..."
            /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
        fi
        
        # Instalar dependencias
        brew install python@3.9 git wget curl ffmpeg portaudio
    fi
}

# Crear entorno virtual Python
setup_python_env() {
    print_status "Configurando entorno virtual Python..."
    
    # Crear directorio del proyecto si no existe
    if [ ! -d "chalan-voice-backend" ]; then
        mkdir -p chalan-voice-backend
        cd chalan-voice-backend
    fi
    
    # Crear entorno virtual
    if [ ! -d "venv" ]; then
        python3 -m venv venv
        print_success "Entorno virtual creado"
    fi
    
    # Activar entorno virtual
    source venv/bin/activate
    print_success "Entorno virtual activado"
    
    # Actualizar pip
    pip install --upgrade pip
    print_success "pip actualizado"
}

# Instalar dependencias Python
install_python_deps() {
    print_status "Instalando dependencias Python..."
    
    # Verificar archivo requirements.txt
    if [ ! -f "requirements.txt" ]; then
        print_error "Archivo requirements.txt no encontrado"
        exit 1
    fi
    
    # Instalar PyTorch con CUDA primero (si está disponible)
    if command -v nvidia-smi &> /dev/null; then
        print_status "GPU NVIDIA detectada, instalando PyTorch con CUDA..."
        pip install torch torchaudio --index-url https://download.pytorch.org/whl/cu118
    else
        print_status "Instalando PyTorch para CPU..."
        pip install torch torchaudio --index-url https://download.pytorch.org/whl/cpu
    fi
    
    # Instalar dependencias restantes
    pip install -r requirements.txt
    print_success "Dependencias Python instaladas"
}

# Configurar variables de entorno
setup_environment() {
    print_status "Configurando variables de entorno..."
    
    if [ ! -f ".env" ]; then
        if [ -f ".env.example" ]; then
            cp .env.example .env
            print_success "Archivo .env creado desde .env.example"
        else
            print_warning "Archivo .env.example no encontrado"
        fi
    fi
    
    print_warning "IMPORTANTE: Revisar y configurar variables en .env:"
    echo "  • SECRET_KEY (clave secreta para JWT)"
    echo "  • WATERMARK_SECRET_KEY (clave para watermarking)"
    echo "  • ALLOWED_ORIGINS (dominios permitidos)"
    echo "  • DATABASE_URL (URL de base de datos)"
}

# Crear directorios necesarios
create_directories() {
    print_status "Creando directorios necesarios..."
    
    directories=(
        "uploads/audio"
        "generated/audio"
        "models/user_models"
        "logs"
        "temp"
        "ssl"
    )
    
    for dir in "${directories[@]}"; do
        mkdir -p "$dir"
        print_success "Directorio creado: $dir"
    done
}

# Configurar Docker (opcional)
setup_docker() {
    read -p "¿Desea configurar Docker para despliegue? (y/N): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        print_status "Configurando Docker..."
        
        # Verificar Docker
        if command -v docker &> /dev/null; then
            print_success "Docker encontrado"
        else
            print_error "Docker no encontrado. Instalar desde https://docker.com"
            return
        fi
        
        # Verificar Docker Compose
        if command -v docker-compose &> /dev/null; then
            print_success "Docker Compose encontrado"
        else
            print_warning "Docker Compose no encontrado. Instalar docker-compose"
        fi
        
        print_warning "Ejecutar con Docker: docker-compose up --build"
    fi
}

# Configurar Nginx (opcional)
setup_nginx() {
    read -p "¿Desea configurar Nginx para producción? (y/N): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        print_status "Configurando Nginx..."
        
        # Verificar si nginx está instalado
        if command -v nginx &> /dev/null; then
            print_success "Nginx encontrado"
            
            # Solicitar dominio
            read -p "Ingrese su dominio: " DOMAIN_NAME
            
            # Actualizar configuración nginx
            if [ -f "nginx.conf" ]; then
                sed "s/tu-dominio.com/$DOMAIN_NAME/g" nginx.conf > /tmp/nginx-chalan-voice.conf
                sudo cp /tmp/nginx-chalan-voice.conf /etc/nginx/sites-available/chalan-voice
                sudo ln -sf /etc/nginx/sites-available/chalan-voice /etc/nginx/sites-enabled/
                sudo nginx -t && sudo systemctl reload nginx
                print_success "Nginx configurado para $DOMAIN_NAME"
            fi
        else
            print_error "Nginx no encontrado"
        fi
    fi
}

# Generar certificados SSL autofirmados para desarrollo
generate_ssl_certs() {
    if [[ "$SSL_SETUP" == "y" ]]; then
        print_status "Generando certificados SSL de desarrollo..."
        
        mkdir -p ssl
        
        openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
            -keyout ssl/clave-privada.key \
            -out ssl/certificado.crt \
            -subj "/C=ES/ST=Madrid/L=Madrid/O=Chalan Voice/OU=IT/CN=localhost"
        
        print_success "Certificados SSL generados en directorio ssl/"
        print_warning "Para producción, usar certificados válidos (Let's Encrypt, etc.)"
    fi
}

# Función principal
main() {
    echo
    print_status "Iniciando instalación de Chalan Voice Backend..."
    echo
    
    # Verificaciones del sistema
    check_os
    check_dependencies
    
    # Instalación
    install_system_deps
    setup_python_env
    install_python_deps
    
    # Configuración
    setup_environment
    create_directories
    
    # Opcionales
    setup_docker
    setup_nginx
    
    echo
    print_success "¡Instalación completada!"
    echo
    print_status "Pasos siguientes:"
    echo "  1. Revisar y configurar variables en .env"
    echo "  2. Activar entorno virtual: source venv/bin/activate"
    echo "  3. Ejecutar aplicación: python run.py"
    echo "  4. Acceder a documentación: http://localhost:8000/docs"
    echo
    print_warning "Para producción:"
    echo "  • Configurar SSL (Let's Encrypt)"
    echo "  • Configurar base de datos PostgreSQL"
    echo "  • Configurar variables de seguridad"
    echo "  • Configurar monitoreo y logs"
    echo
}

# Ejecutar función principal
main "$@"