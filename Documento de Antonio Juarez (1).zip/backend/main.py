"""
Chalan Voice - Backend FastAPI
Sistema completo de clonación de voz con IA
"""

from fastapi import FastAPI, HTTPException, Depends, File, UploadFile, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.responses import FileResponse
from contextlib import asynccontextmanager
import os
import uvicorn
import logging
from datetime import datetime
import json
from typing import List, Optional
import shutil
import tempfile
from pathlib import Path

# Importar routers y servicios
from app.routers import voice, training, models, auth
from app.services.watermark import AudioWatermarker
from app.services.audio_processor import AudioProcessor
from app.core.config import settings
from app.core.database import init_db
from app.core.auth import create_access_token, verify_token

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('logs/chalan_voice.log'),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Gestiona el ciclo de vida de la aplicación"""
    # Startup
    logger.info("Iniciando Chalan Voice Backend...")
    
    # Crear directorios necesarios
    os.makedirs("uploads/audio", exist_ok=True)
    os.makedirs("generated/audio", exist_ok=True)
    os.makedirs("models/user_models", exist_ok=True)
    os.makedirs("logs", exist_ok=True)
    
    # Inicializar base de datos
    await init_db()
    
    # Inicializar servicios de IA
    await AudioProcessor.initialize()
    await AudioWatermarker.initialize()
    
    logger.info("Chalan Voice Backend iniciado correctamente")
    
    yield
    
    # Shutdown
    logger.info("Cerrando Chalan Voice Backend...")

# Crear aplicación FastAPI
app = FastAPI(
    title="Chalan Voice API",
    description="API para clonación de voz y síntesis de audio con IA",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan
)

# Configurar CORS para Android y frontend web
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allow_headers=["*"],
)

# Agregar routers
app.include_router(auth.router, prefix="/api/v1/auth", tags=["authentication"])
app.include_router(voice.router, prefix="/api/v1/voice", tags=["voice"])
app.include_router(training.router, prefix="/api/v1/training", tags=["training"])
app.include_router(models.router, prefix="/api/v1/models", tags=["models"])

@app.get("/")
async def root():
    """Endpoint raíz"""
    return {
        "message": "Chalan Voice API",
        "version": "1.0.0",
        "status": "active",
        "docs": "/docs",
        "redoc": "/redoc"
    }

@app.get("/health")
async def health_check():
    """Verificación de salud del sistema"""
    return {
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "services": {
            "ai_models": "active",
            "watermarking": "active",
            "database": "active"
        }
    }

@app.get("/api/v1/info")
async def api_info():
    """Información sobre la API"""
    return {
        "name": "Chalan Voice API",
        "version": "1.0.0",
        "supported_languages": settings.SUPPORTED_LANGUAGES,
        "max_audio_duration": settings.MAX_AUDIO_DURATION,
        "supported_audio_formats": ["wav", "mp3", "m4a"],
        "features": [
            "voice_cloning",
            "emotion_transfer",
            "multilingual_synthesis",
            "acoustic_watermarking",
            "jwt_authentication"
        ]
    }

if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )