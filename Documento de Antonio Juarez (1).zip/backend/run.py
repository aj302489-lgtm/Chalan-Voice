"""
Script de inicio para desarrollo del backend Chalan Voice
"""

import os
import sys
import asyncio
from pathlib import Path

# Agregar el directorio raíz al path
sys.path.insert(0, str(Path(__file__).parent))

from main import app
import uvicorn
from app.core.config import settings

def check_dependencies():
    """Verificar dependencias críticas"""
    try:
        import torch
        import torchaudio
        import transformers
        print(f"✅ PyTorch: {torch.__version__}")
        print(f"✅ CUDA disponible: {torch.cuda.is_available()}")
        if torch.cuda.is_available():
            print(f"✅ GPU: {torch.cuda.get_device_name(0)}")
        
        import fastapi
        import TTS
        print(f"✅ FastAPI: {fastapi.__version__}")
        print(f"✅ TTS: {TTS.__version__}")
        
    except ImportError as e:
        print(f"❌ Error de dependencia: {e}")
        print("Ejecutar: pip install -r requirements.txt")
        return False
    
    return True

def setup_environment():
    """Configurar entorno de desarrollo"""
    # Crear directorios si no existen
    directories = [
        "uploads/audio",
        "generated/audio", 
        "models/user_models",
        "logs",
        "temp"
    ]
    
    for directory in directories:
        Path(directory).mkdir(parents=True, exist_ok=True)
    
    # Verificar archivo .env
    env_file = Path(".env")
    if not env_file.exists():
        print("⚠️  Archivo .env no encontrado")
        print("Copiando .env.example...")
        import shutil
        shutil.copy(".env.example", ".env")
        print("✅ Archivo .env creado. Revisar configuraciones.")
    
    print("✅ Entorno configurado")

async def initialize_database():
    """Inicializar base de datos"""
    try:
        from app.core.database import init_db
        await init_db()
        print("✅ Base de datos inicializada")
    except Exception as e:
        print(f"❌ Error inicializando DB: {e}")

def main():
    """Función principal"""
    print("🚀 Chalan Voice Backend - Inicio")
    print("=" * 50)
    
    # Verificar dependencias
    if not check_dependencies():
        sys.exit(1)
    
    # Configurar entorno
    setup_environment()
    
    # Inicializar base de datos
    try:
        asyncio.run(initialize_database())
    except Exception as e:
        print(f"⚠️  Error DB (continuando): {e}")
    
    # Configuración de servidor
    host = os.getenv("HOST", "0.0.0.0")
    port = int(os.getenv("PORT", "8000"))
    debug = os.getenv("DEBUG", "true").lower() == "true"
    
    print(f"\n🌐 Servidor iniciando en:")
    print(f"   • Host: {host}")
    print(f"   • Puerto: {port}")
    print(f"   • Debug: {debug}")
    print(f"   • Documentación: http://{host}:{port}/docs")
    print(f"   • API Info: http://{host}:{port}/api/v1/info")
    print(f"   • Health: http://{host}:{port}/health")
    
    # Iniciar servidor
    uvicorn.run(
        "main:app",
        host=host,
        port=port,
        reload=debug,
        log_level="info" if debug else "warning",
        access_log=debug
    )

if __name__ == "__main__":
    main()