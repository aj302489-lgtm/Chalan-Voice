"""
Archivo de pruebas básicas para verificar el funcionamiento del backend
"""

import sys
from pathlib import Path

# Agregar path del proyecto
sys.path.insert(0, str(Path(__file__).parent))

def test_imports():
    """Test básico de imports"""
    try:
        from app.core.config import settings
        from app.core.auth import create_access_token
        from app.schemas.models import UserCreate, EmotionType
        print("✅ Imports básicos funcionando")
    except Exception as e:
        print(f"❌ Error en imports: {e}")
        raise

def test_config():
    """Test de configuración"""
    try:
        from app.core.config import settings
        assert settings.APP_NAME == "Chalan Voice API"
        assert settings.SAMPLE_RATE == 24000
        assert len(settings.SUPPORTED_LANGUAGES) > 0
        print("✅ Configuración válida")
    except Exception as e:
        print(f"❌ Error en configuración: {e}")
        raise

def test_schemas():
    """Test de esquemas Pydantic"""
    try:
        from app.schemas.models import UserCreate, EmotionType
        
        # Test UserCreate
        user_data = UserCreate(
            email="test@example.com",
            password="testpass123",
            name="Test User"
        )
        assert user_data.email == "test@example.com"
        
        # Test EmotionType
        assert EmotionType.neutral == "neutral"
        assert EmotionType.happy == "happy"
        
        print("✅ Esquemas funcionando")
    except Exception as e:
        print(f"❌ Error en esquemas: {e}")
        raise

def test_auth():
    """Test de autenticación JWT"""
    try:
        from app.core.auth import create_access_token, verify_password, get_password_hash
        
        # Test password hashing
        password = "testpassword123"
        hashed = get_password_hash(password)
        assert verify_password(password, hashed)
        assert not verify_password("wrongpassword", hashed)
        
        # Test token creation
        token = create_access_token({"sub": "test_user", "email": "test@example.com"})
        assert isinstance(token, str)
        assert len(token) > 0
        
        print("✅ Autenticación funcionando")
    except Exception as e:
        print(f"❌ Error en autenticación: {e}")
        raise

if __name__ == "__main__":
    print("🧪 Ejecutando tests básicos de Chalan Voice Backend")
    print("=" * 50)
    
    tests = [
        test_imports,
        test_config,
        test_schemas,
        test_auth
    ]
    
    passed = 0
    failed = 0
    
    for test in tests:
        try:
            test()
            passed += 1
        except Exception as e:
            print(f"❌ {test.__name__} falló: {e}")
            failed += 1
    
    print("\n" + "=" * 50)
    print(f"📊 Resultados: {passed}✅ {failed}❌")
    
    if failed == 0:
        print("🎉 Todos los tests pasaron correctamente!")
        print("\n🚀 El backend está listo para usar:")
        print("   python run.py")
        print("   http://localhost:8000/docs")
    else:
        print("⚠️  Algunos tests fallaron. Revisar configuración.")
        sys.exit(1)