# 📚 Chalan Voice - Índice de Documentación

## 🎯 Documentación Principal

### 📖 README Principal
- **Archivo**: [`README.md`](../README.md)
- **Descripción**: Documentación principal del proyecto
- **Contenido**: 
  - Descripción general del proyecto
  - Características principales
  - Instrucciones paso a paso para compilar APK
  - Instrucciones para desplegar el backend
  - Requisitos del sistema
  - Configuración de desarrollo
  - Políticas éticas
  - Guía de contribución

### 📄 Licencia
- **Archivo**: [`LICENSE`](../LICENSE)
- **Descripción**: Licencia MIT con cláusulas éticas
- **Contenido**:
  - Licencia MIT estándar
  - Aviso de uso ético
  - Restricciones y responsabilidades del usuario

## 🏗️ Documentación Técnica

### Backend
- **Archivo**: [`backend/README.md`](../backend/README.md)
- **Descripción**: Documentación técnica completa del backend
- **Contenido**:
  - Arquitectura del sistema
  - Instalación y configuración
  - Guía de despliegue (Docker, Cloud)
  - Referencia completa de la API
  - Modelos de IA integrados
  - Sistema de watermarking
  - Configuración de base de datos
  - Seguridad y autenticación
  - Monitoreo y logs
  - Resolución de problemas

### Android App
- **Archivo**: [`android-app/README.md`](../android-app/README.md)
- **Descripción**: Documentación técnica de la aplicación Android
- **Contenido**:
  - Arquitectura de la aplicación (MVVM, Hilt)
  - Configuración de desarrollo
  - Guía completa de compilación y build
  - Estructura del proyecto
  - APIs y servicios
  - Permisos y seguridad
  - Interfaz de usuario (Jetpack Compose)
  - Testing y QA
  - Distribución (Google Play Store)
  - Troubleshooting

## 🔌 Documentación de API

### API Reference
- **Archivo**: [`docs/api.md`](../docs/api.md)
- **Descripción**: Documentación completa de la API
- **Contenido**:
  - Introducción y autenticación
  - Referencia completa de endpoints
  - Modelos de datos detallados
  - Códigos de error y manejo
  - Rate limiting
  - Ejemplos de uso en múltiples lenguajes
  - WebSockets
  - SDKs oficiales y comunitarios

### Ejemplos de Android
- **Archivo**: [`docs/examples.md`](../docs/examples.md)
- **Descripción**: Ejemplos completos de implementación Android
- **Contenido**:
  - Configuración básica del cliente
  - Implementación de autenticación
  - Grabación y subida de audio
  - Generación de TTS
  - Entrenamiento de modelos
  - Casos de uso completos
  - Manejo de errores
  - Optimizaciones

## ⚙️ Configuración y Deployment

### Variables de Entorno
- **Archivo**: [`.env.example`](../.env.example)
- **Descripción**: Plantilla completa de variables de entorno
- **Contenido**:
  - Configuración base y seguridad
  - Configuración de base de datos
  - Parámetros de audio y modelos de IA
  - Watermarking
  - CORS y acceso
  - Storage y archivos
  - Logging y monitoreo
  - Configuración de email
  - Cache y Redis
  - Docker y producción
  - Features flags

### CI/CD Pipeline
- **Archivo**: [`.github/workflows/ci-cd.yml`](../.github/workflows/ci-cd.yml)
- **Descripción**: Configuración completa de CI/CD
- **Contenido**:
  - Testing automático (Python y Android)
  - Security scanning
  - Docker build y push
  - Despliegue a staging
  - Despliegue a producción
  - Despliegue a Google Play Store
  - Notificaciones

### Fastlane para Android
- **Archivo**: [`android-app/fastlane/Fastfile`](../android-app/fastlane/Fastfile)
- **Descripción**: Configuración de Fastlane para Android
- **Contenido**:
  - Lanes de testing
  - Lanes de build
  - Control de calidad
  - Despliegue a Play Store
  - Utilidades de desarrollo
  - Manejo de errores

### Docker Compose Development
- **Archivo**: [`docker-compose.dev.yml`](../docker-compose.dev.yml)
- **Descripción**: Configuración completa para desarrollo
- **Contenido**:
  - API de desarrollo
  - Base de datos PostgreSQL
  - Redis para cache
  - MinIO para storage
  - Frontend development server
  - Monitoring (Prometheus, Grafana)
  - Testing tools (Selenium)
  - Jupyter notebook
  - Logging stack (ELK)

## 📁 Estructura de Documentación

```
chalan-voice/
├── README.md                          # Documentación principal
├── LICENSE                            # Licencia MIT
├── .env.example                       # Variables de entorno
├── .github/workflows/ci-cd.yml        # CI/CD pipeline
├── docker-compose.dev.yml            # Docker compose desarrollo
│
├── backend/
│   ├── README.md                     # Documentación backend
│   ├── main.py                       # Punto de entrada
│   ├── requirements.txt              # Dependencias
│   ├── Dockerfile                    # Imagen Docker
│   ├── docker-compose.yml            # Docker compose producción
│   ├── app/                          # Código fuente
│   │   ├── core/                     # Configuración y auth
│   │   ├── routers/                  # Endpoints API
│   │   ├── services/                 # Servicios IA
│   │   └── schemas/                  # Modelos Pydantic
│   └── uploads/                      # Archivos subidos
│
├── android-app/
│   ├── README.md                     # Documentación Android
│   ├── app/build.gradle              # Configuración build
│   ├── app/src/main/                 # Código fuente
│   │   ├── java/com/chalanvoice/     # Kotlin code
│   │   └── res/                      # Recursos
│   ├── fastlane/Fastfile            # Fastlane config
│   └── gradle/                       # Gradle wrapper
│
└── docs/
    ├── api.md                        # Documentación API
    └── examples.md                   # Ejemplos Android
```

## 🚀 Guía de Uso Rápido

### Para Desarrolladores Backend

1. **Configuración inicial**:
   ```bash
   git clone <repo-url>
   cd chalan-voice/backend
   pip install -r requirements.txt
   cp .env.example .env
   ```

2. **Ejecución en desarrollo**:
   ```bash
   python main.py
   ```

3. **Docker development**:
   ```bash
   docker-compose -f docker-compose.dev.yml up
   ```

### Para Desarrolladores Android

1. **Configuración**:
   ```bash
   git clone <repo-url>
   cd chalan-voice/android-app
   # Abrir en Android Studio
   ```

2. **Build APK**:
   ```bash
   ./gradlew assembleDebug
   ```

3. **Release APK**:
   ```bash
   ./gradlew assembleRelease
   ```

### Para DevOps

1. **CI/CD**:
   - Configurar `.github/workflows/ci-cd.yml`
   - Configurar secretos necesarios

2. **Despliegue**:
   - Usar `docker-compose.yml` para producción
   - Usar `docker-compose.dev.yml` para desarrollo

## 📞 Soporte y Recursos

### Documentación Adicional
- **API Interactive**: http://localhost:8000/docs (cuando el servidor esté ejecutándose)
- **Troubleshooting**: Consultar secciones específicas en cada README
- **Issues**: Crear issue en GitHub

### Herramientas de Desarrollo
- **Fastlane**: Automatización de builds Android
- **Docker**: Containerización
- **GitHub Actions**: CI/CD
- **Prometheus/Grafana**: Monitoreo

### Contacto
- **Email**: soporte@chalantech.com
- **GitHub**: [Issues y Pull Requests](https://github.com/tu-usuario/chalan-voice)

---

**Chalan Voice** - Documentación completa y profesional 📚✨

*Esta documentación está diseñada para desarrolladores, DevOps, testers y cualquier persona interesada en contribuir al proyecto.*