# Mejores prácticas de arquitectura Android con Jetpack Compose: MVVM, estado, navegación, audio y seguridad

## Resumen ejecutivo

El modo de construir aplicaciones Android ha cambiado de forma profunda con Jetpack Compose. La combinación de una UI declarative, un modelo de estado explícito y un ecosistema moderno de librerías (ViewModel, Navigation Compose, Security, Lifecycle-aware APIs) habilita arquitecturas más simples, predecibles y testables. Este informe técnico sintetiza mejores prácticas oficiales y guías pragmáticas para: adoptar MVVM en Compose con Única Fuente de Verdad (SSOT) y Flujo de Datos Unidireccional (UDF), manejar permisos de micrófono y capturar audio con MediaRecorder cumpliendo las restricciones de plataforma, elegir entre EncryptedSharedPreferences y DataStore para secretos y preferencias, estructurar proyectos y Gradle para escalabilidad y modularidad, diseñar un UiState robusto en ViewModel y recolectarlo de forma lifecycle-aware, y diseñar navegación con arguments tipados, deep links y grafos anidados sin acoplar NavController a la UI[^1][^2][^3][^4][^5][^6].

Conclusiones clave:
- Arquitectura: MVVM en Compose se implementa de forma natural si la UI es stateless, el ViewModel expone UiState inmutable y maneja eventos, y los repositorios (SSOT) encapsulan fuentes de datos y exponen Flow. El UDF se materializa en un canal claro de arriba hacia abajo para el estado y de abajo hacia arriba para los eventos[^1][^2][^18][^20][^21].
- Permisos y audio: declarar RECORD_AUDIO no basta; el flujo correcto distingue estados (concedido, justificación, denegado permanente) y utiliza APIs lifecycle-aware. La captura con MediaRecorder requiere secuencia y liberación ordenada, y servicio en primer plano a partir de Android 9 cuando corresponda[^4][^24][^26].
- Seguridad de almacenamiento: EncryptedSharedPreferences sigue siendo viable para secretos pequeños, pero la librería security-crypto ha sido deprecada; para preferencias y secretos robustos, DataStore con cifrado a medida y migración planificada es una alternativa moderna. Validar siempre versiones y estado de soporte oficial antes de fijar versiones finales[^10][^27][^28][^11].
- Proyecto y builds: estructurar por features con módulos core (network, ui, common) reduce acoplamientos y acelera builds. Usar Version Catalog, centralizar versiones y evitar repositorios no confiables. Compose requiere habilitar el plugin y declarar dependencias explícitas, y seguir convenciones de Gradle para modularización[^12][^13][^14][^29].
- Estado y ViewModel: UiState como sealed class o data class, StateFlow con stateIn(WhileSubscribed(5000)), recolección en UI con collectAsStateWithLifecycle, remember para estado transitorio y rememberSaveable para persistir lo esencial. Hoisting de estado a la mínima jerarquía útil y derivar estados cuando sea necesario[^2][^5][^22][^32][^33][^34].
- Navegación: definir un grafo con argumentos tipados, no pasar objetos complejos; usar deep links para URLs/acciones y grafos anidados para modularidad; desacoplar navegación de Composables vía callbacks; probar con TestNavHostController y CI[^3][^23][^35][^36][^38].

Mapa del informe: cada sección evoluciona desde fundamentos hacia implementación, con tablas comparativas, flujos recomendados y un caso integrador de “Grabación segura” que sintetiza todos los temas en un ejemplo coherente.

## Fundamentos: MVVM para Jetpack Compose y principios rectores

Compose y MVVM se complementan de forma orgánica. En este enfoque, la UI (Compose) es la “vista” declarativa; el ViewModel es el contenedor de estado y lógica de presentación, y los repositorios (capa de datos) son la SSOT que exponen Flow e instrumentos para ejecutar acciones. El UDF guía el flujo del estado desde el ViewModel hacia la UI y el retorno de eventos desde la UI hacia el ViewModel. Esta separación reduce el acoplamiento y hace la aplicación más testable y mantenible[^1][^2][^18][^20][^21].

El principio SSOT garantiza que un tipo de dato tenga un único propietario con capacidad de mutación, lo que simplifica el razonamiento sobre consistencia y errores. En apps modernas, la UI se “impulsa por modelos” persistentes y la arquitectura se diseña en capas (UI, dominio opcional, datos), con coroutines y Flow como mecanismos de comunicación y concurrencia estructurada[^1][^2].

Para situar responsabilidades y límites, la siguiente tabla resume las capas, su rol y riesgos si se mezclan funciones.

Para ilustrar la separación de responsabilidades, la Tabla 1 resume propósito, componentes y riesgos de acoplamiento indebido.

Tabla 1. Capas y responsabilidades

| Capa            | Responsabilidad principal                                      | Componentes típicos                                      | Riesgos si se mezcla                               |
|-----------------|-----------------------------------------------------------------|-----------------------------------------------------------|----------------------------------------------------|
| UI (Presentación) | Renderizar estado y capturar eventos                           | Composables, State holders/ViewModels                    | Lógica de negocio dispersa; difícil de probar      |
| Dominio (opcional) | Reutilizar lógica compleja y orquestar casos de uso           | Use Cases/Interactors                                     | Acceder a Context/Android; romper aislamiento      |
| Datos           | Exponer datos, resolver conflictos, contener lógica de negocio | Repositorios, fuentes (DB, red, archivo, DataStore)       | Exponer detalles a UI; filtrar modelos a UI        |

La modularización por features y módulos core suele acompañar este diseño, promoviendo escalabilidad y aislamiento.

### Separación de responsabilidades y modularización

Diseñar límites claros entre UI, dominio y datos aporta mantenibilidad y testabilidad. Para proyectos pequeños, la estructura por capas puede ser suficiente; para equipos grandes o productos con múltiples características, la arquitectura por features es ventajosa: cada feature contiene su propia presentación, dominio y datos, con un módulo shared/core para utilidades comunes[^1][^16]. Esta separación reduce la deuda técnica y acota el impacto de cambios, al tiempo que permite políticas de visibilidad (api/implementation) que evitan fugas de dependencias.

### SSOT, UDF y concurrencia

La Única Fuente de Verdad y el Flujo de Datos Unidireccional se refuerzan mutuamente. SSOT centraliza la mutación y expone estados inmutables, evitando cascadas de cambios difícil de rastrear; UDF canaliza estado hacia la UI y eventos de vuelta al propietario. En la capa de UI, recolectar StateFlow de forma lifecycle-aware (collectAsStateWithLifecycle) evita fugas, recomposiciones innecesarias y bloqueos del hilo principal. El ViewModel debe ser main-safe, delegando trabajo pesado a coroutines y suspend functions, y estructurando su scope para cancelar tareas al desaparecer el alcance[^2][^6][^32].

## Estado de UI y ViewModel: diseño, preservación y recolección

Un UiState bien diseñado distingue datos, cargas, errores y señales de UX. Puede modelarse con sealed classes (cuando los estados son excluyentes) o data classes (cuando son combinables). El ViewModel expone StateFlow y operaciones para mutate; la UI observa con collectAsStateWithLifecycle y dispara eventos para aplicar cambios, cerrando el bucle UDF[^2][^6][^22][^32].

El almacenamiento del estado en Compose exige decidir dónde conservarlo:
- remember: mantiene el estado en memoria mientras dure la composición.
- rememberSaveable: persiste en Bundle, útil para entradas del usuario y estados de UI que deben sobrevivir a cambios de configuración y muerte del proceso iniciada por el sistema.
- ViewModel: maneja estado de presentación con cambios de configuración, pero no persiste tras muerte de proceso; SavedStateHandle complementa para esa persistencia[^5][^24][^25][^23].

Para clarificar, la siguiente comparativa sintetiza objetivos, persistencia y usos.

Tabla 2. Mecanismos de preservación de estado

| Mecanismo            | Propósito principal                 | Persistencia                          | Casos de uso recomendados                                      |
|---------------------|-------------------------------------|---------------------------------------|-----------------------------------------------------------------|
| remember            | Estado transitorio en Composable    | No persiste                           | Estado local, controles de UI simples                           |
| rememberSaveable    | Estado de UI esencial               | Bundle (cambios config y muerte proceso) | Entrada de usuario, scroll de listas, selecciones en curso      |
| ViewModel           | Lógica y estado de presentación     | Memoria (cambios config)              | UiState complejo, orquestación de flujos, cálculos               |
| SavedStateHandle    | Persistencia de estado de UI en VM  | Bundle (muerte de proceso)            | Restaurar ID o navegación tras muerte de proceso iniciada por el sistema |

La diferencia de alcance es crítica para evitar bugs y experiencias deficientes. Por ejemplo, restaurar una entrada tras rotar el dispositivo se resuelve con rememberSaveable; reconstruir un estado tras volver a abrir la app desde recientes puede requerir SavedStateHandle y/o un repositorio persistente[^5][^24][^23].

Además, no toda lógica de UI debe residir en Composables. State holders simples pueden encapsular detalles y exponer lambdas, manteniendo Composables Stateless y más reutilizables[^2][^18].

Para convertir observables a State de Compose de forma segura, la Tabla 3 resume opciones y dependencias.

Tabla 3. Conversión a State de Compose

| Observable        | Conversión recomendada                         | Dependencia                             | Observaciones clave                        |
|-------------------|-----------------------------------------------|------------------------------------------|--------------------------------------------|
| StateFlow/Flow    | collectAsStateWithLifecycle                    | lifecycle-runtime-compose                | Lifecycle-aware; evita fugas y recomposiciones[^22][^32] |
| LiveData          | observeAsState                                  | runtime-livedata                        | Útil en bases de código con LiveData[^2]   |
| RxJava2/3         | subscribeAsState                                | runtime-rxjava2/3                        | Según versión de Rx                         |

La regla práctica: elevar el estado al ancestro común más bajo donde se lee y, al menos, al nivel donde se cambia. Si dos estados cambian en respuesta a los mismos eventos, elevarlos juntos para evitar divergencias[^2][^34].

### Diseño del UiState y exposición desde ViewModel

El ViewModel debe exponer UiState como StateFlow inmutable y proporcionar funciones para procesar eventos (acciones del usuario). Si el UiState proviene de repositorios, el operador stateIn con política WhileSubscribed(5000) estabiliza el flujo y evita suscripciones cortas que complican la UI. La inmutabilidad y el uso de sealed classes simplifican razonamiento y testing[^2][^6].

### Persistencia del estado y restauración

No todo estado merece persistencia. Preserve entradas esenciales, posición de scroll y selecciones activas para una UX sólida; delegue en repositorios para datos duraderos. SavedStateHandle complementa ViewModel con acceso al Bundle cuando el sistema mata el proceso. Decisiones erradas aquí pueden generar pérdida de datos o开销 excesivo por sobreuso del Bundle[^5][^24][^25][^23].

## Permisos de micrófono y manejo de audio en Android (MediaRecorder)

El acceso al micrófono exige permisos “peligrosos” (dangerous), solicitados en tiempo de ejecución, y un flujo de UX que reconozca justificaciones y denegaciones permanentes. Compose simplifica la integración con APIs de permisos y lifecycle-aware para pedir y reevaluar permisos al volver a primer plano. Un diseño cuidadoso evita estados inconsistentes y fricciones con el usuario[^7][^26].

### Solicitud de permisos en runtime (Compose)

En Jetpack Compose, el manejo de permisos se organiza alrededor de estados como granted, shouldShowRationale y permanentlyDenied. Librerías como Accompanist Permissions exponenrememberMultiplePermissionsState y permiten lanzar solicitudes, además de construir diálogos contextuales cuando procede. Reevaluar permisos en onStart (lifecycle-aware) garantiza que la app responda a cambios hechos por el usuario en Ajustes mientras la app estaba en segundo plano[^7][^26].

Para clarificar transiciones, la Tabla 4 resume el flujo de estados y acciones.

Tabla 4. Flujo de estados de permiso y transiciones

| Estado                | Qué indica                                | Acción del sistema            | Acción del usuario                 | Respuesta recomendada                              |
|-----------------------|--------------------------------------------|-------------------------------|------------------------------------|----------------------------------------------------|
| isGranted            | Permiso concedido                         | Solicitud aprobada            | —                                  | Proceder con captura                               |
| shouldShowRationale  | Necesaria justificación tras negación      | Solicitud postergada          | Acepta o niega                     | Mostrar diálogo explicativo y volver a pedir       |
| permanentlyDenied    | Denegado y no mostrable nuevamente        | Solicitud no se muestra       | Ir a Ajustes de la app             | Navegar a ajustes con guía clara                   |

La experiencia de usuario mejora si los mensajes son precisos y breves, vinculados a la tarea en curso (grabar una nota de voz, iniciar una videollamada), y si se evitan solicitudes fuera de contexto[^7][^26].

### Captura y reproducción de audio con MediaRecorder

MediaRecorder proporciona una API estable para capturar audio desde el micrófono y guardarlo en un archivo para su reproducción con MediaPlayer. El proceso requiere configurar la fuente de audio, el formato de salida, el codificador y el archivo destino, y liberar recursos de manera ordenada. Desde Android 9 (API 28), las aplicaciones en segundo plano no pueden acceder al micrófono; para grabación en segundo plano, se debe usar un servicio en primer plano con notificación persistente[^4].

Tabla 5. Fuentes de audio y casos de uso

| Fuente             | Uso principal                                 | Consideraciones                                         |
|--------------------|-----------------------------------------------|---------------------------------------------------------|
| MIC                | Captura estándar del micrófono                | AGC/ruido pueden aplicarse; suficiente para voz         |
| VOICE_RECOGNITION  | Reconocimiento de voz                         | Menos procesamiento; buena para exactitud               |
| UNPROCESSED        | Audio bruto sin procesamiento                 | Verificar soporte con AudioManager; no siempre disponible |

Tabla 6. Secuencia de uso de MediaRecorder

| Paso                | API                        | Errores comunes                          | Mitigaciones                                     |
|---------------------|----------------------------|-------------------------------------------|--------------------------------------------------|
| Configurar          | setAudioSource, setOutputFormat, setAudioEncoder, setOutputFile | prepare() falla por rutas o permisos | Validar ruta y permisos; try/catch y logs        |
| Iniciar             | start()                    | IllegalStateException                     | Asegurar orden y liberar en onStop               |
| Detener             | stop()                     | —                                         | Cerrar y liberar inmediatamente                  |
| Liberar             | release()                  | Recurso aún retenido                      | Liberar en onStop y onDestroy                    |
| Reproducir (opcional) | MediaPlayer.setDataSource, prepare, start | IOException al preparar                  | Manejar excepciones y validar archivo            |

Ejemplo de configuración (Kotlin):

```kotlin
private fun startRecording() {
    recorder = MediaRecorder().apply {
        setAudioSource(MediaRecorder.AudioSource.MIC)
        setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP)
        setOutputFile(fileName)
        setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB)
        try { prepare() } catch (e: IOException) { Log.e(LOG_TAG, "prepare() failed", e) }
        start()
    }
}

private fun stopRecording() {
    recorder?.apply { stop(); release() }
    recorder = null
}
```

Para escenarios en segundo plano, el servicio en primer plano comunica claramente al usuario que la grabación está activa, respeta políticas de plataforma y evita rechazos en revisión o bloqueos de SO[^4].

#### Restringir captura en segundo plano y servicios en primer plano

A partir de Android 9, las apps en segundo plano no pueden acceder al micrófono; cualquier grabación debe estar vinculada a una Activity visible o un servicio en primer plano con notificación. Diseñar el flujo para cumplir este requisito evita fallos de funcionalidad y rechazos en publicación[^4].

## Almacenamiento seguro: EncryptedSharedPreferences vs DataStore

EncryptedSharedPreferences es un envoltorio cifrado sobre SharedPreferences que protege claves y valores mediante MasterKey y esquemas como AES256_SIV para claves y AES256_GCM para valores. Se orienta a secretos pequeños como tokens de acceso, y su integración con PreferenceFragmentCompat permite reutilizar pantallas de preferencias con cifrado transparente[^27]. Sin embargo, la librería security-crypto ha sido deprecada, lo que exige evaluar alternativas y validar versiones actuales y roadmap antes de decidir su uso en producción[^28].

DataStore, como reemplazo moderno de SharedPreferences, ofrece APIs más seguras y conscientes del ciclo de vida, con posibilidad de incorporar cifrado personalizado y migraciones controladas. En proyectos reales, se han observado incidentes de estabilidad con EncryptedSharedPreferences que motivaron migraciones a DataStore cifrado para mejorar fiabilidad, especialmente ante reinicialización de claves y restauración de backups en ciertos dispositivos[^10]. Un enfoque pragmático consiste en evaluar el perfil de datos (tamaño, latencia, concurrencia), riesgos operativos y soporte oficial vigente; y en caso de migrar, planificar la estrategia y pruebas de restauración.

Tabla 7. Comparativa de almacenamiento seguro

| Opción                     | Pros                                        | Contras / Riesgos                               | Casos de uso                        | Observaciones                          |
|---------------------------|---------------------------------------------|-------------------------------------------------|-------------------------------------|----------------------------------------|
| EncryptedSharedPreferences | Simple; cifrado transparente; MasterKey     | Librería security-crypto deprecada; incidentes en algunos dispositivos | Secretos pequeños y locales         | Validar soporte y versiones[^10][^28]  |
| DataStore (cifrado custom) | Moderno; lifecycle-aware; migración flexible | Cifrado propio requiere cuidado; pruebas de restauración | Preferencias y secretos robustos    | Revisar estado de soporte y roadmap[^10] |

Nota sobre brechas de información: el estado deprecatorio de security-crypto y detalles exactos de su deprecación deben revisarse en la página oficial de releases de Jetpack Security, y las versiones más recientes confirmar en el momento de implementación. También es recomendable validar el roadmap y estado de DataStore en proyectos donde se requiera cifrado fuerte y migración de preferencias encriptadas.

#### Cuándo usar cada opción

EncryptedSharedPreferences sigue siendo razonable para secretos pequeños y locales si el soporte oficial es adecuado; DataStore es preferible para preferencias robustas, migración desde preferencias no cifradas y necesidad de resiliencia en entornos con variabilidad de dispositivos. En ambos casos, gestionar errores de restauración y claves maestras es esencial; evitar almacenar secretos innecesarios, limitar exposición y programar pruebas de restauración y reversión[^10][^27].

## Estructura de proyecto Android Studio y Gradle con Compose

La estructura de un proyecto Compose debe favorecer escalabilidad, modularidad y tiempos de compilación cortos. Dos enfoques predominan: por capas y por features. El enfoque por capas agrupa data, domain y presentation en la raíz; el enfoque por features organiza módulos feature-*, cada uno con sus propias capas y un módulo shared/core para utilidades comunes. En equipos grandes, el segundo suele escalar mejor y reducir conflictos de merge[^16].

En builds, Gradle recomienda separar en múltiples módulos y aprovechar paralelización y evitación de trabajo. Usar Version Catalog (libs.versions.toml) para gestionar versiones centralizadas, y configurar repositories seguros y confiables. Compose requiere habilitar el plugin compose y declarar dependencias específicas; conviene seguir la guía de setup oficial y artículos técnicos para asegurar coherencia y tooling[^12][^13][^14][^29].

Tabla 8. Dependencias Compose y propósito

| Grupo:artefacto                          | Propósito                                 | Uso principal                             |
|------------------------------------------|-------------------------------------------|-------------------------------------------|
| androidx.compose.ui:ui                   | Núcleo de Compose                          | Text, Button, Column                       |
| androidx.compose.material3:material3     | Material Design 3                          | Componentes con tema Material You         |
| androidx.compose.ui:ui-tooling-preview   | Preview en Android Studio                  | Vista previa de Composables                |
| androidx.lifecycle:lifecycle-runtime-ktx | Lifecycle-aware para Compose               | ViewModel, collectAsStateWithLifecycle     |
| androidx.activity:activity-compose       | Integrar Activity con Compose              | setContent con Compose                     |
| androidx.compose.ui:ui-test-junit4       | Pruebas UI Compose                         | ComposeTestRule                            |
| androidx.compose.ui:ui-tooling           | Inspección y depuración                    | Debug tooling                              |
| androidx.navigation:navigation-compose   | Navegación Compose                         | NavHost, NavController                     |

Tabla 9. Capas vs Features: pros y contras

| Enfoque        | Pros                                        | Contras                                     | Adecuado para            |
|----------------|---------------------------------------------|---------------------------------------------|--------------------------|
| Por capas      | Sencillo; claridad inicial                   | Paquetes grandes; límites difusos en apps grandes | Proyectos pequeños/medianos |
| Por features   | Escalabilidad; módulos independientes       | Curva de mantenimiento de módulos           | Equipos grandes/productos complejos |

### Gestión de dependencias y Version Catalog

Centralizar versiones en libs.versions.toml evita inconsistencias y facilita upgrades. La política de visibilidad api vs implementation controla la exposición de dependencias entre módulos: apipropaga a consumidores; implementationoculta y acelera builds. Evitar repositorios no confiables y definir repositoriesMode para estabilidad de sincronización[^29].

## Navegación en Compose: diseño tipado, deep links y pruebas

Navigation Compose organiza la navegación en un grafo con NavController y NavHost, y soporta arguments entre destinos, deep links (URLs, acciones, tipos MIME) y grafos anidados. La interoperabilidad con Views puede realizarse con Navigation basado en Fragments. La buena práctica es no acoplar NavController a Composables: exponer callbacks y mantener la lógica de navegación testeable. Para pruebas, TestNavHostController y ComposeNavigator permiten verificar rutas, transiciones y argumentos sin depender de detalles de UI[^3][^23][^35][^36].

Para modelar argumentos, la Tabla 10 resume tipos soportados y recomendaciones.

Tabla 10. Tipos de argumentos y seguridad

| Tipo              | Soporte        | Uso recomendado                         |
|-------------------|----------------|------------------------------------------|
| Int, Long, Boolean, String | Sí             | IDs, flags, textos simples               |
| Parcelable        | Sí             | Objetos planos complejos (con cautela)   |

La recomendación oficial es pasar solo datos mínimos (p. ej., un ID) y recuperar objetos complejos desde la SSOT (repositorios) a partir de ese ID. Evitar Pasar objetos grandes por argumentos reduce errores y costos de serialización/deserialización[^3][^23][^36].

Tabla 11. Deep links: interno vs externo

| Tipo             | Configuración clave                   | Caso de uso                         |
|------------------|----------------------------------------|-------------------------------------|
| Interno          | deepLinks en composable()              | Navegación dentro de la app         |
| Externo          | intent-filters en manifest             | Abrir la app desde URL/acción       |

TestNavHostController permite emular y verificar rutas y argumentos; en CI, las pruebas de navegación actúan como regresión para evitar reapariciones de bugs y inconsistencias en el grafo[^3][^35].

### Manejo seguro de argumentos y SSOT

Modelar argumentos como data classes tipados evita casts y reduce errores; la UI debe recibir IDs y derivar estados para recuperación de datos desde repositorios. Los eventos de navegación deben elevarse y procesarse en el ViewModel para preservar UDF y mantenibilidad[^3][^2].

### Interoperabilidad y pruebas

En apps mixtas (Compose + Views), usar Navigation con Fragments como contenedores reduce acoplamientos. En Compose puro, TestNavHostController simplifica assertions sobre la ruta actual y la integridad de argumentos. Evitar múltiples NavControllers, navegar desde scopes incorrectos o manipular backstack indebidamente son anti-patrones frecuentes que conviene vigilar[^35][^38].

## Pruebas y aseguramiento de calidad

La calidad se sustenta en pruebas unitarias de ViewModel (incluyendo StateFlow), pruebas de repositorios y fuentes de datos, y pruebas de navegación Compose. En UI, ComposeTestRule facilita interacciones y verificaciones; StateRestorationTester permite validar conservación de estado. Preferir fakes a mocks reduce fragilidad y acerca el test a comportamiento real. En flows, afirmar sobre value y manejar coleccion jobs con políticas como WhileSubscribed evita condiciones de carrera y valores stale[^9][^39][^5].

Tabla 12. Matriz de pruebas

| Módulo       | Objetivo                          | Tipo de prueba           | Herramientas                             |
|--------------|-----------------------------------|--------------------------|------------------------------------------|
| ViewModel    | UiState, eventos, coroutines      | Unit                     | JUnit, kotlinx-coroutines-test           |
| Repositorios | SSOT, mapping, errores            | Unit/Integration         | JUnit, fakes/mocks                       |
| Navegación   | Rutas, argumentos, backstack      | UI (Compose)             | TestNavHostController, ComposeNavigator  |
| UI Compose   | Renderizado, interacciones        | UI                       | ComposeTestRule, StateRestorationTester  |

## Caso integrador: “Grabación segura” (Compose + MVVM + permisos + audio + navegación)

Este caso sintetiza arquitectura, permisos, captura, seguridad y navegación.

Navegación:
- Ruta de lista de grabaciones: “/recordings”.
- Ruta de detalle: “/recordings/{id}”, con argumento tipado (String o Long).
- Pantalla principal: “/recorder”, con controles de grabar/parar y deep link opcional para abrir desde una URL externa[^3].

UiState y ViewModel:
- RecorderUiState sealed class: Idle, Recording, Paused, Error(message), RecordedFile(path), PermissionDenied.
- RecorderViewModel expone StateFlow<RecorderUiState> y eventos: startRecording(), stopRecording(), requestPermission(), openRecording(id), onDismissError(). Al iniciar, solicita permisos; al grabar, usa MediaRecorder con ruta segura (por ejemplo, en cache externo) y libera recursos en onStop; al detener, persiste metadatos y notifica a la UI[^2][^4][^5].

Permisos:
- Encapsular flujo de permisos con Accompanist Permissions; estados y mensajes claros; reevaluar en onStart; mostrar justificación cuando shouldShowRationale y guiar a Ajustes si permanentlyDenied[^7][^26].

Audio:
- Secuencia MediaRecorder con try/catch y liberación en onStop; servicio en primer plano para casos en segundo plano desde Android 9; errores de prepare/start capturados y mapeados a RecorderUiState.Error[^4].

Seguridad:
- Preferir DataStore cifrado para preferencias persistentes (configuración, tokens). Si se usa EncryptedSharedPreferences, validar estado de soporte y planificar migración a DataStore si hay incidentes; registrar eventos de seguridad y errores de restauración[^10][^28][^11][^27].

Para cerrar, la siguiente tabla resume los estados del caso, eventos disparadores y transiciones.

Tabla 13. Estados del caso y transiciones

| Estado              | Evento disparador              | Acción ViewModel/Repositorio         | Transición a               | Prueba clave                                      |
|---------------------|--------------------------------|--------------------------------------|----------------------------|---------------------------------------------------|
| Idle                | requestPermission()            | Solicitar RECORD_AUDIO               | PermissionDenied/Idle      | Verificar mensaje/justificación en UI[^7][^26]    |
| PermissionDenied    | abrirAjustes()                 | —                                    | Idle (tras volver)         | Validar reevaluación al volver a onStart          |
| Idle                | startRecording()               | Inicializar MediaRecorder            | Recording                  | Comprobar secuencia de prepare/start[^4]          |
| Recording           | stopRecording()                | stop()+release(); guardar metadatos  | RecordedFile               | Assert ruta y persistencia                        |
| RecordedFile        | openRecording(id)              | Recuperar por ID (SSOT)              | —                          | Validar navegación tipada y recuperación[^3]      |
| Recording/Idle      | errorOccurred()                | Mapear excepción a Error             | Error                      | UI muestra mensaje; prueba de restauración[^5]    |

Este flujo demuestra cómo UDF, permisos, captura y seguridad operan en conjunto sin exponer dependencias Android en el ViewModel, y cómo la navegación tipada reduce errores al navegar entre pantallas[^1][^2][^3][^4][^5][^7][^10].

## Recomendaciones finales y checklist de adopción

Adoptar Compose con MVVM requiere disciplina arquitectónica y operativa. El checklist siguiente prioriza decisiones clave y mitigaciones.

Tabla 14. Checklist de implementación

| Ítem                                               | Prioridad | Referencia         | Estado     | Responsable |
|----------------------------------------------------|-----------|--------------------|------------|------------|
| Adoptar UDF y SSOT; UI stateless                   | Alta      | [^1][^2][^21]      | —          | —          |
| Diseñar UiState (sealed/data); StateFlow + stateIn | Alta      | [^2][^6]           | —          | —          |
| Recolección lifecycle-aware (collectAsStateWithLifecycle) | Alta   | [^22][^32]         | —          | —          |
|remember vs rememberSaveable; SavedStateHandle     | Alta      | [^5][^24][^25]     | —          | —          |
| Permisos: flujo completo (justificación, ajustes) | Alta      | [^7][^26]          | —          | —          |
| MediaRecorder: secuencia y servicio en foreground  | Alta      | [^4]               | —          | —          |
| Seguridad: evaluar EncryptedSharedPreferences vs DataStore | Alta | [^10][^28][^11] | —          | —          |
| Modularización por features + core                 | Media     | [^16][^13][^29]    | —          | —          |
| Version Catalog y repositorios confiables          | Media     | [^29]              | —          | —          |
| Navegación tipada, deep links, grafos anidados     | Media     | [^3][^23][^36]     | —          | —          |
| Pruebas: ViewModel, navegación, restauración       | Alta      | [^9][^35][^5]      | —          | —          |

Riesgos y mitigaciones:
- Obsolescencia de librerías: revisar releases y validar versiones final-stable (p. ej., security-crypto deprecada).
- Errores de permisos en segundo plano: respetar servicio en primer plano y reevaluar permisos al volver a primer plano.
- Persistencia excesiva en Bundle: limitar a lo esencial para UX; delegar en repositorios para datos duraderos.
- Deep links inseguros: validar URLs, argumentos y esquema; limitar impacto de argumentos malformados.

Brechas de información conocidas:
- Verificar el estado deprecatorio exacto de security-crypto y su roadmap en la página oficial de Jetpack Security antes de decidir.
- Confirmar versiones final-stable de Compose, Navigation y Accompanist en el momento de implementación (fijar en libs.versions.toml y documentar).
- Profundizar en cifrado con DataStore y estrategias de migración desde EncryptedSharedPreferences (incluyendo manejo de claves y restauración).
- Ampliar pruebas en CI/CD específicas de Compose Navigation y casos de restauración de estado con StateRestorationTester.
- Lineamientos sobre audio de baja latencia y fuentes de audio sin procesar (UNPROCESSED) más allá de MediaRecorder.

---

## Referencias

[^1]: Guía de arquitectura de aplicaciones — Android Developers. https://developer.android.com/topic/architecture  
[^2]: Estado y Jetpack Compose — Android Developers. https://developer.android.com/develop/ui/compose/state  
[^3]: Navegación con Compose — Android Developers. https://developer.android.com/develop/ui/compose/navigation  
[^4]: MediaRecorder overview — Android Developers. https://developer.android.com/media/platform/mediarecorder  
[^5]: Guardar estado de UI en Compose — Android Developers. https://developer.android.com/develop/ui/compose/state-saving  
[^6]: Recomendaciones de arquitectura — Android Developers. https://developer.android.com/topic/architecture/recommendations  
[^7]: Manejo de permisos en Kotlin con Jetpack Compose — Medium (Kabi). https://kabi20.medium.com/permission-handling-in-kotlin-using-jetpack-compose-198a5ba7ebc4  
[^8]: Guía moderna de estructuras de paquetes Android — Medium (Kliment Jonceski). https://medium.com/@kliment.jonceski/a-guide-to-modern-android-project-package-structures-3a9bb385307d  
[^9]: Pruebas en Jetpack Compose — Android Developers. https://developer.android.com/develop/ui/compose/testing  
[^10]: De EncryptedSharedPreferences a Secure DataStore — Medium (Malik Saif). https://medium.com/@maliksaif070/from-encryptedsharedpreferences-to-secure-datastore-in-jetpack-compose-my-real-world-shift-9f3a6f3c57b2  
[^11]: Asegura los datos de tu app Android con EncryptedSharedPreferences — Medium (Moraneus). https://medium.com/@moraneus/secure-your-android-apps-data-with-encryptedsharedpreferences-7091da539f5e  
[^12]: Estructura de builds Android — Android Developers. https://developer.android.com/build/android-build-structure  
[^13]: Mejores prácticas para estructurar builds — Gradle. https://docs.gradle.org/current/userguide/best_practices_structuring_builds.html  
[^14]: Configuración inicial de Jetpack Compose — Android Developers. https://developer.android.com/develop/ui/compose/setup  
[^15]: Seguridad en apps Android — ProAndroidDev. https://proandroiddev.com/securing-user-data-in-android-tips-and-techniques-1b584fd5a14a  
[^16]: ViewModel — Android Developers. https://developer.android.com/topic/libraries/architecture/viewmodel  
[^17]: Capa de datos (Data layer) — Android Developers. https://developer.android.com/jetpack/guide/data-layer  
[^18]: Capa de UI (Ui layer) — Android Developers. https://developer.android.com/topic/architecture/ui-layer  
[^19]: Consumir Flows de forma segura en Compose — Medium (Android Developers). https://medium.com/androiddevelopers/consuming-flows-safely-in-jetpack-compose-cde014d0d5a3  
[^20]: Una forma más segura de recolectar Flows en UIs Android — Medium (Android Developers). https://medium.com/androiddevelopers/a-safer-way-to-collect-flows-from-android-uis-23080b1f8bda  
[^21]: Colección StateFlow como State con lifecycle — Android Developers (API reference). https://developer.android.com/reference/kotlin/androidx/lifecycle/compose/package-summary#(kotlinx.coroutines.flow.StateFlow).collectAsStateWithLifecycle(androidx.lifecycle.LifecycleOwner,androidx.lifecycle.Lifecycle.State,kotlin.coroutines.CoroutineContext)  
[^22]: Capa de UI — State holders y UiState — Android Developers. https://developer.android.com/topic/architecture/ui-layer/stateholders  
[^23]: SavedStateHandle — Android Developers. https://developer.android.com/reference/androidx/lifecycle/SavedStateHandle  
[^24]: Guardar estados (UI dismissal system) — Android Developers. https://developer.android.com/topic/libraries/architecture/saving-states#ui-dismissal-system  
[^25]: Parcelize — Android Developers. https://developer.android.com/kotlin/parcelize  
[^26]: Solicitar permisos en runtime — Android Developers. https://developer.android.com/guide/topics/permissions/requesting  
[^27]: EncryptedSharedPreferences — Android Developers (Reference). https://developer.android.com/reference/androidx/security/crypto/EncryptedSharedPreferences  
[^28]: Seguridad (Jetpack) — Lanzamientos — Android Developers. https://developer.android.com/jetpack/androidx/releases/security  
[^29]: Configurar Gradle: guía definitiva — ProAndroidDev. https://proandroiddev.com/how-to-configure-gradle-the-ultimate-guide-06dfb4eaa92d  
[^30]: Common pitfalls in Jetpack Compose navigation — ProAndroidDev. https://proandroiddev.com/common-pitfalls-in-jetpack-compose-navigation-571aa115c5f2  
[^31]: Testing de navegación — Android Developers. https://developer.android.com/guide/navigation/navigation-testing  
[^32]: TestNavHostController — Android Developers (Reference). https://developer.android.com/reference/kotlin/androidx/navigation/testing/TestNavHostController  
[^33]: Qué probar (Testing fundamentals) — Android Developers. https://developer.android.com/training/testing/fundamentals/what-to-test  
[^34]: StateRestorationTester — Android Developers (Reference). https://developer.android.com/reference/kotlin/androidx/compose/ui/test/junit4/StateRestorationTester  
[^35]: Compose samples — GitHub (Android). https://github.com/android/compose-samples  
[^36]: Now in Android — GitHub (Android). https://github.com/android/nowinandroid