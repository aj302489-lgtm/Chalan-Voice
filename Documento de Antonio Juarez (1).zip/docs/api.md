# 🔌 Chalan Voice - API Documentation

## 📋 Índice

1. [Introducción](#introducción)
2. [Autenticación](#autenticación)
3. [Endpoints](#endpoints)
4. [Modelos de Datos](#modelos-de-datos)
5. [Códigos de Error](#códigos-de-error)
6. [Rate Limiting](#rate-limiting)
7. [Ejemplos de Uso](#ejemplos-de-uso)
8. [WebSockets](#websockets)
9. [SDKs y Clientes](#sdks-y-clientes)

## 🚀 Introducción

### Base URL

```text
Production: https://api.chalanvoice.com
Staging: https://staging-api.chalanvoice.com
Development: http://localhost:8000
```

### Headers Requeridos

```http
Content-Type: application/json
Authorization: Bearer {access_token}
Accept: application/json
User-Agent: ChalanVoice-Android/1.0.0
```

### Versión de API

- **Versión actual**: v1.0
- **URL base**: `/api/v1/`
- **Última actualización**: 2025-01-01

### Formatos de Respuesta

#### Respuesta Exitosa
```json
{
  "success": true,
  "data": { ... },
  "message": "Operación exitosa",
  "timestamp": "2025-01-01T00:00:00Z"
}
```

#### Respuesta de Error
```json
{
  "success": false,
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Los datos proporcionados no son válidos",
    "details": {
      "field": "email",
      "reason": "Formato de email inválido"
    }
  },
  "timestamp": "2025-01-01T00:00:00Z"
}
```

## 🔐 Autenticación

### Registro de Usuario

```http
POST /api/v1/auth/register
Content-Type: application/json

{
  "email": "usuario@example.com",
  "password": "secure_password_123",
  "name": "Usuario Prueba"
}
```

**Parámetros:**
- `email` (string, requerido): Email válido del usuario
- `password` (string, requerido): Mínimo 8 caracteres
- `name` (string, requerido): Nombre completo

**Respuesta:**
```json
{
  "success": true,
  "data": {
    "id": "uuid-string",
    "email": "usuario@example.com",
    "name": "Usuario Prueba",
    "created_at": "2025-01-01T00:00:00Z"
  },
  "message": "Usuario registrado exitosamente"
}
```

### Inicio de Sesión

```http
POST /api/v1/auth/login
Content-Type: application/json

{
  "email": "usuario@example.com",
  "password": "secure_password_123"
}
```

**Respuesta:**
```json
{
  "success": true,
  "data": {
    "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "token_type": "bearer",
    "expires_in": 3600,
    "refresh_token": "refresh_token_here",
    "user": {
      "id": "uuid-string",
      "email": "usuario@example.com",
      "name": "Usuario Prueba"
    }
  }
}
```

### Renovación de Token

```http
POST /api/v1/auth/refresh
Content-Type: application/json

{
  "refresh_token": "refresh_token_here"
}
```

### Obtener Usuario Actual

```http
GET /api/v1/auth/me
Authorization: Bearer {access_token}
```

**Respuesta:**
```json
{
  "success": true,
  "data": {
    "id": "uuid-string",
    "email": "usuario@example.com",
    "name": "Usuario Prueba",
    "created_at": "2025-01-01T00:00:00Z",
    "last_login": "2025-01-01T00:00:00Z"
  }
}
```

### Cerrar Sesión

```http
POST /api/v1/auth/logout
Authorization: Bearer {access_token}
```

## 📞 Endpoints

### 🗣️ Endpoints de Voz

#### Subir Muestra de Voz

```http
POST /api/v1/voice/upload-voice
Authorization: Bearer {access_token}
Content-Type: multipart/form-data

file: [archivo_audio]
emotion: "neutral"  # optional
```

**Parámetros:**
- `file` (file, requerido): Archivo de audio (WAV, MP3, M4A)
- `emotion` (string, opcional): neutral, happy, sad, angry, surprised

**Restricciones:**
- Tamaño máximo: 50MB
- Duración máxima: 5 minutos
- Formatos soportados: WAV, MP3, M4A

**Respuesta:**
```json
{
  "success": true,
  "data": {
    "id": "voice_sample_id",
    "filename": "muestra_voz.wav",
    "duration": 5.2,
    "format": "wav",
    "file_size": 1024000,
    "upload_time": "2025-01-01T00:00:00Z",
    "emotion": "neutral"
  }
}
```

#### Generar Síntesis de Voz

```http
POST /api/v1/voice/generate
Authorization: Bearer {access_token}
Content-Type: application/json

{
  "text": "Hola, este es mi texto sintetizado",
  "voice_sample_id": "voice_sample_id",
  "emotion": "happy",
  "language": "es",
  "model": "xtts_v2"  # xtts_v2, bark, tortoise
}
```

**Parámetros:**
- `text` (string, requerido): Texto a sintetizar (máximo 1000 caracteres)
- `voice_sample_id` (string, requerido): ID de muestra de voz
- `emotion` (string, opcional): neutral, happy, sad, angry, surprised
- `language` (string, requerido): Código de idioma (es, en, fr, de, etc.)
- `model` (string, opcional): xtts_v2 (default), bark, tortoise

**Respuesta:**
```json
{
  "success": true,
  "data": {
    "id": "generation_id",
    "status": "processing",
    "text": "Hola, este es mi texto sintetizado",
    "voice_sample_id": "voice_sample_id",
    "emotion": "happy",
    "language": "es",
    "model": "xtts_v2",
    "estimated_time": 30,
    "created_at": "2025-01-01T00:00:00Z"
  }
}
```

#### Obtener Estado de Generación

```http
GET /api/v1/voice/status/{generation_id}
Authorization: Bearer {access_token}
```

**Respuesta:**
```json
{
  "success": true,
  "data": {
    "id": "generation_id",
    "status": "completed",  # processing, completed, failed
    "progress": 100,
    "file_path": "generated/audio/generation_id.wav",
    "file_size": 2048000,
    "duration": 8.5,
    "created_at": "2025-01-01T00:00:00Z",
    "completed_at": "2025-01-01T00:00:35Z"
  }
}
```

#### Descargar Audio Generado

```http
GET /api/v1/voice/download/{generation_id}
Authorization: Bearer {access_token}
```

**Respuesta:**
- **Content-Type**: `audio/wav`
- **Content-Disposition**: `attachment; filename="synthesis.wav"`

#### Listar Generaciones del Usuario

```http
GET /api/v1/voice/generations?page=1&limit=20&status=all
Authorization: Bearer {access_token}
```

**Parámetros de consulta:**
- `page` (integer, opcional): Número de página (default: 1)
- `limit` (integer, opcional): Elementos por página (default: 20, max: 100)
- `status` (string, opcional): all, processing, completed, failed

**Respuesta:**
```json
{
  "success": true,
  "data": {
    "generations": [
      {
        "id": "generation_id",
        "text": "Hola mundo",
        "status": "completed",
        "duration": 5.2,
        "language": "es",
        "emotion": "neutral",
        "created_at": "2025-01-01T00:00:00Z"
      }
    ],
    "pagination": {
      "page": 1,
      "limit": 20,
      "total": 45,
      "pages": 3
    }
  }
}
```

### 🎓 Endpoints de Entrenamiento

#### Iniciar Entrenamiento

```http
POST /api/v1/training/train
Authorization: Bearer {access_token}
Content-Type: application/json

{
  "voice_sample_ids": ["sample1", "sample2", "sample3"],
  "model_name": "Mi_Voz_Personalizada",
  "language": "es",
  "epochs": 100,
  "batch_size": 16
}
```

**Parámetros:**
- `voice_sample_ids` (array, requerido): Array de IDs de muestras de voz
- `model_name` (string, requerido): Nombre del modelo personalizado
- `language` (string, requerido): Código de idioma
- `epochs` (integer, opcional): Número de épocas (default: 100)
- `batch_size` (integer, opcional): Tamaño de lote (default: 16)

**Respuesta:**
```json
{
  "success": true,
  "data": {
    "id": "training_id",
    "status": "starting",
    "model_name": "Mi_Voz_Personalizada",
    "language": "es",
    "voice_sample_count": 3,
    "estimated_duration": 3600,  # en segundos
    "created_at": "2025-01-01T00:00:00Z"
  }
}
```

#### Obtener Estado de Entrenamiento

```http
GET /api/v1/training/status/{training_id}
Authorization: Bearer {access_token}
```

**Respuesta:**
```json
{
  "success": true,
  "data": {
    "id": "training_id",
    "status": "training",  # pending, training, completed, failed
    "progress": 45,
    "current_epoch": 45,
    "total_epochs": 100,
    "loss": 0.234,
    "model_path": "models/user_models/training_id/",
    "estimated_completion": "2025-01-01T01:00:00Z"
  }
}
```

#### Listar Modelos del Usuario

```http
GET /api/v1/training/models
Authorization: Bearer {access_token}
```

**Respuesta:**
```json
{
  "success": true,
  "data": {
    "models": [
      {
        "id": "model_id",
        "name": "Mi_Voz_Personalizada",
        "language": "es",
        "status": "completed",
        "accuracy": 0.95,
        "training_time": 3600,
        "created_at": "2025-01-01T00:00:00Z"
      }
    ]
  }
}
```

### 📊 Endpoints de Información

#### Health Check

```http
GET /health
```

**Respuesta:**
```json
{
  "status": "healthy",
  "timestamp": "2025-01-01T00:00:00Z",
  "version": "1.0.0",
  "services": {
    "ai_models": "active",
    "watermarking": "active",
    "database": "active",
    "storage": "active"
  }
}
```

#### Información de la API

```http
GET /api/v1/info
```

**Respuesta:**
```json
{
  "success": true,
  "data": {
    "name": "Chalan Voice API",
    "version": "1.0.0",
    "supported_languages": [
      "es", "en", "fr", "de", "it", "pt", "ru", "zh", "ja", "ko"
    ],
    "supported_audio_formats": ["wav", "mp3", "m4a"],
    "max_upload_size": 52428800,  # bytes
    "max_audio_duration": 300,    # segundos
    "max_text_length": 1000,
    "features": [
      "voice_cloning",
      "emotion_transfer",
      "multilingual_synthesis",
      "acoustic_watermarking",
      "model_training"
    ]
  }
}
```

#### Estadísticas del Usuario

```http
GET /api/v1/user/stats
Authorization: Bearer {access_token}
```

**Respuesta:**
```json
{
  "success": true,
  "data": {
    "total_generations": 25,
    "total_training_time": 3600,
    "storage_used": 52428800,  # bytes
    "favorite_language": "es",
    "recent_activity": [
      {
        "type": "generation",
        "description": "Generó audio en español",
        "timestamp": "2025-01-01T00:00:00Z"
      }
    ]
  }
}
```

## 📋 Modelos de Datos

### User Model

```json
{
  "id": "string (UUID)",
  "email": "string (email format)",
  "name": "string",
  "created_at": "string (ISO 8601)",
  "last_login": "string (ISO 8601)",
  "is_active": "boolean"
}
```

### VoiceSample Model

```json
{
  "id": "string (UUID)",
  "user_id": "string (UUID)",
  "filename": "string",
  "file_path": "string",
  "duration": "number (float, seconds)",
  "format": "string (wav|mp3|m4a)",
  "file_size": "number (bytes)",
  "emotion": "string (neutral|happy|sad|angry|surprised)",
  "upload_time": "string (ISO 8601)"
}
```

### AudioGeneration Model

```json
{
  "id": "string (UUID)",
  "user_id": "string (UUID)",
  "voice_sample_id": "string (UUID)",
  "text": "string",
  "emotion": "string",
  "language": "string (ISO 639-1)",
  "model": "string (xtts_v2|bark|tortoise)",
  "status": "string (processing|completed|failed)",
  "file_path": "string",
  "duration": "number (float, seconds)",
  "file_size": "number (bytes)",
  "progress": "number (0-100)",
  "created_at": "string (ISO 8601)",
  "completed_at": "string (ISO 8601)"
}
```

### TrainedModel Model

```json
{
  "id": "string (UUID)",
  "user_id": "string (UUID)",
  "name": "string",
  "language": "string (ISO 639-1)",
  "voice_sample_ids": "array[string]",
  "status": "string (pending|training|completed|failed)",
  "accuracy": "number (0-1)",
  "training_time": "number (seconds)",
  "model_path": "string",
  "created_at": "string (ISO 8601)",
  "completed_at": "string (ISO 8601)"
}
```

### Error Model

```json
{
  "success": "boolean",
  "error": {
    "code": "string",
    "message": "string",
    "details": "object"
  },
  "timestamp": "string (ISO 8601)"
}
```

## ⚠️ Códigos de Error

### HTTP Status Codes

| Código | Descripción | Uso |
|--------|-------------|-----|
| `200` | OK | Operación exitosa |
| `201` | Created | Recurso creado exitosamente |
| `400` | Bad Request | Datos inválidos |
| `401` | Unauthorized | Token inválido o expirado |
| `403` | Forbidden | Sin permisos |
| `404` | Not Found | Recurso no encontrado |
| `429` | Too Many Requests | Rate limit excedido |
| `500` | Internal Server Error | Error del servidor |

### Error Codes

#### Autenticación
- `AUTH_001`: Token inválido
- `AUTH_002`: Token expirado
- `AUTH_003`: Refresh token inválido
- `AUTH_004`: Usuario no encontrado

#### Validación
- `VALID_001`: Email inválido
- `VALID_002`: Password muy débil
- `VALID_003`: Archivo no válido
- `VALID_004`: Texto muy largo

#### Recursos
- `RES_001`: Muestra de voz no encontrada
- `RES_002`: Generación no encontrada
- `RES_003`: Modelo no encontrado

#### Procesamiento
- `PROC_001`: Error al procesar audio
- `PROC_002`: Modelo no disponible
- `PROC_003`: Memoria insuficiente
- `PROC_004`: Timeout de procesamiento

#### Rate Limiting
- `RATE_001`: Límite de requests excedido
- `RATE_002`: Límite de almacenamiento excedido
- `RATE_003`: Límite de generaciones excedido

## 🚦 Rate Limiting

### Límites por Endpoint

| Endpoint | Límite | Ventana |
|----------|--------|---------|
| POST /auth/login | 10 | 1 minuto |
| POST /voice/generate | 5 | 1 minuto |
| POST /voice/upload | 20 | 1 hora |
| POST /training/train | 3 | 1 día |
| GET /voice/status | 100 | 1 minuto |

### Headers de Rate Limiting

```http
X-RateLimit-Limit: 5
X-RateLimit-Remaining: 3
X-RateLimit-Reset: 1640995200
X-RateLimit-Window: 60
```

### Response cuando se excede

```json
{
  "success": false,
  "error": {
    "code": "RATE_001",
    "message": "Rate limit exceeded. Try again in 45 seconds.",
    "details": {
      "limit": 5,
      "window": 60,
      "retry_after": 45
    }
  }
}
```

## 💻 Ejemplos de Uso

### Python Client

```python
import requests
import json

class ChalanVoiceClient:
    def __init__(self, base_url, access_token=None):
        self.base_url = base_url
        self.access_token = access_token
        self.session = requests.Session()
        
        if access_token:
            self.session.headers.update({
                'Authorization': f'Bearer {access_token}'
            })
    
    def login(self, email, password):
        response = self.session.post(
            f"{self.base_url}/api/v1/auth/login",
            json={"email": email, "password": password}
        )
        response.raise_for_status()
        data = response.json()
        self.access_token = data['data']['access_token']
        self.session.headers.update({
            'Authorization': f'Bearer {self.access_token}'
        })
        return data
    
    def upload_voice_sample(self, file_path, emotion="neutral"):
        with open(file_path, 'rb') as f:
            files = {'file': f}
            data = {'emotion': emotion}
            response = self.session.post(
                f"{self.base_url}/api/v1/voice/upload-voice",
                files=files,
                data=data
            )
            response.raise_for_status()
            return response.json()
    
    def generate_audio(self, text, voice_sample_id, emotion="neutral", language="es"):
        payload = {
            "text": text,
            "voice_sample_id": voice_sample_id,
            "emotion": emotion,
            "language": language
        }
        response = self.session.post(
            f"{self.base_url}/api/v1/voice/generate",
            json=payload
        )
        response.raise_for_status()
        return response.json()
    
    def get_generation_status(self, generation_id):
        response = self.session.get(
            f"{self.base_url}/api/v1/voice/status/{generation_id}"
        )
        response.raise_for_status()
        return response.json()
    
    def download_audio(self, generation_id, output_path):
        response = self.session.get(
            f"{self.base_url}/api/v1/voice/download/{generation_id}"
        )
        response.raise_for_status()
        
        with open(output_path, 'wb') as f:
            f.write(response.content)
        
        return output_path

# Uso del cliente
client = ChalanVoiceClient("https://api.chalanvoice.com")

# Login
client.login("usuario@example.com", "password123")

# Subir muestra de voz
upload_result = client.upload_voice_sample("muestra_voz.wav")
voice_sample_id = upload_result['data']['id']

# Generar audio
generation_result = client.generate_audio(
    "Hola, este es un test",
    voice_sample_id,
    emotion="happy"
)
generation_id = generation_result['data']['id']

# Esperar y descargar
import time
while True:
    status = client.get_generation_status(generation_id)
    if status['data']['status'] == 'completed':
        break
    time.sleep(5)

client.download_audio(generation_id, "output.wav")
```

### JavaScript/Node.js Client

```javascript
const axios = require('axios');
const FormData = require('form-data');
const fs = require('fs');

class ChalanVoiceClient {
    constructor(baseUrl, accessToken = null) {
        this.baseUrl = baseUrl;
        this.accessToken = accessToken;
        this.client = axios.create({
            baseURL: baseUrl,
            headers: accessToken ? {
                'Authorization': `Bearer ${accessToken}`
            } : {}
        });
    }
    
    async login(email, password) {
        const response = await this.client.post('/api/v1/auth/login', {
            email,
            password
        });
        
        this.accessToken = response.data.data.access_token;
        this.client.defaults.headers.Authorization = `Bearer ${this.accessToken}`;
        
        return response.data;
    }
    
    async uploadVoiceSample(filePath, emotion = 'neutral') {
        const form = new FormData();
        form.append('file', fs.createReadStream(filePath));
        form.append('emotion', emotion);
        
        const response = await this.client.post('/api/v1/voice/upload-voice', form, {
            headers: form.getHeaders()
        });
        
        return response.data;
    }
    
    async generateAudio(text, voiceSampleId, emotion = 'neutral', language = 'es') {
        const payload = {
            text,
            voice_sample_id: voiceSampleId,
            emotion,
            language
        };
        
        const response = await this.client.post('/api/v1/voice/generate', payload);
        return response.data;
    }
    
    async getGenerationStatus(generationId) {
        const response = await this.client.get(`/api/v1/voice/status/${generationId}`);
        return response.data;
    }
    
    async downloadAudio(generationId, outputPath) {
        const response = await this.client.get(`/api/v1/voice/download/${generationId}`, {
            responseType: 'stream'
        });
        
        const writer = fs.createWriteStream(outputPath);
        response.data.pipe(writer);
        
        return new Promise((resolve, reject) => {
            writer.on('finish', resolve);
            writer.on('error', reject);
        });
    }
}

// Uso del cliente
async function main() {
    const client = new ChalanVoiceClient('https://api.chalanvoice.com');
    
    try {
        // Login
        await client.login('usuario@example.com', 'password123');
        
        // Subir muestra de voz
        const uploadResult = await client.uploadVoiceSample('muestra_voz.wav');
        const voiceSampleId = uploadResult.data.id;
        
        // Generar audio
        const generationResult = await client.generateAudio(
            'Hola, este es un test',
            voiceSampleId,
            'happy'
        );
        const generationId = generationResult.data.id;
        
        // Esperar completado
        while (true) {
            const status = await client.getGenerationStatus(generationId);
            if (status.data.status === 'completed') break;
            await new Promise(resolve => setTimeout(resolve, 5000));
        }
        
        // Descargar
        await client.downloadAudio(generationId, 'output.wav');
        console.log('Audio generado exitosamente!');
        
    } catch (error) {
        console.error('Error:', error.response?.data || error.message);
    }
}

main();
```

### cURL Examples

```bash
# Login
curl -X POST https://api.chalanvoice.com/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email": "usuario@example.com", "password": "password123"}'

# Subir muestra de voz
curl -X POST https://api.chalanvoice.com/api/v1/voice/upload-voice \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN" \
  -F "file=@muestra_voz.wav" \
  -F "emotion=neutral"

# Generar audio
curl -X POST https://api.chalanvoice.com/api/v1/voice/generate \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "text": "Hola, este es un test",
    "voice_sample_id": "SAMPLE_ID",
    "emotion": "happy",
    "language": "es"
  }'

# Descargar audio
curl -X GET https://api.chalanvoice.com/api/v1/voice/download/GENERATION_ID \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN" \
  -o output.wav
```

## 🔄 WebSockets

### Conexión WebSocket

```javascript
const socket = new WebSocket('wss://api.chalanvoice.com/ws?token=YOUR_ACCESS_TOKEN');

socket.onopen = function(event) {
    console.log('WebSocket conectado');
};

socket.onmessage = function(event) {
    const data = JSON.parse(event.data);
    console.log('Mensaje recibido:', data);
    
    // Manejar actualizaciones de estado
    if (data.type === 'generation_update') {
        console.log(`Progreso: ${data.progress}%`);
    }
};

// Suscribirse a actualizaciones de generación
socket.send(JSON.stringify({
    action: 'subscribe',
    event: 'generation_progress',
    generation_id: 'GENERATION_ID'
}));
```

### Eventos WebSocket

#### generation_progress
```json
{
  "type": "generation_progress",
  "generation_id": "generation_id",
  "progress": 65,
  "status": "processing",
  "estimated_time_remaining": 15
}
```

#### training_update
```json
{
  "type": "training_update",
  "training_id": "training_id",
  "progress": 30,
  "current_epoch": 30,
  "total_epochs": 100,
  "loss": 0.234
}
```

## 🛠️ SDKs y Clientes

### Oficial

- **Python SDK**: [chalanvoice-python](https://pypi.org/project/chalanvoice/)
- **JavaScript SDK**: [chalanvoice-js](https://npmjs.com/package/chalanvoice)
- **Android Library**: Incluida en la app oficial

### Community

- **Ruby SDK**: [chalanvoice-ruby](https://rubygems.org/gems/chalanvoice)
- **PHP SDK**: [chalanvoice-php](https://packagist.org/packages/chalanvoice/php)
- **Go SDK**: [chalanvoice-go](https://github.com/chalanvoice/go-sdk)

---

**Chalan Voice API** - Documentación completa v1.0 🔌📚

*Para soporte técnico, consulta la [documentación principal](../README.md) o abre un issue en GitHub.*