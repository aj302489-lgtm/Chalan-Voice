# 📱 Chalan Voice - Ejemplos de Llamadas desde Android

## 📋 Índice

1. [Configuración Básica](#configuración-básica)
2. [Autenticación](#autenticación)
3. [Grabación y Subida de Audio](#grabación-y-subida-de-audio)
4. [Generación de TTS](#generación-de-tts)
5. [Entrenamiento de Modelos](#entrenamiento-de-modelos)
6. [Casos de Uso Completos](#casos-de-uso-completos)
7. [Manejo de Errores](#manejo-de-errores)
8. [Optimizaciones](#optimizaciones)

## ⚙️ Configuración Básica

### Cliente API Principal

```kotlin
@Module
@InstallIn(SingletonComponent::class)
object NetworkModule {
    
    @Provides
    @Singleton
    fun provideOkHttp(): OkHttpClient {
        val loggingInterceptor = HttpLoggingInterceptor().apply {
            level = if (BuildConfig.DEBUG) {
                HttpLoggingInterceptor.Level.BODY
            } else {
                HttpLoggingInterceptor.Level.NONE
            }
        }
        
        return OkHttpClient.Builder()
            .addInterceptor(loggingInterceptor)
            .addInterceptor(AuthInterceptor())
            .addInterceptor(ErrorInterceptor())
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .writeTimeout(60, TimeUnit.SECONDS)
            .build()
    }
    
    @Provides
    @Singleton
    fun provideRetrofit(okHttpClient: OkHttpClient): Retrofit {
        return Retrofit.Builder()
            .baseUrl(BuildConfig.API_BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(Json.asConverterFactory("application/json".toMediaType()))
            .addCallAdapterFactory(RetrofitResultCallAdapterFactory())
            .build()
    }
}

// Auth Interceptor para agregar token automáticamente
class AuthInterceptor @Inject constructor(
    private val tokenManager: AuthTokenManager
) : Interceptor {
    
    override fun intercept(chain: Interceptor.Chain): Response {
        val originalRequest = chain.request()
        
        val token = tokenManager.getToken()
        return if (token != null && tokenManager.isTokenValid()) {
            val newRequest = originalRequest.newBuilder()
                .header("Authorization", "Bearer $token")
                .build()
            chain.proceed(newRequest)
        } else {
            chain.proceed(originalRequest)
        }
    }
}
```

### Modelos de Datos

```kotlin
// Modelos de request/response
@Serializable
data class LoginRequest(
    val email: String,
    val password: String
)

@Serializable
data class LoginResponse(
    val access_token: String,
    val token_type: String,
    val expires_in: Int,
    val user: User
)

@Serializable
data class VoiceUploadRequest(
    val emotion: String = "neutral"
)

@Serializable
data class VoiceUploadResponse(
    val id: String,
    val filename: String,
    val duration: Float,
    val format: String,
    val uploadTime: String
)

@Serializable
data class TtsGenerationRequest(
    val text: String,
    val voice_sample_id: String,
    val emotion: String = "neutral",
    val language: String = "es",
    val model: String = "xtts_v2"
)

@Serializable
data class TtsGenerationResponse(
    val id: String,
    val status: String,
    val text: String,
    val emotion: String,
    val language: String,
    val estimated_time: Int
)

@Serializable
data class GenerationStatusResponse(
    val id: String,
    val status: String,
    val progress: Int,
    val file_path: String?,
    val file_size: Long?,
    val duration: Float?
)
```

## 🔐 Autenticación

### Login Flow Completo

```kotlin
@Singleton
class AuthRepository @Inject constructor(
    private val authApiService: AuthApiService,
    private val tokenManager: AuthTokenManager,
    private val encryptedPrefs: SharedPreferences
) {
    
    suspend fun login(email: String, password: String): Resource<LoginResponse> {
        return safeApiCall {
            val request = LoginRequest(email, password)
            val response = authApiService.login(request)
            
            // Guardar token
            val expiryTime = System.currentTimeMillis() + (response.expires_in * 1000)
            tokenManager.saveToken(response.access_token, expiryTime)
            
            response
        }
    }
    
    suspend fun register(
        name: String, 
        email: String, 
        password: String
    ): Resource<RegisterResponse> {
        return safeApiCall {
            val request = RegisterRequest(name, email, password)
            authApiService.register(request)
        }
    }
    
    suspend fun getCurrentUser(): Resource<User> {
        return safeApiCall {
            authApiService.getCurrentUser()
        }
    }
    
    suspend fun logout() {
        tokenManager.clearToken()
        
        // Opcional: invalidate token en servidor
        try {
            authApiService.logout()
        } catch (e: Exception) {
            // Log error pero no bloquear logout local
            Log.w("AuthRepository", "Error invalidating token: ${e.message}")
        }
    }
    
    fun isLoggedIn(): Boolean {
        return tokenManager.isTokenValid()
    }
}
```

### Uso en ViewModel

```kotlin
@HiltViewModel
class AuthViewModel @Inject constructor(
    private val authRepository: AuthRepository
) : ViewModel() {
    
    private val _loginState = MutableStateFlow<Resource<LoginResponse>?>(null)
    val loginState: StateFlow<Resource<LoginResponse>?> = _loginState.asStateFlow()
    
    private val _isLoggedIn = MutableStateFlow(false)
    val isLoggedIn: StateFlow<Boolean> = _isLoggedIn.asStateFlow()
    
    init {
        _isLoggedIn.value = authRepository.isLoggedIn()
    }
    
    fun login(email: String, password: String) {
        viewModelScope.launch {
            _loginState.value = Resource.Loading()
            
            val result = authRepository.login(email, password)
            
            _loginState.value = result
            
            if (result is Resource.Success) {
                _isLoggedIn.value = true
            }
        }
    }
    
    fun clearLoginState() {
        _loginState.value = null
    }
}
```

### Pantalla de Login

```kotlin
@Composable
fun LoginScreen(
    viewModel: AuthViewModel = hiltViewModel(),
    onLoginSuccess: () -> Unit,
    onNavigateToRegister: () -> Unit
) {
    val loginState by viewModel.loginState.collectAsState()
    val isLoggedIn by viewModel.isLoggedIn.collectAsState()
    
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    
    // Manejar estado de login
    LaunchedEffect(loginState) {
        when (loginState) {
            is Resource.Success -> {
                onLoginSuccess()
            }
            is Resource.Error -> {
                // Mostrar error
                Log.e("LoginScreen", "Login failed: ${(loginState as Resource.Error).exception.message}")
            }
            else -> { /* Loading state */ }
        }
    }
    
    LaunchedEffect(isLoggedIn) {
        if (isLoggedIn) {
            onLoginSuccess()
        }
    }
    
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Logo
        Image(
            painter = painterResource(id = R.drawable.ic_logo),
            contentDescription = "Logo",
            modifier = Modifier.size(120.dp)
        )
        
        Spacer(modifier = Modifier.height(32.dp))
        
        // Email field
        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("Email") },
            modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Email
            )
        )
        
        Spacer(modifier = Modifier.height(16.dp))
        
        // Password field
        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Contraseña") },
            modifier = Modifier.fillMaxWidth(),
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Password
            )
        )
        
        Spacer(modifier = Modifier.height(24.dp))
        
        // Login button
        Button(
            onClick = {
                if (email.isNotEmpty() && password.isNotEmpty()) {
                    viewModel.login(email, password)
                }
            },
            modifier = Modifier.fillMaxWidth(),
            enabled = loginState !is Resource.Loading
        ) {
            when (loginState) {
                is Resource.Loading -> {
                    CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                }
                else -> {
                    Text("Iniciar Sesión")
                }
            }
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        // Register link
        TextButton(onClick = onNavigateToRegister) {
            Text("¿No tienes cuenta? Regístrate")
        }
    }
}
```

## 🎤 Grabación y Subida de Audio

### Audio Recorder

```kotlin
@Singleton
class AudioRecorder @Inject constructor(
    @ApplicationContext private val context: Context
) {
    
    private var mediaRecorder: MediaRecorder? = null
    private var outputFile: File? = null
    private var startTime: Long = 0
    
    fun startRecording(
        onDurationUpdate: (Long) -> Unit = {}
    ): String {
        // Crear archivo temporal
        outputFile = File(context.cacheDir, "recording_${System.currentTimeMillis()}.wav")
        
        mediaRecorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            MediaRecorder(context)
        } else {
            @Suppress("DEPRECATION")
            MediaRecorder()
        }
        
        mediaRecorder?.apply {
            setAudioSource(MediaRecorder.AudioSource.MIC)
            setOutputFormat(MediaRecorder.OutputFormat.WAVE)
            setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            setAudioEncodingBitRate(128_000)
            setAudioSamplingRate(44_100)
            setOutputFile(outputFile?.absolutePath)
            
            try {
                prepare()
                start()
                startTime = System.currentTimeMillis()
                
                // Iniciar timer para updates de duración
                CoroutineScope(Dispatchers.Main).launch {
                    while (isRecording()) {
                        val currentDuration = System.currentTimeMillis() - startTime
                        onDurationUpdate(currentDuration)
                        delay(100)
                    }
                }
                
            } catch (e: IOException) {
                Log.e("AudioRecorder", "Error starting recording: ${e.message}")
                release()
            }
        }
        
        return outputFile?.absolutePath ?: ""
    }
    
    fun stopRecording(): File? {
        mediaRecorder?.apply {
            try {
                stop()
                release()
            } catch (e: RuntimeException) {
                Log.e("AudioRecorder", "Error stopping recording: ${e.message}")
            }
        }
        mediaRecorder = null
        
        return outputFile?.takeIf { it.exists() }
    }
    
    fun isRecording(): Boolean {
        return mediaRecorder != null
    }
    
    fun getCurrentDuration(): Long {
        return if (isRecording()) {
            System.currentTimeMillis() - startTime
        } else {
            0
        }
    }
}
```

### Repository de TTS con Upload

```kotlin
@Singleton
class TtsRepository @Inject constructor(
    private val ttsApiService: TtsApiService,
    private val audioRecorder: AudioRecorder
) {
    
    suspend fun uploadVoiceSample(
        file: File,
        emotion: String = "neutral"
    ): Resource<VoiceUploadResponse> {
        return safeApiCall {
            val requestFile = file.asRequestBody("audio/wav".toMediaType())
            val multipartFile = MultipartBody.Part.createFormData(
                "file",
                file.name,
                requestFile
            )
            
            val emotionPart = emotion.toRequestBody("text/plain".toMediaType())
            
            ttsApiService.uploadVoiceSample(multipartFile, emotionPart)
        }
    }
    
    suspend fun generateAudio(
        text: String,
        voiceSampleId: String,
        emotion: String = "neutral",
        language: String = "es"
    ): Resource<TtsGenerationResponse> {
        return safeApiCall {
            val request = TtsGenerationRequest(
                text = text,
                voice_sample_id = voiceSampleId,
                emotion = emotion,
                language = language
            )
            
            ttsApiService.generateAudio(request)
        }
    }
    
    suspend fun downloadAudio(
        generationId: String,
        outputFile: File
    ): Resource<File> {
        return safeApiCall {
            val responseBody = ttsApiService.downloadAudio(generationId)
            
            outputFile.outputStream().use { outputStream ->
                responseBody.byteStream().use { inputStream ->
                    inputStream.copyTo(outputStream)
                }
            }
            
            outputFile
        }
    }
}
```

### Screen de Grabación

```kotlin
@Composable
fun RecordingScreen(
    viewModel: RecordingViewModel = hiltViewModel(),
    onRecordingComplete: (String) -> Unit
) {
    val recordingState by viewModel.recordingState.collectAsState()
    val uiState by viewModel.uiState.collectAsState()
    
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Título
        Text(
            text = "Graba tu voz",
            style = MaterialTheme.typography.headlineMedium,
            modifier = Modifier.padding(bottom = 32.dp)
        )
        
        // Status de grabación
        when (recordingState) {
            RecordingState.IDLE -> {
                Text(
                    text = "Presiona el botón para comenzar",
                    style = MaterialTheme.typography.bodyLarge,
                    textAlign = TextAlign.Center
                )
            }
            RecordingState.RECORDING -> {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Indicador visual
                    Box(
                        modifier = Modifier
                            .size(200.dp)
                            .background(
                                color = MaterialTheme.colorScheme.error.copy(alpha = 0.3f),
                                shape = CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = "Grabando",
                            modifier = Modifier.size(80.dp),
                            tint = MaterialTheme.colorScheme.error
                        )
                    }
                    
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    // Timer
                    val currentDuration = viewModel.getCurrentDuration()
                    Text(
                        text = formatDuration(currentDuration),
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.error
                    )
                }
            }
            RecordingState.PROCESSING -> {
                CircularProgressIndicator(modifier = Modifier.size(80.dp))
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "Procesando audio...",
                    style = MaterialTheme.typography.bodyLarge
                )
            }
            RecordingState.COMPLETE -> {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = "Completado",
                    modifier = Modifier.size(80.dp),
                    tint = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "Audio grabado exitosamente",
                    style = MaterialTheme.typography.bodyLarge
                )
            }
            RecordingState.ERROR -> {
                Icon(
                    imageVector = Icons.Default.Error,
                    contentDescription = "Error",
                    modifier = Modifier.size(80.dp),
                    tint = MaterialTheme.colorScheme.error
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "Error al grabar audio",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.error
                )
            }
        }
        
        Spacer(modifier = Modifier.height(48.dp))
        
        // Botón de grabación
        when (recordingState) {
            RecordingState.IDLE -> {
                FloatingActionButton(
                    onClick = { viewModel.startRecording() },
                    modifier = Modifier.size(80.dp),
                    containerColor = MaterialTheme.colorScheme.primary
                ) {
                    Icon(
                        imageVector = Icons.Default.Mic,
                        contentDescription = "Iniciar grabación",
                        modifier = Modifier.size(40.dp),
                        tint = MaterialTheme.colorScheme.onPrimary
                    )
                }
            }
            RecordingState.RECORDING -> {
                FloatingActionButton(
                    onClick = { viewModel.stopRecording() },
                    modifier = Modifier.size(80.dp),
                    containerColor = MaterialTheme.colorScheme.error
                ) {
                    Icon(
                        imageVector = Icons.Default.Stop,
                        contentDescription = "Detener grabación",
                        modifier = Modifier.size(40.dp),
                        tint = MaterialTheme.colorScheme.onError
                    )
                }
            }
            else -> {
                // Mostrar botón deshabilitado o diferente
                FloatingActionButton(
                    onClick = { },
                    modifier = Modifier.size(80.dp),
                    containerColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.3f)
                ) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(40.dp),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
        
        Spacer(modifier = Modifier.height(32.dp))
        
        // Botón para continuar (solo cuando está completo)
        if (recordingState == RecordingState.COMPLETE) {
            Button(
                onClick = {
                    val voiceSampleId = uiState.uploadedVoiceSampleId
                    if (voiceSampleId != null) {
                        onRecordingComplete(voiceSampleId)
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Continuar")
            }
        }
    }
}
```

## 🎯 Generación de TTS

### ViewModel para TTS

```kotlin
@HiltViewModel
class TtsViewModel @Inject constructor(
    private val ttsRepository: TtsRepository
) : ViewModel() {
    
    private val _generationState = MutableStateFlow<Resource<TtsGenerationResponse>?>(null)
    val generationState: StateFlow<Resource<TtsGenerationResponse>?> = _generationState.asStateFlow()
    
    private val _generationProgress = MutableStateFlow(0)
    val generationProgress: StateFlow<Int> = _generationProgress.asStateFlow()
    
    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()
    
    private val _generatedAudioFile = MutableStateFlow<File?>(null)
    val generatedAudioFile: StateFlow<File?> = _generatedAudioFile.asStateFlow()
    
    suspend fun generateAudio(
        text: String,
        voiceSampleId: String,
        emotion: String = "neutral",
        language: String = "es"
    ) {
        _isGenerating.value = true
        _generationState.value = Resource.Loading()
        
        try {
            // 1. Generar TTS
            val result = ttsRepository.generateAudio(text, voiceSampleId, emotion, language)
            _generationState.value = result
            
            if (result is Resource.Success) {
                val generationId = result.data.id
                
                // 2. Monitorear progreso
                monitorGenerationProgress(generationId)
                
                // 3. Esperar completado y descargar
                waitForCompletionAndDownload(generationId)
            } else {
                _isGenerating.value = false
            }
        } catch (e: Exception) {
            _generationState.value = Resource.Error(e)
            _isGenerating.value = false
        }
    }
    
    private suspend fun monitorGenerationProgress(generationId: String) {
        CoroutineScope(Dispatchers.IO).launch {
            while (_isGenerating.value) {
                try {
                    // Aquí implementarías un endpoint para obtener progreso
                    // Por ahora simulamos el progreso
                    val currentProgress = _generationProgress.value
                    if (currentProgress < 100) {
                        _generationProgress.value = currentProgress + 10
                    }
                    delay(2000)
                } catch (e: Exception) {
                    Log.e("TtsViewModel", "Error monitoring progress: ${e.message}")
                }
            }
        }
    }
    
    private suspend fun waitForCompletionAndDownload(generationId: String) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                // Esperar hasta que esté completado (máximo 2 minutos)
                val maxWaitTime = 120_000L
                val startTime = System.currentTimeMillis()
                
                while (System.currentTimeMillis() - startTime < maxWaitTime) {
                    // Verificar estado (implementar endpoint real)
                    val isCompleted = checkIfGenerationCompleted(generationId)
                    
                    if (isCompleted) {
                        // Descargar audio
                        val outputFile = File(context.cacheDir, "generated_$generationId.wav")
                        val downloadResult = ttsRepository.downloadAudio(generationId, outputFile)
                        
                        withContext(Dispatchers.Main) {
                            if (downloadResult is Resource.Success) {
                                _generatedAudioFile.value = outputFile
                            }
                            _isGenerating.value = false
                            _generationProgress.value = 100
                        }
                        break
                    }
                    
                    delay(5_000) // Esperar 5 segundos antes de verificar nuevamente
                }
                
                if (_isGenerating.value) {
                    // Timeout
                    withContext(Dispatchers.Main) {
                        _generationState.value = Resource.Error(Exception("Timeout: La generación tomó demasiado tiempo"))
                        _isGenerating.value = false
                    }
                }
                
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    _generationState.value = Resource.Error(e)
                    _isGenerating.value = false
                }
            }
        }
    }
    
    private suspend fun checkIfGenerationCompleted(generationId: String): Boolean {
        // TODO: Implementar llamada real a la API
        return _generationProgress.value >= 100
    }
    
    fun clearState() {
        _generationState.value = null
        _generationProgress.value = 0
        _isGenerating.value = false
        _generatedAudioFile.value = null
    }
}
```

### Screen de Generación TTS

```kotlin
@Composable
fun TtsGeneratorScreen(
    voiceSampleId: String,
    viewModel: TtsViewModel = hiltViewModel(),
    onBack: () -> Unit,
    onGenerationComplete: (File) -> Unit
) {
    val generationState by viewModel.generationState.collectAsState()
    val isGenerating by viewModel.isGenerating.collectAsState()
    val progress by viewModel.generationProgress.collectAsState()
    val generatedFile by viewModel.generatedAudioFile.collectAsState()
    
    var text by remember { mutableStateOf("") }
    var selectedEmotion by remember { mutableStateOf("neutral") }
    var selectedLanguage by remember { mutableStateOf("es") }
    
    val emotions = listOf("neutral", "happy", "sad", "angry", "surprised")
    val languages = listOf(
        "es" to "Español",
        "en" to "English",
        "fr" to "Français",
        "de" to "Deutsch"
    )
    
    // Manejar cuando la generación está completa
    LaunchedEffect(generatedFile) {
        generatedFile?.let { file ->
            onGenerationComplete(file)
        }
    }
    
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        // Header
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Atrás")
            }
            Text(
                text = "Generar Audio",
                style = MaterialTheme.typography.headlineSmall,
                modifier = Modifier.weight(1f)
            )
        }
        
        Spacer(modifier = Modifier.height(24.dp))
        
        // Campo de texto
        OutlinedTextField(
            value = text,
            onValueChange = { text = it },
            label = { Text("Texto a sintetizar") },
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 120.dp),
            maxLines = 5,
            textStyle = MaterialTheme.typography.bodyLarge
        )
        
        Spacer(modifier = Modifier.height(16.dp))
        
        // Selector de emoción
        Text(
            text = "Emoción",
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(emotions) { emotion ->
                FilterChip(
                    onClick = { selectedEmotion = emotion },
                    selected = selectedEmotion == emotion,
                    label = { Text(emotion.capitalize()) },
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
            }
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        // Selector de idioma
        Text(
            text = "Idioma",
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.height(120.dp)
        ) {
            items(languages) { (code, name) ->
                Card(
                    modifier = Modifier
                        .padding(4.dp)
                        .fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = if (selectedLanguage == code) {
                            MaterialTheme.colorScheme.primary
                        } else {
                            MaterialTheme.colorScheme.surface
                        }
                    ),
                    onClick = { selectedLanguage = code }
                ) {
                    Text(
                        text = name,
                        modifier = Modifier.padding(16.dp),
                        color = if (selectedLanguage == code) {
                            MaterialTheme.colorScheme.onPrimary
                        } else {
                            MaterialTheme.colorScheme.onSurface
                        }
                    )
                }
            }
        }
        
        Spacer(modifier = Modifier.height(24.dp))
        
        // Botón de generar
        Button(
            onClick = {
                if (text.isNotBlank()) {
                    viewModel.generateAudio(text, voiceSampleId, selectedEmotion, selectedLanguage)
                }
            },
            modifier = Modifier.fillMaxWidth(),
            enabled = !isGenerating && text.isNotBlank()
        ) {
            when (isGenerating) {
                true -> {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(16.dp),
                            color = MaterialTheme.colorScheme.onPrimary
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Generando... $progress%")
                    }
                }
                false -> {
                    Text("Generar Audio")
                }
            }
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        // Progreso de generación
        if (isGenerating) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Column(
                    modifier = Modifier.padding(16.dp)
                ) {
                    Text(
                        text = "Generando tu audio...",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    LinearProgressIndicator(
                        progress = progress / 100f,
                        modifier = Modifier.fillMaxWidth()
                    )
                    
                    Text(
                        text = "$progress% completado",
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
        }
        
        // Estado de error
        generationState?.let { state ->
            if (state is Resource.Error) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.errorContainer
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Error,
                            contentDescription = "Error",
                            tint = MaterialTheme.colorScheme.onErrorContainer
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Error: ${state.exception.message}",
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                    }
                }
            }
        }
    }
}
```

## 🎓 Entrenamiento de Modelos

### Repository de Entrenamiento

```kotlin
@Singleton
class TrainingRepository @Inject constructor(
    private val trainingApiService: TrainingApiService
) {
    
    suspend fun startTraining(
        voiceSampleIds: List<String>,
        modelName: String,
        language: String
    ): Resource<TrainingResponse> {
        return safeApiCall {
            val request = TrainingRequest(
                voice_sample_ids = voiceSampleIds,
                model_name = modelName,
                language = language
            )
            trainingApiService.startTraining(request)
        }
    }
    
    suspend fun getTrainingStatus(trainingId: String): Resource<TrainingStatusResponse> {
        return safeApiCall {
            trainingApiService.getTrainingStatus(trainingId)
        }
    }
    
    suspend fun getUserModels(): Resource<ModelsListResponse> {
        return safeApiCall {
            trainingApiService.getUserModels()
        }
    }
    
    suspend fun deleteModel(modelId: String): Resource<Unit> {
        return safeApiCall {
            trainingApiService.deleteModel(modelId)
        }
    }
}
```

### Screen de Entrenamiento

```kotlin
@Composable
fun TrainingScreen(
    viewModel: TrainingViewModel = hiltViewModel(),
    voiceSamples: List<VoiceSample>,
    onTrainingComplete: (String) -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    val trainingState by viewModel.trainingState.collectAsState()
    
    var modelName by remember { mutableStateOf("") }
    var selectedLanguage by remember { mutableStateOf("es") }
    var selectedSamples = remember { mutableStateSetOf<String>() }
    
    val languages = listOf(
        "es" to "Español",
        "en" to "English", 
        "fr" to "Français"
    )
    
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text(
            text = "Entrenar Modelo Personalizado",
            style = MaterialTheme.typography.headlineSmall,
            modifier = Modifier.padding(bottom = 24.dp)
        )
        
        // Nombre del modelo
        OutlinedTextField(
            value = modelName,
            onValueChange = { modelName = it },
            label = { Text("Nombre del modelo") },
            modifier = Modifier.fillMaxWidth()
        )
        
        Spacer(modifier = Modifier.height(16.dp))
        
        // Selector de idioma
        Text(
            text = "Idioma",
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        
        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            modifier = Modifier.height(120.dp)
        ) {
            items(languages) { (code, name) ->
                Card(
                    modifier = Modifier
                        .padding(4.dp)
                        .fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = if (selectedLanguage == code) {
                            MaterialTheme.colorScheme.primary
                        } else {
                            MaterialTheme.colorScheme.surface
                        }
                    ),
                    onClick = { selectedLanguage = code }
                ) {
                    Text(
                        text = name,
                        modifier = Modifier.padding(12.dp),
                        textAlign = TextAlign.Center,
                        color = if (selectedLanguage == code) {
                            MaterialTheme.colorScheme.onPrimary
                        } else {
                            MaterialTheme.colorScheme.onSurface
                        }
                    )
                }
            }
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        // Lista de muestras de voz
        Text(
            text = "Seleccionar muestras de voz (mínimo 3)",
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        
        LazyColumn(modifier = Modifier.height(200.dp)) {
            items(voiceSamples) { sample ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (selectedSamples.contains(sample.id)) {
                            MaterialTheme.colorScheme.primaryContainer
                        } else {
                            MaterialTheme.colorScheme.surface
                        }
                    ),
                    onClick = {
                        if (selectedSamples.contains(sample.id)) {
                            selectedSamples.remove(sample.id)
                        } else {
                            selectedSamples.add(sample.id)
                        }
                    }
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = selectedSamples.contains(sample.id),
                            onCheckedChange = null // Managed by card click
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = sample.filename,
                                style = MaterialTheme.typography.bodyLarge
                            )
                            Text(
                                text = "${sample.duration}s - ${sample.format}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
        
        Spacer(modifier = Modifier.height(24.dp))
        
        // Información del entrenamiento
        if (trainingState is Resource.Success) {
            val trainingResponse = (trainingState as Resource.Success).data
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Entrenamiento iniciado",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "ID: ${trainingResponse.id}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Text(
                        text = "Tiempo estimado: ${trainingResponse.estimatedDuration / 60} minutos",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        // Botón de entrenamiento
        Button(
            onClick = {
                val sampleIds = selectedSamples.toList()
                if (modelName.isNotBlank() && sampleIds.size >= 3) {
                    viewModel.startTraining(
                        voiceSampleIds = sampleIds,
                        modelName = modelName,
                        language = selectedLanguage
                    )
                }
            },
            modifier = Modifier.fillMaxWidth(),
            enabled = modelName.isNotBlank() && 
                     selectedSamples.size >= 3 && 
                     trainingState !is Resource.Loading
        ) {
            when (trainingState) {
                is Resource.Loading -> {
                    CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                }
                else -> {
                    Text("Iniciar Entrenamiento")
                }
            }
        }
    }
}
```

## 🔄 Casos de Uso Completos

### Flujo Completo de Clonación de Voz

```kotlin
@HiltViewModel
class CompleteVoiceCloningViewModel @Inject constructor(
    private val ttsRepository: TtsRepository,
    private val audioRecorder: AudioRecorder
) : ViewModel() {
    
    private val _currentStep = MutableStateFlow(0)
    val currentStep: StateFlow<Int> = _currentStep.asStateFlow()
    
    private val _voiceSampleId = MutableStateFlow<String?>(null)
    val voiceSampleId: StateFlow<String?> = _voiceSampleId.asStateFlow()
    
    private val _generatedAudio = MutableStateFlow<File?>(null)
    val generatedAudio: StateFlow<File?> = _generatedAudio.asStateFlow()
    
    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()
    
    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()
    
    private val steps = listOf(
        "Grabar muestra de voz",
        "Subir muestra",
        "Generar audio de prueba",
        "Completado"
    )
    
    fun getStepTitle(step: Int): String {
        return steps.getOrNull(step) ?: "Paso $step"
    }
    
    fun startRecording() {
        viewModelScope.launch {
            try {
                audioRecorder.startRecording { duration ->
                    // Update recording duration if needed
                }
                _currentStep.value = 0
            } catch (e: Exception) {
                _error.value = "Error al iniciar grabación: ${e.message}"
            }
        }
    }
    
    fun stopRecordingAndUpload() {
        viewModelScope.launch {
            _isLoading.value = true
            _error.value = null
            
            try {
                // 1. Stop recording
                val recordedFile = audioRecorder.stopRecording()
                    ?: throw Exception("No se pudo crear el archivo de audio")
                
                // 2. Upload voice sample
                val uploadResult = ttsRepository.uploadVoiceSample(recordedFile, "neutral")
                
                when (uploadResult) {
                    is Resource.Success -> {
                        _voiceSampleId.value = uploadResult.data.id
                        _currentStep.value = 1
                        
                        // 3. Generate test audio automatically
                        generateTestAudio()
                    }
                    is Resource.Error -> {
                        _error.value = "Error al subir muestra: ${uploadResult.exception.message}"
                    }
                }
            } catch (e: Exception) {
                _error.value = "Error en el proceso: ${e.message}"
            } finally {
                _isLoading.value = false
            }
        }
    }
    
    private suspend fun generateTestAudio() {
        val voiceSampleId = _voiceSampleId.value ?: return
        
        _currentStep.value = 2
        _isLoading.value = true
        
        try {
            val testText = "Hola, esta es una prueba de mi voz clonada. ¿Te gusta cómo suena?"
            
            val generationResult = ttsRepository.generateAudio(
                text = testText,
                voiceSampleId = voiceSampleId,
                emotion = "neutral",
                language = "es"
            )
            
            when (generationResult) {
                is Resource.Success -> {
                    // Wait for completion and download
                    waitForCompletionAndDownload(generationResult.data.id)
                }
                is Resource.Error -> {
                    _error.value = "Error al generar audio: ${generationResult.exception.message}"
                }
            }
        } catch (e: Exception) {
            _error.value = "Error en la generación: ${e.message}"
        } finally {
            _isLoading.value = false
        }
    }
    
    private suspend fun waitForCompletionAndDownload(generationId: String) {
        try {
            // Simular espera (en implementación real usar WebSocket o polling)
            delay(30_000) // Esperar 30 segundos
            
            val outputFile = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                "voice_clone_test_${System.currentTimeMillis()}.wav"
            )
            
            val downloadResult = ttsRepository.downloadAudio(generationId, outputFile)
            
            when (downloadResult) {
                is Resource.Success -> {
                    _generatedAudio.value = outputFile
                    _currentStep.value = 3
                }
                is Resource.Error -> {
                    _error.value = "Error al descargar audio: ${downloadResult.exception.message}"
                }
            }
        } catch (e: Exception) {
            _error.value = "Error en la descarga: ${e.message}"
        }
    }
    
    fun reset() {
        _currentStep.value = 0
        _voiceSampleId.value = null
        _generatedAudio.value = null
        _isLoading.value = false
        _error.value = null
        audioRecorder.stopRecording()
    }
    
    override fun onCleared() {
        super.onCleared()
        audioRecorder.stopRecording()
    }
}
```

### Screen del Flujo Completo

```kotlin
@Composable
fun CompleteVoiceCloningScreen(
    viewModel: CompleteVoiceCloningViewModel = hiltViewModel(),
    onComplete: (File) -> Unit
) {
    val currentStep by viewModel.currentStep.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()
    val error by viewModel.error.collectAsState()
    val generatedAudio by viewModel.generatedAudio.collectAsState()
    
    // Manejar cuando el audio está generado
    LaunchedEffect(generatedAudio) {
        generatedAudio?.let { file ->
            onComplete(file)
        }
    }
    
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Progress indicator
        LinearProgressIndicator(
            progress = currentStep / 3f,
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 24.dp)
        )
        
        // Current step
        Text(
            text = viewModel.getStepTitle(currentStep),
            style = MaterialTheme.typography.headlineMedium,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(bottom = 32.dp)
        )
        
        when (currentStep) {
            0 -> {
                // Recording step
                RecordingStep(
                    onStartRecording = { viewModel.startRecording() },
                    onStopRecording = { viewModel.stopRecordingAndUpload() },
                    isLoading = isLoading
                )
            }
            1 -> {
                // Upload step
                UploadStep(isLoading = isLoading)
            }
            2 -> {
                // Generation step
                GenerationStep(isLoading = isLoading)
            }
            3 -> {
                // Completion step
                CompletionStep(generatedAudio = generatedAudio)
            }
        }
        
        // Error display
        error?.let { errorMessage ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.errorContainer
                )
            ) {
                Row(
                    modifier = Modifier.padding(16.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Error,
                        contentDescription = "Error",
                        tint = MaterialTheme.colorScheme.onErrorContainer
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = errorMessage,
                        color = MaterialTheme.colorScheme.onErrorContainer
                    )
                }
            }
        }
    }
}

@Composable
private fun RecordingStep(
    onStartRecording: () -> Unit,
    onStopRecording: () -> Unit,
    isLoading: Boolean
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = Icons.Default.Mic,
            contentDescription = "Microphone",
            modifier = Modifier.size(120.dp),
            tint = MaterialTheme.colorScheme.primary
        )
        
        Spacer(modifier = Modifier.height(24.dp))
        
        Button(
            onClick = onStopRecording,
            enabled = !isLoading
        ) {
            if (isLoading) {
                CircularProgressIndicator(
                    modifier = Modifier.size(16.dp),
                    color = MaterialTheme.colorScheme.onPrimary
                )
            } else {
                Text("Detener y Subir")
            }
        }
    }
}

@Composable
private fun UploadStep(isLoading: Boolean) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        CircularProgressIndicator(modifier = Modifier.size(80.dp))
        Spacer(modifier = Modifier.height(24.dp))
        Text(
            text = "Subiendo muestra de voz...",
            style = MaterialTheme.typography.bodyLarge
        )
    }
}

@Composable
private fun GenerationStep(isLoading: Boolean) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        CircularProgressIndicator(modifier = Modifier.size(80.dp))
        Spacer(modifier = Modifier.height(24.dp))
        Text(
            text = "Generando audio de prueba...",
            style = MaterialTheme.typography.bodyLarge
        )
        Text(
            text = "Esto puede tomar unos minutos",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun CompletionStep(generatedAudio: File?) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = Icons.Default.CheckCircle,
            contentDescription = "Success",
            modifier = Modifier.size(120.dp),
            tint = MaterialTheme.colorScheme.primary
        )
        
        Spacer(modifier = Modifier.height(24.dp))
        
        Text(
            text = "¡Clonación completada!",
            style = MaterialTheme.typography.headlineMedium,
            textAlign = TextAlign.Center
        )
        
        Spacer(modifier = Modifier.height(8.dp))
        
        Text(
            text = "Tu voz ha sido clonada exitosamente",
            style = MaterialTheme.typography.bodyLarge,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        
        generatedAudio?.let { file ->
            Spacer(modifier = Modifier.height(24.dp))
            
            Button(
                onClick = {
                    // Play audio or share it
                    playAudioFile(file)
                }
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Reproducir Audio")
            }
        }
    }
}
```

## ⚠️ Manejo de Errores

### Error Interceptor

```kotlin
class ErrorInterceptor : Interceptor {
    
    override fun intercept(chain: Interceptor.Chain): Response {
        val request = chain.request()
        val response = chain.proceed(request)
        
        return when (response.code) {
            401 -> {
                // Unauthorized - clear token and restart auth flow
                handleUnauthorized(response)
            }
            403 -> {
                // Forbidden - show permission error
                throw ForbiddenException("Sin permisos para esta operación")
            }
            404 -> {
                // Not Found
                throw NotFoundException("Recurso no encontrado")
            }
            429 -> {
                // Rate limit
                throw RateLimitException("Demasiadas solicitudes, intenta más tarde")
            }
            in 500..599 -> {
                // Server error
                throw ServerException("Error del servidor, intenta más tarde")
            }
            else -> {
                response
            }
        }
    }
    
    private fun handleUnauthorized(response: Response): Response {
        // Clear stored tokens
        // Navigate to login screen
        return response
    }
}

// Custom Exceptions
class ForbiddenException(message: String) : Exception(message)
class NotFoundException(message: String) : Exception(message)
class RateLimitException(message: String) : Exception(message)
class ServerException(message: String) : Exception(message)
```

### Error Handler en Repository

```kotlin
@Singleton
class ErrorHandler @Inject constructor(
    @ApplicationContext private val context: Context
) {
    
    fun handleError(exception: Exception): String {
        return when (exception) {
            is SocketTimeoutException -> {
                "La conexión ha tardado demasiado. Verifica tu conexión a internet."
            }
            is UnknownHostException -> {
                "No se puede conectar al servidor. Verifica tu conexión."
            }
            is HttpException -> {
                when (exception.code()) {
                    401 -> "Sesión expirada. Por favor, inicia sesión nuevamente."
                    403 -> "No tienes permisos para realizar esta acción."
                    404 -> "El recurso solicitado no existe."
                    429 -> "Demasiadas solicitudes. Intenta más tarde."
                    500 -> "Error interno del servidor. Intenta más tarde."
                    else -> "Error de conexión. Intenta nuevamente."
                }
            }
            is FileNotFoundException -> {
                "El archivo no existe o ha sido movido."
            }
            is SecurityException -> {
                "Permisos insuficientes para acceder al archivo."
            }
            else -> {
                "Ha ocurrido un error inesperado: ${exception.message}"
            }
        }
    }
    
    fun showErrorDialog(exception: Exception) {
        val message = handleError(exception)
        
        AlertDialog.Builder(context)
            .setTitle("Error")
            .setMessage(message)
            .setPositiveButton("OK") { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }
}
```

## 🚀 Optimizaciones

### Cache de Audio

```kotlin
@Singleton
class AudioCache @Inject constructor(
    @ApplicationContext private val context: Context
) {
    
    private val cacheDir = File(context.cacheDir, "audio_cache")
    private val maxCacheSize = 100 * 1024 * 1024 // 100MB
    
    init {
        cacheDir.mkdirs()
    }
    
    fun getCachedAudio(generationId: String): File? {
        val cachedFile = File(cacheDir, "$generationId.wav")
        return if (cachedFile.exists()) cachedFile else null
    }
    
    fun cacheAudio(generationId: String, audioData: ByteArray): File {
        val cachedFile = File(cacheDir, "$generationId.wav")
        cachedFile.writeBytes(audioData)
        
        // Clean up old files if cache is too large
        cleanCacheIfNeeded()
        
        return cachedFile
    }
    
    private fun cleanCacheIfNeeded() {
        val totalSize = getDirectorySize(cacheDir)
        if (totalSize > maxCacheSize) {
            cacheDir.listFiles()
                ?.sortedBy { it.lastModified() }
                ?.takeWhile { totalSize > maxCacheSize * 0.8 }
                ?.forEach { it.delete() }
        }
    }
    
    private fun getDirectorySize(directory: File): Long {
        return directory.listFiles()
            ?.sumOf { it.length() } ?: 0L
    }
    
    fun clearCache() {
        cacheDir.listFiles()?.forEach { it.delete() }
    }
}
```

### Optimización de Red

```kotlin
@Module
@InstallIn(SingletonComponent::class)
object CacheModule {
    
    @Provides
    @Singleton
    fun provideCache(): Cache {
        val cacheSize = 10 * 1024 * 1024 // 10MB
        return Cache(File(context.cacheDir, "http_cache"), cacheSize)
    }
    
    @Provides
    @Singleton
    fun provideOkHttpWithCache(cache: Cache): OkHttpClient {
        return OkHttpClient.Builder()
            .cache(cache)
            .addInterceptor { chain ->
                val request = chain.request()
                val response = chain.proceed(request)
                
                // Cache successful GET responses for 5 minutes
                if (request.method == "GET" && response.isSuccessful) {
                    response.newBuilder()
                        .header("Cache-Control", "public, max-age=300")
                        .build()
                } else {
                    response
                }
            }
            .build()
    }
}
```

### Preload de Modelos

```kotlin
@Singleton
class ModelPreloader @Inject constructor(
    private val ttsRepository: TtsRepository
) {
    
    private val preloadedModels = mutableSetOf<String>()
    
    fun preloadModels(modelIds: List<String>) {
        modelIds.forEach { modelId ->
            if (!preloadedModels.contains(modelId)) {
                preloadModel(modelId)
            }
        }
    }
    
    private fun preloadModel(modelId: String) {
        // This would be implemented based on your API
        // For now, just mark as preloaded
        preloadedModels.add(modelId)
    }
    
    fun isModelPreloaded(modelId: String): Boolean {
        return preloadedModels.contains(modelId)
    }
    
    fun clearPreloaded() {
        preloadedModels.clear()
    }
}
```

---

**Chalan Voice Android** - Ejemplos completos de implementación 📱💻

*Estos ejemplos muestran las mejores prácticas para integrar la API de Chalan Voice en aplicaciones Android modernas.*