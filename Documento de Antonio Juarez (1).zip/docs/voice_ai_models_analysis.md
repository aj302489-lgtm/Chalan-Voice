# Modelos de IA para clonación de voz: XTTSv2, Bark, alternativas (Tortoise-TTS, Coqui TTS), marcas de agua acústicas, entrenamiento y ecosistema Python

## Resumen ejecutivo y conclusiones accionables

La síntesis de voz por IA y la clonación de voz han madurado al punto de ofrecer resultados de alta calidad con fricción técnica razonable. Dos modelos open source se posicionan con claridad para producción: XTTSv2 de Coqui, que destaca por clonación multilingüe con apenas unos segundos de audio y transferencia de emoción/estilo; y Bark de Suno, que sobresale como generador de audio expresivo guiado por texto (habla, música y efectos) con controles semánticos útiles para experiencias ricas y creativas. Tortoise-TTS, por su parte, ofrece una alternativa de alta calidad con latencias bajas tras optimizaciones, aunque su velocidad sigue siendo inferior a la de XTTSv2. El ecosistema Coqui TTS integra estos modelos bajo APIs coherentes, lo que simplifica su adopción.

Para proteger audio generado y mitigar abusos, la watermarking acústico es crítico. VoiceMark introduce una aproximación basada en latentes específicos del hablante, con alta detectabilidad en escenarios de clonación de voz en zero-shot y frente a transformaciones comunes. Esta línea de defensa debe integrarse como un módulo de verificación continua en pipelines corporativos y productos públicos.

En términos de decisiones:

- Si el caso de uso requiere clonación rápida de una voz en múltiples idiomas, con transferencia de emoción/estilo y estabilidad, XTTSv2 es la primera opción. El fine-tuning adicional puede elevar la similitud de hablante cuando se requiere mayor precisión en escenarios entre idiomas.[^1][^2][^5][^16][^17]
- Si la necesidad es generar experiencias de audio complejas (habla con risas, suspiros, música de fondo) y se valoran controles semánticos y presets de voz, Bark aporta riqueza expresiva con integración directa en Transformers y aceleración mediante OpenVINO.[^8][^9][^10]
- Si la prioridad es calidad prosódica y se tolera una mayor latencia, Tortoise-TTS con sus optimizaciones recientes (DeepSpeed, caché KV, FP16) es competitivo, especialmente para narrativas con matiz emotivo.[^11]
- Si el objetivo es conversión de voz cantada preservando tono y entonación, so-vits-svc y su ecosistema (RVC, forks con soporte en tiempo real) son los adecuados; no son TTS, pero resuelven voice-to-voice con alta fidelidad musical.[^12][^13][^14]
- Donde haya riesgo reputacional, regulatorio o de abuso, incorporar watermarking acústico (p. ej., VoiceMark) como capa de verificación, combinándolo con controles de contenido y trazabilidad.[^19][^20][^21][^22]

Para sintetizar estas recomendaciones en un solo vistazo, la siguiente tabla resume la selección por caso de uso. Antes de revisarla, cabe subrayar que la decisión final depende de restricciones de hardware, requisitos de latencia, cobertura idiomática, licencias y la disponibilidad de datos de calidad para fine-tuning.

Tabla 1. Resumen de recomendación por caso de uso

| Caso de uso | Modelo recomendado | Motivo principal | Riesgos/Limitaciones |
|---|---|---|---|
| Clonación multilingüe a partir de muestras cortas | XTTSv2 | Clonación zero-shot en 17 idiomas; transferencia de emoción/estilo; APIs de Coqui TTS | Calidad sensible a la referencia; ajustar emoción vía referencia; tolerancia a ruido del habla objetivo[^1][^2][^5] |
| Narración expresiva con música/efectos | Bark | Audio generativo rico; controles semánticos ([laughter], música), >100 presets | Longitud por pase ~13–14s; requiere拼接 para textos largos; VRAM significativa si no se optimiza[^8][^9][^10] |
| Alta calidad prosódica con latencia moderada-baja | Tortoise-TTS | Decodificador autorregresivo + difusión; optimizaciones RTF 0.25–0.3 | Inferencia más lenta que XTTSv2; requiere tuning de presets/optimizaciones[^11] |
| Voice-to-voice (cantado) | so-vits-svc / RVC | SVC que preserva tono/entonación; amplia compatibilidad de encoders y F0 | No es TTS; depende de preprocesado (separación de stems, F0); repositorio archivado (AGPL-3.0)[^12][^13][^14] |
| Protección de contenido generado | VoiceMark (+ políticas) | Watermark robusto en zero-shot VC; alta detectabilidad; respeto a calidad | Integración adicional; impacto computacional; política corporativa necesaria[^19][^20][^21][^22] |

El mensaje clave: adoptar XTTSv2 para clonación multilingüe de alta calidad; Bark para experiencias sonoras ricas con semántica; Tortoise cuando la calidad prosódica y una latencia razonable son prioritarias; so-vits-svc/RVC para conversión de voz cantada; y watermarking acústico como defensa proactiva contra usos indebidos.

## Fundamentos y taxonomía: clonación de voz, TTS, VC y watermarking

Conviene establecer definiciones operativas. La clonación de voz es la capacidad de replicar la identidad vocal de un hablante —timbre, acento, estilo— a partir de muestras de audio. Puede ser zero-shot (sin entrenar el modelo con la voz objetivo, usando una referencia breve) o requerir fine-tuning sobre datos específicos del hablante. El Texto-a-Voz (Text-to-Speech, TTS) genera audio a partir de texto; algunos modelos de TTS incluyen clonación de voz incorporada, como XTTSv2, mientras que otros, como Bark, ofrecen una síntesis muy expresiva sin enfocarse específicamente en identidad vocal. La conversión de voz (Voice Conversion, VC) transforma una señal de audio de origen hacia la voz de un objetivo manteniendo contenido, tono y entonación; aquí destacan los toolkits SVC como so-vits-svc, que no trabajan con texto. Por último, el watermarking acústico inserta marcas imperceptibles en el audio que permiten su trazabilidad y verificación posterior.

El panorama técnico se organiza en familias: Codec/LLM, que tokeniza audio y usa modelos de lenguaje para generar secuencias; Autorregresivo + Difusión, que combina un predictor de tokens de audio y un decodificador probabilístico para alta calidad; Vocoders neurales (p. ej., HiFi-GAN, UnivNet), que convierten latentes o espectrogramas en señal audible; y Pipelines de VC (p. ej., VITS + SoftVC), que encadenan encoders de contenido y vocoders. XTTS se apoya en tokens de un VQ-VAE para audio, un GPT-2 condicionado por un encoder de hablante, y un vocoder HiFi-GAN; Bark utiliza EnCodec como representación cuantizada y modelos estilo GPT para generar audio; Tortoise combina un decodificador autorregresivo con uno de difusión y un vocoder UnivNet; y so-vits-svc emplea VITS para VC con encoders de contenido (ContentVec/Hubert/Whisper-PPG) y vocoders NSF HiFiGAN.[^2][^18][^11][^13]

Un punto esencial es la diferencia práctica entre clonación zero-shot y fine-tuning. En zero-shot, la identidad vocal se capta a partir de una muestra breve; el sistema retiene timbre y rasgos generales, pero puede perder rango expresivo completo o matices del hablante, ya que el estilo de entrega tiende a seguir el del modelo base. El fine-tuning, por el contrario, enseña al modelo la voz específica con mayor precisión, mejorando la similitud de hablante, la prosodia y el fraseo característico, a costa de datos, tiempo y cómputo. Las guías de Unsloth y Telnyx subrayan estas compensaciones y recomiendan fine-tuning cuando la calidad de identidad y estilo es crítica.[^6][^7]

Para visualizar esta taxonomía, la siguiente tabla compara familias, representantes, pros/contras y licenciamiento.

Tabla 2. Taxonomía técnica: familia/modelo, pros, contras y licencia

| Familia | Modelo representante | Pros | Contras | Licencia/Notas |
|---|---|---|---|---|
| Codec/LLM + Vocoder | XTTSv2 | Multilingüe, zero-shot robusto, transferencia de estilo/emoción, clonación entre idiomas | Control de emoción no explícito; depende de calidad de referencia | Modelos y librerías Coqui TTS (CPML); ecosistema abierto[^1][^2][^4][^16][^17] |
| Autorregresivo + Difusión + Vocoder UnivNet | Tortoise-TTS | Alta calidad prosódica; prosodia e entonación realistas; optimizaciones | Latencia superior a XTTSv2; requiere tuning de presets y optimizaciones | Apache-2.0[^11] |
| Codec/LLM estilo GPT + EnCodec | Bark | Audio generativo multiformato; controles semánticos; presets de voz; integración Transformers | Longitud por pase limitada;拼接 para textos largos; VRAM relevante | MIT (comercial); ejemplos y aceleración OpenVINO[^8][^9][^10] |
| VC (VITS + SoftVC + vocoder) | so-vits-svc | Preserva tono/entonación; compatibilidad amplia de encoders/F0; forks en tiempo real | No TTS; AGPL-3.0; repositorio archivado | AGPL-3.0; variantes (RVC, svc-fork)[^12][^13][^14] |
| Watermarking acústico | VoiceMark | Robusto en zero-shot VC; alta detectabilidad; buena calidad perceptual | Integración adicional; impacto computacional; requiere datasets y evaluación | Investigación reciente; complementar con políticas y detección[^19][^20][^21][^22] |

La principal conclusión es que la elección del modelo no es solo técnica, sino una decisión de producto: identidad vocal precisa y multilingüe (XTTSv2), riqueza expresiva y semántica (Bark), calidad prosódica con latencia moderada (Tortoise), conversión de voz cantada (so-vits-svc), y defensa mediante watermarking (VoiceMark).

## XTTSv2: características, implementación y control de emociones

XTTSv2 es la evolución del modelo masivamente multilingüe zero-shot de Coqui, con soporte para 17 idiomas y mejoras de estabilidad, prosodia y acondicionamiento de hablantes. Oficialmente, admite clonación con una referencia de aproximadamente seis segundos y transferencia de emoción/estilo por clonación. Además, permite múltiples referencias del mismo hablante e incluso interpolación entre hablantes, lo que abre la puerta a matices de identidad y ajustes de estilo en producción. En términos prácticos, el modelo produce audio a 24 kHz, y se invoca mediante APIs de la librería TTS de Coqui tanto en Python como en línea de comandos.[^1]

Más allá de la tarjeta del modelo, la arquitectura documentada ofrece claridad: un VQ-VAE codifica mel-espectrogramas a tokens de audio a ~21.53 Hz; un codificador condicionado (GPT-2, solo decodificador) genera códigos VQ-VAE a partir de texto tokenizado con BPE, bajo el condicionamiento de un encoder de hablante que produce 32 embeddings por muestra; y un vocoder HiFi-GAN decodifica los latentes hacia señal de 24 kHz. Este diseño facilita TTS zero-shot multilingüe, mejora la similitud de hablante con pérdidas específicas (p. ej., SCL) y habilita clonación entre idiomas sin necesidad de datos paralelos.[^2]

La implementación típica sigue el patrón de la librería Coqui TTS. En Python, se carga el modelo “tts_models/multilingual/multi-dataset/xtts_v2” y se llama a tts_to_file con el texto, el archivo del hablante de referencia y el código de idioma. En CLI, “tts” con el mismo conjunto de parámetros realiza la síntesis a archivo. En uso directo del modelo, se cargan configuración y checkpoint, se llevan tensores a GPU y se invoca synthesize con las opciones adecuadas (longitud de condición GPT, idioma, referencia). Estos flujos cubren inferencia y, según la librería, ofrecen soporte para fine-tuning.[^1][^4]

Para clarificar la cobertura idiomática y capacidades, a continuación se listan los idiomas soportados y funciones principales.

Tabla 3. Idiomas soportados y capacidades

| Idioma | Código | Clonación zero-shot | Transferencia de emoción/estilo | Clonación entre idiomas |
|---|---|---|---|---|
| Inglés | en | Sí | Sí | Sí |
| Español | es | Sí | Sí | Sí |
| Francés | fr | Sí | Sí | Sí |
| Alemán | de | Sí | Sí | Sí |
| Italiano | it | Sí | Sí | Sí |
| Portugués | pt | Sí | Sí | Sí |
| Polaco | pl | Sí | Sí | Sí |
| Turco | tr | Sí | Sí | Sí |
| Ruso | ru | Sí | Sí | Sí |
| Holandés | nl | Sí | Sí | Sí |
| Checo | cs | Sí | Sí | Sí |
| Árabe | ar | Sí | Sí | Sí |
| Chino (simplificado) | zh-cn | Sí | Sí | Sí |
| Japonés | ja | Sí | Sí | Sí |
| Húngaro | hu | Sí | Sí | Sí |
| Coreano | ko | Sí | Sí | Sí |
| Hindi | hi | Sí | Sí | Sí |

Interpretación: la consistencia de clonación y transferencia de emoción/estilo en los 17 idiomas se debe al entrenamiento multilingüe masivo y a la arquitectura de acondicionamiento del hablante. Esta cobertura permite casos de uso globales con mínimos datos de referencia.[^1][^2]

En rendimiento, el paper reporta resultados de inteligibilidad y calidad por idioma (p. ej., CER, SECS), y preferencias de usuario (CMOS/SMOS) frente a sistemas comparables. Si bien las métricas detalladas se discuten en la sección de evaluación, el mensaje operacional es que XTTS logra resultados de última generación en la mayoría de los idiomas entrenados, con ventajas en similitud de hablante cuando se realiza fine-tuning (por ejemplo, incremento notable en SECS bajo transferencia entre idiomas).[^2]

Sobre control de emociones, la ruta práctica hoy es usar una referencia de audio que contenga la emoción deseada. El proyecto indica que el control explícito está en desarrollo; hasta entonces, elegir referencias con la emoción objetivo y combinar múltiples referencias ayuda a estabilizar el estilo.[^5] Esta aproximación, si se organiza con una biblioteca curada de referencias emocionales por idioma, puede industrializarse con buena tasa de éxito.

Para referencia técnica, el desglose de componentes y parámetros refuerza decisiones de ingeniería.

Tabla 4. Arquitectura y parámetros

| Componente | Tipo | Parámetros clave | Función |
|---|---|---|---|
| VQ-VAE (audio) | Cuantizador | 13M; 8192 códigos; 21.53 Hz/trama; mantiene 1024 códigos frecuentes | Tokens de audio a partir de mel-espectrogramas |
| Codificador condicionado | GPT-2 (decoder-only) | 443M; BPE 6681 tokens; condicionamiento vía encoder de hablante | Genera tokens VQ-VAE desde texto |
| Encoder de hablante | Atención producto escalado | 6 capas, 16 cabezas; 32 embeddings de 1024 dimensiones; Perceiver Resampler | Condiciona el generador para clonación |
| Vocoder | HiFi-GAN | ~26M | Latentes a audio 24 kHz |

Conclusión: XTTSv2 ofrece una combinación poco común de cobertura multilingüe, clonación zero-shot robusta y transferencia de estilo, con APIs maduras. Su única frontera operativa es el control explícito de emoción; mientras llega, la ingeniería de referencias es el patrón recomendado.[^1][^2][^4][^5][^16][^17]

## Bark: capacidades e integración

Bark es un modelo generativo de audio guiado por texto que produce habla multilingüe altamente realista, música, ruido de fondo y efectos sencillos, además de comunicaciones no verbales como risas y suspiros. Entre sus capacidades distintivas está la detección automática de idioma, una biblioteca de más de 100 presets de altavoz que пытаются igualar tono, timbre, emoción y prosodia, y el reconocimiento de marcadores semánticos en el prompt que permiten controlar pausas, énfasis y eventos sonoros: [laughter], [sighs], [music], pausas con “—” o “…”, notación musical con “♪” para letras de canciones, MAYÚSCULAS para énfasis, y sesgos de género [MAN]/[WOMAN].[^8][^9]

En arquitectura, Bark emplea una representación de audio cuantificada por EnCodec y un transformer estilo GPT para la generación. Está optimizado para GPU con PyTorch 2.0+, y ofrece variantes de modelo que permiten ejecutarse en GPUs con menos VRAM, llegando incluso a configuraciones de ~2 GB con ajustes. La longitud por pase de texto está en el rango de 13–14 segundos; para textos largos, el procedimiento recomendado es la segmentación y拼接, con guías prácticas en notebooks dedicados. Además de la integración en Transformers, existe una vía de aceleración con OpenVINO para entornos CPU o para mejorar el throughput en hardware sin GPU de gama alta.[^8][^10][^18]

Un aspecto clave para producto es su licencia MIT, que habilita uso comercial, y la disponibilidad de demos (Spaces, Colab, Replicate) que facilitan pruebas rápidas de concepto. Estas rutas hacen de Bark una opción atractiva cuando se busca una experiencia sonora expresiva, con control semántico de eventos y música, en lugar de una clonación estricta de identidad vocal.[^8][^9]

La siguiente tabla resume las capacidades de Bark por categoría.

Tabla 5. Capacidades de Bark por categoría

| Categoría | Capacidades | Ejemplos de control |
|---|---|---|
| Habla multilingüe | Inglés, alemán, español, francés, hindi, italiano, japonés, coreano, polaco, portugués, ruso, turco, chino simplificado | Detección automática de idioma; acentos nativos en code-switching |
| Sonidos no verbales | Risas, suspiros, llantos, tos, respiración | Marcadores [laughter], [sighs], [gasps], [clears throat] |
| Música | Generación guiada de música y letras | Notación “♪” para canciones; pausas y énfasis |
| Presets de voz | >100 presets de altavoz | Ajuste de tono, timbre, emoción y prosodia |
| Controles semánticos | Pausas, énfasis, sesgos de género | “—”, “…”, MAYÚSCULAS, [MAN]/[WOMAN] |

Interpretación: Bark habilita experiencias de audio narrativas y multimedia con un nivel de control semántico que lo hace ideal para contenido creativo, locuciones expresivas y productos con identidad sonora rica. Sus límites operativos —longitud por pase y VRAM— se gestionan con segmentación y variantes de modelo.[^8][^9][^10][^18]

## Modelos alternativos y ecosistema: Tortoise-TTS y Coqui TTS

Tortoise-TTS prioriza la calidad sobre la velocidad. Combina un decodificador autorregresivo con uno de difusión y utiliza un vocoder UnivNet, logrando prosodia e entonación realistas. Tras optimizaciones, el proyecto reporta un RTF (Real-Time Factor) de 0.25–0.3 con 4 GB de VRAM y latencias por debajo de 500 ms bajo streaming. Aunque sigue siendo más lento que XTTSv2, su calidad lo hace competitivo en narraciones o productos donde la expresividad y el matices prosódicos pesan más que la latencia. Además, ofrece personalización mediante “voice_samples” en la API, soporte de DeepSpeed, caché KV y ejecución en FP16, lo que permite adaptar el rendimiento al hardware disponible.[^11]

El ecosistema Coqui TTS es el marco que unifica el acceso a modelos como XTTS y otros, mediante APIs y herramientas de entrenamiento e inferencia coherentes, documentación extensa y distribuciones de checkpoints. Desde Coqui, se publican modelos y recursos (incluida documentación de entrenamiento de XTTS), además de políticas de licencia como CPML para ciertos assets, lo que ayuda a escalar adopción y cumplimiento en entornos empresariales.[^4][^1][^16][^17]

La siguiente tabla contrasta Tortoise-TTS y XTTSv2 en aspectos operativos clave.

Tabla 6. Tortoise vs XTTSv2

| Criterio | Tortoise-TTS | XTTSv2 |
|---|---|---|
| Arquitectura | Autorregresivo + Difusión; vocoder UnivNet | Codec/LLM (VQ-VAE + GPT-2 condicionado); vocoder HiFi-GAN |
| Idiomas | Multivoz; enfoque en calidad; sin cobertura multilingüe específica documentada | 17 idiomas; clonación multilingüe zero-shot |
| Control de emoción | Vía presets/voice_samples; calidad prosódica alta | Transferencia por clonación; control explícito en desarrollo |
| Latencia/RTF | RTF 0.25–0.3 en 4 GB VRAM; <500 ms con streaming | Inferencia más rápida que VALL-E; optimizada para producción |
| Licenciamiento | Apache-2.0 | Modelos y herramientas Coqui TTS; assets con CPML |

Interpretación: si se requiere velocidad y escalabilidad multilingüe, XTTSv2 es superior; si el objetivo es la máxima calidad prosódica y se acepta una latencia mayor, Tortoise-TTS es una alternativa sólida.[^11][^1][^2][^4][^16][^17]

## Marca de agua acústica en audio generado

El watermarking acústico es un mecanismo de trazabilidad y autenticación que inserta señales imperceptibles en el audio, diseñadas para resistir transformaciones y ataques. En el contexto de la clonación de voz y generación TTS, su función es doble: verificar que un contenido es sintético y disuadir usos indebidos, además de facilitar pruebas periciales.

VoiceMark propone el primer enfoque de marca de agua resistente a clonación de voz zero-shot que utiliza latentes específicos del hablante como portador de la marca, con módulos de inserción (embedder) y decodificación (decoder) basados en Transformers. El entrenamiento incluye aumentos que simulan VC (enmascaramiento, aleatorización de ventanas, reemplazo de segmentos, codificación neuronal con EnCodec, perturbaciones de velocidad/amplitud/filtros/remuestreo), y una pérdida guiada por Detección de Actividad de Voz (VAD) para enfocar la marca en segmentos con habla. Los experimentos muestran una precisión de detección superior al 95% después de síntesis VC zero-shot, superando significativamente métodos previos. Además, se evaluó la calidad perceptual y de inteligibilidad con métricas como PESQ, SI-SNR, STOI y SMOS, con resultados que reflejan un buen equilibrio entre robustez y calidad.[^19]

La literatura complementa esta aproximación con técnicas de watermarking en representaciones intermedias discretas y evaluaciones sistemáticas de robustez frente a ataques comunes, así como métodos centrados en timbre. A continuación, se sintetiza el rendimiento reportado para VoiceMark frente a transformaciones habituales.[^20][^21][^22]

Tabla 7. Robustez de detección (accuracy, ACC) y tasa de falsa atribución (FAR)

| Transformación | ACC (VoiceMark) | FAR (VoiceMark) | ACC (AudioSeal) | FAR (AudioSeal) | ACC (WavMark) | FAR (WavMark) | ACC (Timbre) | FAR (Timbre) |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| EnCodec | 0.985 | 0.044 | 0.936 | 0.052 | 0.498 | 1.000 | 0.696 | 0.726 |
| Resample | 0.988 | 0.049 | 1.000 | 0.000 | 1.000 | 0.000 | 1.000 | 0.000 |
| Amplitude | 0.995 | 0.014 | 1.000 | 0.000 | 1.000 | 0.000 | 1.000 | 0.000 |
| Filter | 0.987 | 0.036 | 1.000 | 0.000 | 0.711 | 0.289 | 0.989 | 0.022 |
| White noise | 0.965 | 0.109 | 1.000 | 0.000 | 0.938 | 0.058 | 1.000 | 0.000 |
| MP3 | 0.973 | 0.102 | 1.000 | 0.000 | 1.000 | 0.000 | 1.000 | 0.000 |

Interpretación: VoiceMark mantiene alta detectabilidad con baja falsa atribución frente a una gama de transformaciones, con un rendimiento consistente que supera esquemas anteriores en escenarios zero-shot VC. Aunque existen métodos con desempeño perfecto bajo ciertas transformaciones, la capacidad de VoiceMark de sostener la marca a través de VC zero-shot lo hace especialmente relevante para clonación.[^19][^22]

Para sintetizar impacto en calidad, se muestran métricas de calidad perceptual:

Tabla 8. Métricas de calidad perceptual

| Método | PESQ (↑) | SI-SNR (↑) | STOI (↑) | SMOS (↑) |
|---|---:|---:|---:|---:|
| AudioSeal (W) | 4.32 | 26.69 | 0.99 | 4.67 ± 0.10 |
| EnCodec (N) | 1.62 | -0.62 | 0.80 | 2.21 ± 0.15 |
| SpeechTokenizer (N) | 2.58 | 1.64 | 0.89 | 4.63 ± 0.10 |
| VoiceMark (W–N) | 2.20 | 2.01 | 0.89 | 4.25 ± 0.13 |

Interpretación: VoiceMark presenta un equilibrio favorable entre robustez y calidad, con mejoras claras frente a baseline de códec neuronal, y una calidad perceptual competitiva (SMOS) frente a otros esquemas.[^19]

La implementación práctica requiere insertar la marca durante la generación o post-procesado, y verificar en auditorías o ingresos de contenido. Las guías y síntesis del estado del arte sugieren combinar watermarking con detección y políticas de gobernanza, además de pruebas periódicas de robustez frente a nuevas amenazas.[^22][^21]

## Flujo de entrenamiento y generación de modelos de voz

El entrenamiento y la generación de voz demandan un pipeline meticuloso que empiece por los datos. La preparación incluye adquisición de audio limpio, segmentación en frases, normalización de transcripciones y creación de manifiestos (CSV/TSV) que mapen rutas de archivos y texto. La guía universal TTS enfatiza la consistencia de tasa de muestreo (p. ej., 22.05 o 24 kHz) y la limpieza rigurosa para evitar artefactos que degraden prosodia o inteligibilidad.[^23]

En cuanto a requisitos de duración, existen órdenes de magnitud útiles para planificar inversión y retorno. La siguiente tabla resume recomendaciones comunes:

Tabla 9. Requisitos de duración de datos

| Objetivo | Duración recomendada | Observaciones |
|---|---|---|
| Fine-tuning básico en voz específica | 5–20 horas | Mínimo decente con modelo preentrenado; mejora similitud de hablante[^23] |
| Robustez en voz/idioma | 50–100+ horas | Mejora estabilidad, prosodia y cobertura de casos[^23] |
| Entrenamiento desde cero (alta calidad) | 1000+ horas | Solo para modelos generales de alta calidad y propósito amplio[^23] |

Interpretación: la mayor parte de los casos de clonación de voz se benefician de fine-tuning sobre modelos preentrenados (XTTS, Tortoise), evitando costes masivos de datos y cómputo.

En técnica, fine-tuning frente a zero-shot implica decisiones sobre datos y calidad. Las guías de Unsloth documentan dos rutas: ajuste fino (fine-tuning) para capturar peculiaridades de prosodia, fraseo y personalidad vocal, y clonación zero-shot para timbres generales con menor rango expresivo. Para ejecución práctica, recomiendan modelos de menos de 3B parámetros para baja latencia, frecuencia de muestreo de 24 kHz cuando aplica, y parámetros de entrenamiento sensatos (p. ej., batch por dispositivo 1, acumulación de gradiente 4, epochs cortos o max_steps para pruebas). También proponen usar LoRA de 16/8 bits o fine-tuning completo según memoria disponible y objetivos de calidad.[^6]

Tabla 10. Fine-tuning vs zero-shot: impacto en calidad y requisitos

| Dimensión | Fine-tuning | Zero-shot |
|---|---|---|
| Similitud de hablante | Alta; capta peculiaridades y rango expresivo | Media; timbre general sin personalidad completa |
| Datos requeridos | 5–100+ horas según objetivo | 6–10 segundos de referencia |
| Coste computacional | Moderado–alto; depende de duración y modelo | Bajo; inferencia con acondicionamiento |
| Estabilidad prosódica | Mayor; entrenado en estilo/voz objetivo | Menor; sigue estilo del modelo base |
| Tiempo de entrega | Mayor; entrenamiento/validación | Menor; generación inmediata |

Interpretación: la decisión es de producto. Si la identidad vocal y la prosodia son críticas, el fine-tuning es la inversión correcta; si la necesidad es explorar voces o idiomas con rapidez, zero-shot es suficiente.[^6][^7]

Evaluación. Para medir calidad, las métricas comunes incluyen MOS (Mean Opinion Score), CMOS/SMOS (comparativos), CER (Character Error Rate) para inteligibilidad y SECS (Speaker Embedding Cosine Similarity) para similitud de hablante. El paper de XTTS documenta resultados por idioma y comparativas de preferencia (CMOS/SMOS) frente a otros sistemas, lo que ayuda a establecer umbrales de aceptación. Se recomienda construir conjuntos de evaluación con hablantes no vistos, textos diversos por dominio y condiciones acústicas variadas.[^2]

Tabla 11. Métricas de evaluación

| Métrica | Qué mide | Cuándo usar |
|---|---|---|
| MOS/SMOS | Calidad perceptual global | Evaluaciones humanas controladas |
| CMOS | Preferencia relativa entre sistemas | Pruebas A/B con texto y condiciones estandarizadas |
| CER | Inteligibilidad (ASR参考) | Detección de errores de pronunciación/cobertura |
| SECS | Similitud de hablante | Validación de clonación (embeddings de speaker) |

Interpretación: evaluar con múltiples métricas evita sesgos y refleja tanto percepción como inteligibilidad y identidad vocal.

## Librerías Python en el stack: transformers, torchaudio, g2p, so-vits-svc

Transformers de Hugging Face integra Bark con clases y ejemplos listos para usar (p. ej., BarkModel, BarkSemanticModel), y ofrece utilidades para cargar modelos, generar audio en segmentos y gestionar prompts con controles semánticos. Esta integración facilita pipelines en Python, tanto para experimentación como para producción, con soporte de aceleración (p. ej., mediante OpenVINO en plataformas compatibles).[^8][^9][^10]

Torchaudio proporciona el conjunto de herramientas para transformación de audio (resample, spectrograma, mel-escala), lectura/escritura y pipelines de preprocessing. En entrenamiento TTS y VC, se utiliza para homogenizar tasas de muestreo, construir espectrogramas y preparar lotes de audio compatibles con modelos.

Las librerías de g2p (grapheme-to-phoneme) no fueron objeto de revisión detallada en esta investigación; su mención es pertinente porque varios pipelines requieren convertir texto a fonemas para mejorar pronunciación en idiomas con ortografías complejas. En la práctica, XTTS incorpora romanización para coreano, japonés y chino durante el entrenamiento, lo que sugiere que g2p puede ser opcional o complementar romanización en fine-tuning de dominios específicos. Esta es un área con brecha de información que se recomienda cubrir en la fase de implementación, especialmente para acentos regionales o lenguajes con poca estandarización.[^2]

Finalmente, so-vits-svc es el toolkit de conversión de voz cantada (SVC) basado en VITS y SoftVC con vocoder NSF HiFiGAN. No es TTS; funciona con encoders de contenido (ContentVec, Hubertsoft, Whisper-PPG, WavLM, DPHuBERT), predictores de F0 (crepe, dio, harvest, rmvpe, fcpe) y ofrece difusión superficial, exportación ONNX y opciones de clustering/retrieval para reducir fuga de timbre. Existen forks con soporte en tiempo real y mejoras de interfaz; sin embargo, su licenciamiento (AGPL-3.0) y el estado archivado del repositorio original requieren atención legal y técnica en producción.[^12][^13][^14]

Tabla 12. Rol de librerías

| Librería | Rol | Capacidades clave | Casos de uso |
|---|---|---|---|
| Transformers | Carga/inferencia de modelos TTS | Integración Bark; segmentación; prompts; aceleración | Generación de audio con controles semánticos |
| Torchaudio | Procesamiento de audio | Resample; espectrograma; mel; I/O | Preparación de datos y feature pipelines |
| g2p | Texto→fonemas | Normalización fonética | Mejora de pronunciación en idiomas complejos |
| so-vits-svc / svc-fork | VC (SVC) | Encoders; F0; vocoders; difusión superficial | Voice-to-voice cantado; tiempo real en forks |

Interpretación: estas librerías resuelven capas distintas del stack: modelos y generación (Transformers), audio signal (Torchaudio), lingüística (g2p) y conversión de voz cantada (so-vits-svc). La integración adecuada exige entender las fronteras entre TTS y VC.

## Evaluación comparativa y selección de modelo

Comparar modelos exige considerar cobertura idiomática, capacidad de clonación y transferencia de emoción/estilo, VRAM, latencia/RTF, longitud máxima por pase, licencia y facilidad de integración. Bajo estos criterios:

Tabla 13. Comparativa de modelos

| Criterio | XTTSv2 | Bark | Tortoise-TTS | so-vits-svc |
|---|---|---|---|---|
| Idiomas | 17 | Multiformato (varios idiomas) | Multivoz (sin cobertura específica) | N/A (VC) |
| Clonación | Zero-shot con 6s; interpolación | Presets; generación sin identidad específica | voice_samples | Voice-to-voice (no TTS) |
| Emoción/estilo | Transferencia por clonación | Controles semánticos y no verbales | Prosodia realista | Preserva tono/entonación |
| VRAM | Moderada (24 kHz) | ~12 GB (modelo completo); variantes menores | 4 GB para RTF 0.25–0.3 | Variable según encoder/vocoder |
| Latencia/RTF | Rápido (producción) | Casi tiempo real en GPU;拼接 para largo | 0.25–0.3 (4 GB); <500 ms streaming | Tiempo real en forks |
| Longitud por pase | No especificada | ~13–14 s | Depende del preset | N/A |
| Licencia | Coqui TTS; CPML para assets | MIT | Apache-2.0 | AGPL-3.0 |
| Integración | Coqui TTS (API/CLI) | Transformers; OpenVINO | Scripts y API | Python/GUI; ONNX |

Interpretación: para clonación multilingüe con identidad y estilo, XTTSv2 lidera; para audio expresivo y semántico, Bark; para máxima calidad prosódica con latencia razonable, Tortoise; para voz cantada, so-vits-svc. La elección debe alinearse con restricciones técnicas y objetivos de producto.[^1][^8][^11][^12][^13][^14]

## Riesgos, cumplimiento y gobernanza

La clonación de voz comporta riesgos reputacionales, de privacidad y de seguridad. El watermarking acústico funciona como mitigación técnica complementaria a políticas de uso responsable y procedimientos de verificación. Integrar una capa de marca de agua —p. ej., VoiceMark— en audio generado, combinada con auditorías y detección de contenido sintético, reduce la superficie de abuso y apoya cumplimiento corporativo y normativo. Las síntesis de estado del arte recomiendan pruebas de robustez periódicas frente a ataques y transformaciones, y evaluación de impacto en calidad perceptual. El licenciamiento y términos de uso deben revisarse: Bark (MIT) favorece uso comercial; Tortoise (Apache-2.0) también; Coqui TTS utiliza CPML para ciertos assets; so-vits-svc está bajo AGPL-3.0 con repositorio archivado, lo que implica obligaciones de código abierto.[^19][^22][^8][^11][^12]

## Plan de implementación de referencia

Para industrializar la clonación de voz con calidad y cumplimiento, se propone el siguiente plan:

- Preparación de datos: audio limpio (ruido bajo, reverberación mínima), segmentación en frases, normalización de transcripciones, manifiestos CSV/TSV, tasa de muestreo consistente (p. ej., 24 kHz), y, si aplica, etiquetado de emoción en transcripciones mediante tokens especiales para entrenar estilos expresivos.[^23][^6]
- Entrenamiento/fine-tuning: seleccionar modelo preentrenado (XTTSv2, Tortoise), establecer parámetros de entrenamiento con batch y acumulación moderados, usar LoRA 16/8 bits si la VRAM es limitada, y validar con hablantes no vistos. Para XTTS, el fine-tuning puede elevar significativamente la similitud de hablante en escenarios entre idiomas; para Tortoise, ajustar presets y optimizaciones (DeepSpeed, caché KV, FP16).[^6][^2][^11]
- Generación en producción: parametrizar idioma, referencia de hablante, estilo/emoción (vía referencia), chunking y拼接 para textos largos (Bark), y caché para reducir latencias. Implementar watermarking acústico en la capa de post-procesado o generación y establecer verificación automatizada y auditorías.[^1][^8][^19]
- Monitoreo continuo: recopilar feedback de usuarios, mantener datasets de evaluación con MOS/CMOS, CER y SECS, actualizar y reentrenar regularmente para cubrir nuevas jergas y condiciones acústicas, y ejecutar pruebas de robustez de watermarking frente a ataques emergentes.[^7][^22][^19]

Tabla 14. Checklist de implementación

| Fase | Acciones clave | Resultados esperados |
|---|---|---|
| Datos | Limpieza, segmentación, normalización, manifiestos | Datasets listos; consistencia de sampling |
| Entrenamiento | Selección de modelo, parámetros, LoRA/FFT | Mejora de similitud y prosodia |
| Generación | Parámetros, chunking, caché, referencias | Latencia estable; calidad percibida |
| Evaluación | MOS/CMOS, CER, SECS | Métricas de aceptación |
| Watermarking | Inserción y verificación | Trazabilidad; disuasión de abusos |
| Monitoreo | Feedback, reentrenos, pruebas | Evolución y robustez continua |

Interpretación: este plan convierte la tecnología en capacidad operativa, con un bucle cerrado de calidad y gobernanza.

## Brechas de información identificadas

- Control explícito de emoción en XTTSv2: el proyecto indica que está en desarrollo; hoy la técnica operativa se basa en referencias emocionales. Falta documentación detallada y estable sobre parámetros de control directo.[^5]
- Benchmarks estandarizados y comparables entre XTTSv2, Bark y Tortoise más allá de los reportados en sus papers/repositorios: se requieren evaluaciones cruzadas en las mismas condiciones de hardware, textos e idiomas.
- Métricas precisas de latencia/TTFB por hardware de XTTSv2: la información pública no especifica umbrales por GPU/CPU en producción.
- Integración de librerías g2p en pipelines específicos (XTTS/Bark): más allá de la romanización en entrenamiento XTTS para ciertos idiomas, faltan guías de integración finas por idioma/acento.
- Detalles de licensing específicos para modelos Coqui y CPML más allá de la referencia general: conviene revisar cada asset y modelo para uso comercial.
- Impacto del watermarking acústico en calidad percibida en producción TTS multi-idioma: VoiceMark reporta buenas métricas, pero se necesita validación en casos reales multilingües.

Estas brechas no impiden la adopción, pero requieren un plan de validación y mitigación durante la implementación.

## Conclusión

La clonación de voz por IA ha alcanzado una madurez que permite construir productos multilingües y expresivos con costes razonables. XTTSv2, Bark y Tortoise cubren tres necesidades complementarias —identidad multilingüe, riqueza semántica y calidad prosódica—; so-vits-svc resuelve conversión de voz cantada con alta fidelidad; y el watermarking acústico añade una capa de defensa necesaria. Con un pipeline de datos disciplinado, fine-tuning cuando la identidad vocal es crítica, y gobernanza activa, es posible llevar estas tecnologías a producción de manera responsable y rentable.

La clave operativa está en decidir qué problema se resuelve: identidad y cobertura global (XTTSv2), experiencia sonora expresiva (Bark), narrativa prosódica de alta calidad (Tortoise), o conversión de canto (so-vits-svc), y acompañar la solución con verificación y políticas que salvaguarden reputación y cumplimiento.

---

## Referencias

[^1]: coqui/XTTS-v2 - Hugging Face. https://huggingface.co/coqui/XTTS-v2  
[^2]: XTTS: a Massively Multilingual Zero-Shot Text-to-Speech Model. https://arxiv.org/html/2406.04904v1  
[^3]: Coqui TTS (GitHub). https://github.com/coqui-ai/TTS  
[^4]: XTTS model — Training — Coqui TTS docs. https://tts.readthedocs.io/en/latest/models/xtts.html#training  
[^5]: coqui/XTTS-v2 · Emotions - Discussion. https://huggingface.co/coqui/XTTS-v2/discussions/19  
[^6]: Text-to-Speech (TTS) Fine-tuning | Unsloth Documentation. https://docs.unsloth.ai/basics/text-to-speech-tts-fine-tuning  
[^7]: How to optimize voice AI applications with fine-tuning — Telnyx. https://telnyx.com/resources/voice-ai-applications  
[^8]: suno-ai/bark: Text-Prompted Generative Audio Model (GitHub). https://github.com/suno-ai/bark  
[^9]: Bark — Transformers Documentation. https://huggingface.co/docs/transformers/main/en/model_doc/bark  
[^10]: Text-to-speech generation using Bark — OpenVINO Notebook. https://docs.openvino.ai/2024/notebooks/bark-text-to-audio-with-output.html  
[^11]: neonbjb/tortoise-tts (GitHub). https://github.com/neonbjb/tortoise-tts  
[^12]: svc-develop-team/so-vits-svc: SoftVC VITS Singing Voice Conversion (GitHub). https://github.com/svc-develop-team/so-vits-svc  
[^13]: SoftVC VITS Singing Voice Conversion Fork — Documentation. https://so-vits-svc-fork.readthedocs.io/  
[^14]: voicepaw/so-vits-svc-fork (GitHub). https://github.com/voicepaw/so-vits-svc-fork  
[^15]: The Top Open-Source Text to Speech (TTS) Models — Modal Blog. https://modal.com/blog/open-source-tts  
[^16]: Coqui TTS Models — XTTS Training Docs (alt). https://tts.readthedocs.io/en/latest/models/xtts.html#training  
[^17]: Coqui TTS — CPML License. https://coqui.ai/cpml  
[^18]: EnCodec (GitHub). https://github.com/facebookresearch/encodec  
[^19]: VoiceMark: Zero-Shot Voice Cloning-Resistant Watermarking. https://arxiv.org/html/2505.21568v2  
[^20]: Speech Watermarking with Discrete Intermediate Representations — AAAI. https://ojs.aaai.org/index.php/AAAI/article/view/34600/36757  
[^21]: Detecting Voice Cloning Attacks via Timbre Watermarking — NDSS 2024. https://www.ndss-symposium.org/wp-content/uploads/2024-200-paper.pdf  
[^22]: SoK: How Robust is Audio Watermarking in Generative AI models? https://sokaudiowm.github.io/  
[^23]: Universal TTS Model Training & Dataset Preparation Guide (GitHub). https://github.com/AcTePuKc/Universal-TTS-Guide  
[^24]: Text to Speech Finetuning using NeMo — NVIDIA Docs. https://docs.nvidia.com/deeplearning/riva/user-guide/docs/tutorials/tts-finetune-nemo.html