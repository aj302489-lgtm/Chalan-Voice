#!/bin/bash

# Script de configuración rápida para Chalan Voice Project
# Este script configura tanto el backend como la aplicación Android

set -e

# Colores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[OK]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

echo "🚀 Chalan Voice - Configuración Rápida del Proyecto"
echo "=================================================="
echo

# Seleccionar componente a configurar
echo "Selecciona qué componentes configurar:"
echo "1. Solo Backend"
echo "2. Solo Android App"
echo "3. Ambos (Backend + Android)"
echo "4. Salir"
echo

read -p "Opción [1-4]: " choice

case $choice in
    1)
        print_status "Configurando Backend..."
        cd backend
        if [ -f "install.sh" ]; then
            bash install.sh
        else
            print_error "Script de instalación del backend no encontrado"
            exit 1
        fi
        ;;
    2)
        print_status "Configurando Android App..."
        cd android-app
        if [ -f "install.sh" ]; then
            bash install.sh
        else
            print_error "Script de instalación de Android no encontrado"
            exit 1
        fi
        ;;
    3)
        print_status "Configurando ambos componentes..."
        echo
        
        # Backend
        print_status "=== CONFIGURANDO BACKEND ==="
        cd backend
        if [ -f "install.sh" ]; then
            bash install.sh
        else
            print_error "Script de instalación del backend no encontrado"
            exit 1
        fi
        
        cd ..
        echo
        
        # Android
        print_status "=== CONFIGURANDO ANDROID APP ==="
        cd android-app
        if [ -f "install.sh" ]; then
            bash install.sh
        else
            print_error "Script de instalación de Android no encontrado"
            exit 1
        fi
        
        cd ..
        
        print_success "¡Ambos componentes configurados!"
        ;;
    4)
        print_status "Saliendo..."
        exit 0
        ;;
    *)
        print_error "Opción inválida"
        exit 1
        ;;
esac

echo
print_success "¡Configuración completada!"
echo

print_status "Próximos pasos:"
echo "  • Configurar variables de entorno en backend/.env"
echo "  • Verificar URLs de API en android-app/app/src/main/java/com/chalanvoice/data/Constants.kt"
echo "  • Configurar dispositivos/emuladores para testing"
echo "  • Probar la conexión entre backend y Android"
echo

print_status "Comandos útiles:"
echo "  • Backend: cd backend && python run.py"
echo "  • Android: cd android-app && ./gradlew assembleDebug"
echo "  • Documentación API: http://localhost:8000/docs"
echo

print_warning "Recordatorio: No commitees archivos .env ni configuraciones sensibles"