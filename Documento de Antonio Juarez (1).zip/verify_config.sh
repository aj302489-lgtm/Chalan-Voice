#!/bin/bash

# Script de verificación de configuración
# Verifica que todos los archivos de requisitos estén presentes y configurados

set -e

# Colores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_status() { echo -e "${BLUE}[INFO]${NC} $1"; }
print_success() { echo -e "${GREEN}[OK]${NC} $1"; }
print_warning() { echo -e "${YELLOW}[WARNING]${NC} $1"; }
print_error() { echo -e "${RED}[ERROR]${NC} $1"; }

echo "🔍 Verificación de Configuración - Chalan Voice"
echo "=============================================="
echo

# Contadores
total_checks=0
passed_checks=0
warning_checks=0

# Función para verificar archivo
check_file() {
    local file_path="$1"
    local description="$2"
    local required="$3"
    
    total_checks=$((total_checks + 1))
    
    if [ -f "$file_path" ]; then
        print_success "✓ $description"
        passed_checks=$((passed_checks + 1))
        return 0
    else
        if [ "$required" = "true" ]; then
            print_error "✗ $description (FALTANTE)"
            return 1
        else
            print_warning "○ $description (opcional)"
            warning_checks=$((warning_checks + 1))
            return 0
        fi
    fi
}

# Función para verificar contenido
check_content() {
    local file_path="$1"
    local pattern="$2"
    local description="$3"
    
    if [ -f "$file_path" ]; then
        if grep -q "$pattern" "$file_path"; then
            print_success "✓ $description"
            passed_checks=$((passed_checks + 1))
        else
            print_warning "○ $description (no encontrado)"
            warning_checks=$((warning_checks + 1))
        fi
    else
        print_error "✗ $description (archivo no existe)"
    fi
    total_checks=$((total_checks + 1))
}

# Verificar archivos del Backend
echo "🐍 BACKEND - Archivos de Requisitos"
echo "=================================="

check_file "backend/requirements.txt" "Backend requirements.txt (Python dependencies)" "true"
check_file "backend/.env.example" "Backend .env.example (Variables de entorno ejemplo)" "true"
check_file "backend/Dockerfile" "Backend Dockerfile (Docker configuration)" "true"
check_file "backend/docker-compose.yml" "Backend docker-compose.yml (Docker orchestration)" "true"
check_file "backend/install.sh" "Backend install.sh (Script de instalación)" "true"
check_file "backend/nginx.conf" "Backend nginx.conf (Nginx configuration)" "false"

echo

# Verificar contenido del requirements.txt
check_content "backend/requirements.txt" "fastapi" "FastAPI dependency"
check_content "backend/requirements.txt" "torch" "PyTorch dependency"
check_content "backend/requirements.txt" "TTS" "Text-to-Speech dependency"
check_content "backend/requirements.txt" "python-dotenv" "Python-dotenv dependency"

echo

# Verificar variables de entorno en .env.example
check_content "backend/.env.example" "SECRET_KEY" "SECRET_KEY variable"
check_content "backend/.env.example" "DATABASE_URL" "DATABASE_URL variable"
check_content "backend/.env.example" "XTTS_MODEL_NAME" "XTTS_MODEL_NAME variable"
check_content "backend/.env.example" "ALLOWED_ORIGINS" "ALLOWED_ORIGINS variable"

echo

# Verificar archivos del Android
echo "📱 ANDROID APP - Archivos de Configuración"
echo "=========================================="

check_file "android-app/app/build.gradle" "Android app/build.gradle (Android app configuration)" "true"
check_file "android-app/gradle.properties" "Android gradle.properties (Gradle properties)" "true"
check_file "android-app/.env.example" "Android .env.example (Variables de entorno ejemplo)" "false"
check_file "android-app/.gitignore" "Android .gitignore (Android ignore rules)" "true"
check_file "android-app/install.sh" "Android install.sh (Script de instalación)" "true"
check_file "android-app/local.properties" "Android local.properties (Local configuration)" "false"

echo

# Verificar dependencias en build.gradle
if [ -f "android-app/app/build.gradle" ]; then
    check_content "android-app/app/build.gradle" "compose" "Compose dependencies"
    check_content "android-app/app/build.gradle" "dagger:hilt-android" "Hilt dependency injection"
    check_content "android-app/app/build.gradle" "retrofit2" "Retrofit networking"
    check_content "android-app/app/build.gradle" "androidx.lifecycle" "Lifecycle dependencies"
fi

echo

# Verificar archivos globales
echo "🌍 ARCHIVOS GLOBALES"
echo "==================="

check_file ".gitignore" "Global .gitignore (Ignore rules)" "true"
check_file "setup.sh" "Global setup.sh (Setup script)" "true"
check_file "README_CONFIG.md" "README_CONFIG.md (Config documentation)" "true"

echo

# Verificar configuración de Gradle
if [ -f "gradle/libs.versions.toml" ]; then
    check_content "gradle/libs.versions.toml" "android" "Android Gradle plugin version"
    check_content "gradle/libs.versions.toml" "kotlin" "Kotlin version"
fi

echo

# Verificaciones adicionales de estructura
echo "📁 VERIFICACIÓN DE ESTRUCTURA"
echo "============================"

# Verificar estructura de directorios
directories=(
    "backend/app/core"
    "backend/app/models"
    "backend/app/routers"
    "backend/app/services"
    "android-app/app/src/main"
)

for dir in "${directories[@]}"; do
    total_checks=$((total_checks + 1))
    if [ -d "$dir" ]; then
        print_success "✓ Directorio: $dir"
        passed_checks=$((passed_checks + 1))
    else
        print_warning "○ Directorio: $dir (puede no existir en desarrollo inicial)"
    fi
done

echo

# Verificar configuraciones específicas
echo "⚙️  VERIFICACIÓN DE CONFIGURACIONES"
echo "=================================="

# Verificar minSdk y targetSdk en Android
if [ -f "android-app/app/build.gradle" ]; then
    total_checks=$((total_checks + 1))
    if grep -q "minSdk 24" "android-app/app/build.gradle"; then
        print_success "✓ Android minSdk configurado (24)"
        passed_checks=$((passed_checks + 1))
    else
        print_warning "○ Android minSdk no configurado correctamente"
        warning_checks=$((warning_checks + 1))
    fi
fi

# Verificar puerto del backend
total_checks=$((total_checks + 1))
if [ -f "backend/.env.example" ]; then
    if grep -q "PORT=8000" "backend/.env.example"; then
        print_success "✓ Backend puerto configurado (8000)"
        passed_checks=$((passed_checks + 1))
    else
        print_warning "○ Backend puerto no configurado en .env.example"
        warning_checks=$((warning_checks + 1))
    fi
else
    print_error "✗ Backend .env.example no encontrado"
fi

echo

# Resumen final
echo "📊 RESUMEN DE VERIFICACIÓN"
echo "========================="
echo "Total de verificaciones: $total_checks"
print_success "Verificaciones pasadas: $passed_checks"
print_warning "Advertencias: $warning_checks"
echo

if [ $warning_checks -eq 0 ]; then
    print_success "🎉 ¡Configuración completa! Todos los archivos están presentes."
else
    print_warning "⚠️  Hay algunas advertencias, pero la configuración básica está bien."
fi

echo
print_status "Próximos pasos sugeridos:"
echo "1. Configurar variables en backend/.env (copiar desde .env.example)"
echo "2. Verificar URLs en android-app (constants.kt)"
echo "3. Ejecutar backend/install.sh para configurar backend"
echo "4. Ejecutar android-app/install.sh para configurar Android"
echo "5. Probar conexión entre ambos componentes"

echo
print_status "Para configuración rápida, ejecutar: bash setup.sh"
echo